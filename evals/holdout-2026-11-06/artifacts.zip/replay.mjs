// Replay one archived candidate through the original assertions. No model invocation.
import { cp, mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { dirname, join, resolve } from 'node:path';
import assert from 'node:assert/strict';
import { grade } from './judge.mjs';
const records=JSON.parse(await readFile(new URL('./results.json',import.meta.url),'utf8'));
const record=records.find(r=>r.name===process.argv[2]);
if(!record)throw new Error('Usage: node replay.mjs H02-skill-1 (use a name from results.json)');
const workspace=await mkdtemp(join(tmpdir(),'bmg-replay-'));
try {
  await cp(new URL('./inputs/'+record.id+'/',import.meta.url),workspace,{recursive:true});
  for(const name of record.changed_files)await cp(new URL('./outputs/'+record.name+'/'+name,import.meta.url),join(workspace,name));
  const result=await grade(record.id,workspace);
  console.log(JSON.stringify(result,null,2));process.exitCode=result.status==='PASS'?0:1;
} finally {
  assert.equal(dirname(resolve(workspace)), resolve(tmpdir()));
  assert.ok(workspace.startsWith(join(tmpdir(),'bmg-replay-')));
  await rm(workspace,{recursive:true,force:true});
}
