Fixed `index.html`: five digits is now a minimum width, so larger scores retain every digit. Scoring, count-up animation, and layout remain unchanged.

Added `verify-score.cjs`. Confirmed it fails on the original 100,000 case and passes after the fix. Checks cover formatting boundaries, animation, game over, restart, and six-/seven-digit visibility at two viewport sizes. `node smoke.cjs` also passed.

Limit: JavaScript’s existing numeric precision remains unchanged. Supplied guidance and helpers were untouched.