const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Advance updates explicitly so animation assertions are deterministic.
  const game = await openGame(__dirname, () => {
    window.requestAnimationFrame = () => 0;
  });
  try {
    const { page } = game;
    assert.equal(await page.locator('#score').textContent(), '00000');
    const cases = [
      [0, '00000'], [1, '00001'], [9999, '09999'], [10000, '10000'],
      [99999, '99999'], [100000, '100000'], [100001, '100001'],
      [999999, '999999'], [1000000, '1000000'],
      [Number.MAX_SAFE_INTEGER, '9007199254740991'], [12.9, '00012']
    ];
    for (const [value, expected] of cases) {
      const result = await page.evaluate(value => {
        setScore(value);
        drawScore();
        return { text: get('score').textContent, score, vscore, dirty: invalid.score };
      }, value);
      assert.deepEqual(result, { text: expected, score: value, vscore: value, dirty: false });
    }

    const lifecycle = await page.evaluate(() => {
      const snapshot = () => ({ text: get('score').textContent, score, vscore, playing });
      play();
      setScore(99999);
      drawScore();
      addScore(10);
      drawScore();
      const pending = snapshot();
      update(0);
      drawScore();
      const firstFrame = snapshot();
      update(0);
      drawScore();
      const secondFrame = snapshot();
      lose();
      drawScore();
      const lost = snapshot();
      update(0);
      drawScore();
      const stopped = snapshot();
      play();
      drawScore();
      const restarted = snapshot();
      addScore(10);
      for (let frame = 0; frame < 12; frame++) update(0);
      drawScore();
      return { pending, firstFrame, secondFrame, lost, stopped, restarted, settled: snapshot() };
    });
    assert.deepEqual(lifecycle.pending, { text: '99999', score: 100009, vscore: 99999, playing: true });
    assert.deepEqual(lifecycle.firstFrame, { text: '100000', score: 100009, vscore: 100000, playing: true });
    assert.deepEqual(lifecycle.secondFrame, { text: '100001', score: 100009, vscore: 100001, playing: true });
    assert.deepEqual(lifecycle.lost, { text: '100009', score: 100009, vscore: 100009, playing: false });
    assert.deepEqual(lifecycle.stopped, lifecycle.lost);
    assert.deepEqual(lifecycle.restarted, { text: '00000', score: 0, vscore: 0, playing: true });
    assert.deepEqual(lifecycle.settled, { text: '00010', score: 10, vscore: 10, playing: true });

    for (const viewport of [{ width: 320, height: 640 }, { width: 1000, height: 900 }]) {
      await page.setViewportSize(viewport);
      for (const value of [100000, 1000000]) {
        const bounds = await page.evaluate(value => {
          setScore(value);
          drawScore();
          const scoreBox = get('score').getBoundingClientRect();
          const menuBox = get('menu').getBoundingClientRect();
          return { text: get('score').textContent, left: scoreBox.left, right: scoreBox.right,
            menuLeft: menuBox.left, menuRight: menuBox.right, width: scoreBox.width };
        }, value);
        assert.equal(bounds.text, String(value));
        assert.ok(bounds.width > 0 && bounds.left >= bounds.menuLeft && bounds.right <= bounds.menuRight,
          `Score must fit the existing menu at ${viewport.width}px: ${JSON.stringify(bounds)}`);
      }
    }
    console.log('PASS: 11 formatting cases; count-up, authoritative score, loss, restart and settling; 6/7-digit HUD bounds at 320px and 1000px.');
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
