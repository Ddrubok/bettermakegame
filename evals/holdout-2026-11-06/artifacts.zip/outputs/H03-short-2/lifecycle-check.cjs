const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    await game.page.waitForSelector('.tile');
    const results = await game.page.evaluate(() => {
      const originalRAF = window.requestAnimationFrame;
      let queue = [];
      window.requestAnimationFrame = callback => queue.push(callback);
      const results = [];
      const check = (condition, message) => {
        if (!condition) throw new Error(message);
      };
      const frame = () => {
        const callbacks = queue;
        queue = [];
        callbacks.forEach(callback => callback());
      };
      const grid = value => {
        const result = new Grid(4);
        result.insertTile(new Tile({ x: 0, y: 0 }, value));
        return result;
      };
      const metadata = (kind, score = 16) => ({
        terminated: !!kind, won: kind === 'win', over: kind === 'loss',
        score, bestScore: 4096
      });
      const hidden = actuator =>
        !actuator.messageContainer.classList.contains('game-won') &&
        !actuator.messageContainer.classList.contains('game-over');
      const shown = (actuator, kind) => {
        check(actuator.messageContainer.classList.contains(
          kind === 'win' ? 'game-won' : 'game-over'), `${kind} class missing`);
        check(actuator.messageContainer.querySelector('p').textContent ===
          (kind === 'win' ? 'You win!' : 'Game over!'), 'wrong message text');
      };
      const test = (name, run) => {
        queue = [];
        const actuator = new HTMLActuator();
        actuator.clearMessage();
        actuator.clearContainer(actuator.tileContainer);
        actuator.updateScore(0);
        actuator.updateBestScore(0);
        try {
          run(actuator);
          results.push({ name, passed: true });
        } catch (error) {
          results.push({ name, passed: false, error: error.message });
        }
      };
      try {
        for (const kind of ['win', 'loss']) {
          test(`${kind}: continue before frame preserves board and scores`, a => {
            a.actuate(grid(2048), metadata(kind));
            a.continueGame();
            frame();
            check(hidden(a), 'obsolete message reappeared');
            check(a.tileContainer.querySelector('.tile-2048'), 'board missing');
            check(a.score === 16 && a.scoreContainer.firstChild.textContent === '16', 'score missing');
            check(a.bestContainer.textContent === '4096', 'best score missing');
            check(a.scoreContainer.querySelector('.score-addition').textContent === '+16', 'score feedback missing');
          });
          test(`${kind}: restart before frame shows fresh board`, a => {
            a.actuate(grid(2048), metadata(kind));
            a.continueGame();
            a.actuate(grid(2), metadata(null, 0));
            frame();
            check(hidden(a), 'obsolete message over new board');
            check(a.tileContainer.children.length === 1 && a.tileContainer.querySelector('.tile-2'), 'wrong board');
            check(a.scoreContainer.textContent === '0', 'score did not reset');
            check(a.bestContainer.textContent === '4096', 'best score lost');
          });
          test(`${kind}: current terminal message survives earlier invalidation`, a => {
            a.actuate(grid(2), metadata(kind === 'win' ? 'loss' : 'win'));
            a.continueGame();
            a.actuate(grid(2048), metadata(kind));
            frame();
            shown(a, kind);
            check(!a.messageContainer.classList.contains(kind === 'win' ? 'game-over' : 'game-won'), 'stale opposite class');
            a.continueGame();
            check(hidden(a), 'visible message not cleared immediately');
          });
          test(`${kind}: ordinary terminal render`, a => {
            a.actuate(grid(2048), metadata(kind));
            frame();
            shown(a, kind);
          });
        }
        test('direct clearing invalidates all previously queued messages', a => {
          a.actuate(grid(2), metadata('win'));
          a.actuate(grid(4), metadata('loss'));
          a.clearMessage();
          a.clearMessage();
          frame();
          check(hidden(a), 'clearMessage allowed an old message');
          a.actuate(grid(8), metadata('loss'));
          frame();
          shown(a, 'loss');
        });
        test('nonterminal won flag does not show a message', a => {
          a.actuate(grid(2048), { ...metadata('win'), terminated: false });
          frame();
          check(hidden(a), 'continued win displayed a message');
        });
        test('movement, merge, spawn and score feedback survive continuation', a => {
          const board = grid(2);
          const moving = new Tile({ x: 2, y: 0 }, 4);
          moving.previousPosition = { x: 1, y: 0 };
          board.insertTile(moving);
          const merged = new Tile({ x: 3, y: 0 }, 8);
          merged.mergedFrom = [new Tile({ x: 3, y: 0 }, 4), new Tile({ x: 3, y: 1 }, 4)];
          board.insertTile(merged);
          a.actuate(board, metadata('win', 8));
          a.continueGame();
          frame();
          check(a.tileContainer.querySelector('.tile-2.tile-new'), 'spawn feedback missing');
          check(a.tileContainer.querySelector('.tile-8.tile-merged'), 'merge feedback missing');
          check(a.tileContainer.children.length === 5, 'merge source tiles missing');
          const wrapper = a.tileContainer.querySelector('.tile-4.tile-position-2-1');
          check(wrapper, 'previous tile position missing');
          check(a.scoreContainer.querySelector('.score-addition').textContent === '+8', 'score feedback missing');
          frame();
          check(wrapper.classList.contains('tile-position-3-1'), 'tile did not move');
          check(hidden(a), 'obsolete message reappeared');
        });
        test('real GameManager restart and keep-playing lifecycle', () => {
          function Input() {}
          Input.prototype.on = function () {};
          function Storage() {}
          Storage.prototype.getGameState = function () { return null; };
          Storage.prototype.getBestScore = function () { return 4096; };
          Storage.prototype.setGameState = Storage.prototype.clearGameState = function () {};
          const manager = new GameManager(4, Input, HTMLActuator, Storage);
          frame();
          manager.won = true;
          manager.score = 2048;
          manager.actuate();
          GameManager.prototype.keepPlaying.call(manager);
          frame();
          check(hidden(manager.actuator) && manager.actuator.score === 2048, 'keep-playing race');
          manager.over = true;
          manager.actuate();
          frame();
          shown(manager.actuator, 'loss');
          manager.actuate();
          manager.restart();
          frame();
          check(hidden(manager.actuator), 'restart race');
          check(manager.actuator.score === 0 && manager.actuator.tileContainer.children.length === 2, 'restart rendering');
        });
      } finally {
        window.requestAnimationFrame = originalRAF;
      }
      return results;
    });
    for (const result of results) console.log(`${result.passed ? 'PASS' : 'FAIL'} ${result.name}${result.error ? ': ' + result.error : ''}`);
    assert.equal(results.filter(result => !result.passed).length, 0, 'lifecycle checks failed');
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
