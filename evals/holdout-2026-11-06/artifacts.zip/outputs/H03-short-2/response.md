Fixed `js/html_actuator.js` so clearing a message invalidates queued terminal messages while preserving board, score, best-score and animation updates. Later wins/losses still display. GameManager and supplied files remain unchanged.

Added `lifecycle-check.cjs`: 9 checks reproduced the original bug; all 12 now pass. Browser smoke and JavaScript syntax checks also passed.

Validation used headless Chromium; other browsers were not tested.