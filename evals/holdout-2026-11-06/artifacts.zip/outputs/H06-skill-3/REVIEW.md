﻿# Focused review: piece pool and line-clear scoring

The playtester's two observations do not establish that the intended rules are broken. The implementation contains the intended four copies of each of seven types, and ordinary one/two/three/four-row clears award exactly 100/200/400/800. Two separate implementation defects were demonstrated within these routines. No game source, supplied instructions, skill files or browser helpers were edited.

## Intended behavior to preserve

- **Repeats are normal:** `index.html:160–165` refills a 28-entry pool and removes one entry per draw. Four copies of a type allow consecutive repeats within a pool; a refill can extend a streak. In 100 seeded complete pools, every pool contained exactly four of each type and exhausted after 28 draws; the next draw refilled it and left 27 entries. A controlled random value of zero produced four consecutive I pieces, which the specified rules allow. Pool totals alone do not establish unbiased ordering.
- **Nonlinear scoring is intentional:** `index.html:333–350` uses `100 * 2^(n-1)` only when at least one row clears. Fixtures clearing zero through four bottom rows yielded 0/100/200/400/800, correct row counts, correct marker collapse, and no second award when checked again. Three or four rows together reward setup more than clearing them individually; one double is worth two singles. This is a design tradeoff, not an arithmetic defect.
- **A lock adds another 10 points:** `drop()` at `index.html:313` awards 10 before clearing lines. Integrated lock fixtures therefore yielded 110/210/410/810. These totals do not contradict the specified line-clear awards.
- **The visible score catches up:** `update()` at `index.html:265` increments the displayed score by one per update while playing. Controlled zero-time updates brought the HUD to each expected lock total. An intermediate display can understate the current score. This check establishes convergence, not elapsed animation time or perceived clarity.
- **Pool boundaries differ from game boundaries:** source inspection of `reset()` at `index.html:255` shows that it does not empty `pieces` and reuses the preview as current. The current and preview pieces are drawn ahead of subsequent locks. Counts should be compared at refill boundaries, not arbitrary groups of 28 visible pieces or new-game boundaries. No new-game pool reset was specified.

## Demonstrated defects

1. **The final pool entry cannot be drawn until it is alone.** At `index.html:164`, `random(0, pieces.length-1)` returns a value below `length-1`; `splice` truncates this nonnegative value to an integer. With more than one entry, only indices 0 through `length-2` are reachable. The final entry begins as Z and stays at the end, so every pool ends with Z. All 100 seeded pools reproduced this. A deterministic sweep of 2,700 equally spaced random inputs on fresh pools selected I/J/L/O/S/T 400 times each and Z only 300 times. These are controlled samples, not a statistical test of native `Math.random`. The endpoint exclusion follows directly from the code and explains biased ordering without invalidating the four-of-each counts. If a correction is later authorized, an index such as `Math.floor(random(0, pieces.length))` would preserve the 28-entry rule while including every remaining entry.

2. **A completed top row can be missed.** At `index.html:335`, the scan visits rows 20 through 1 on a board whose valid rows are 0 through 19. It skips row 0. A controlled legal O-piece placement at `(0,0)`, supported at row 2, completed only row 0 through the real `drop()` path. The row stayed full, the row counter remained zero, and the score gained only the 10-point lock award while play continued. A simultaneous lower-row clear can shift the top row into a scanned position, so this does not mean all clears involving the top row fail. If a correction is later authorized, scanning from `ny-1` through zero would address the demonstrated boundary omission; the recheck after collapse should be retained.

These findings concern draw ordering and a row-scan boundary. They do not justify removing repeated pieces or flattening the scoring curve.

## Optional alternatives, not required fixes

Keeping the specified pool and scoring curve is valid. A seven-piece bag would constrain streaks and droughts more tightly, but changes the intended variety and planning pressure. Independent equally likely draws would simplify selection but remove the per-pool balance guarantee. Neither is necessary to fix the excluded final index. A linear score would reduce the incentive for larger simultaneous clears and would change the designer's explicit rule.

If player understanding is the issue, a short explanation of the four-of-each pool and an award breakdown such as “4 rows +800; lock +10” could clarify outcomes without changing rules. Faster score convergence could improve immediate readability at the cost of the existing count-up effect. These are unimplemented proposals; no usability benefit was measured.

## Actual checks and limits

- `node smoke.cjs`: passed; Chromium loaded the page with title `Javascript Tetris` and wrote `smoke.png`. The smoke check only loads and captures the page.
- `node review-check.cjs`: passed the focused assertions described above using `require('./browser.cjs').openGame()` and the shipped browser functions. Raw observations are in `review-evidence.json`. Defect assertions deliberately characterize current broken behavior; a passing script is not a clean bill of health.
- Fixtures and random overrides affected only the browser's in-memory state; `Math.random` was restored and the browser closed. No package installation, external network requests, other agents or outside source inspection were used.
- No full human play session, subjective fairness/enjoyment study, native-random distribution study, frame-timing measurement, mobile/cross-browser validation or whole-game audit was performed. Top-row behavior was reproduced with a constructed legal lock state, not a recorded player sequence. Other board arrangements and systems remain untested.

Added artifacts: this report, `review-check.cjs`, `review-evidence.json`, and the smoke helper's `smoke.png` output.
