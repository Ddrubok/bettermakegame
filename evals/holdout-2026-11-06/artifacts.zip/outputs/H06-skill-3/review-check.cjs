﻿const assert = require('node:assert/strict');
const fs = require('node:fs');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    const result = await game.page.evaluate(() => {
      // Controlled in-memory fixtures only; all calls use the shipped game functions.
      playing = false;
      const nativeRandom = Math.random;
      const types = [i,j,l,o,s,t,z];
      const names = ['I','J','L','O','S','T','Z'];
      const name = type => names[types.indexOf(type)];
      let seed = 123456789;
      const seeded = () => {
        seed = (Math.imul(1664525, seed) + 1013904223) >>> 0;
        return seed / 4294967296;
      };
      try {
        Math.random = seeded;
        pieces = [];
        const bags = [];
        for (let b = 0; b < 100; b++) {
          const draws = Array.from({length:28}, () => name(randomPiece().type));
          bags.push({counts:names.map(n => draws.filter(d => d === n).length), last:draws[27], remaining:pieces.length});
        }
        const refill = name(randomPiece().type);
        const refillRemaining = pieces.length;
        // Every midpoint of 2700 equal intervals, on a freshly refilled bag.
        const firstDrawCounts = Object.fromEntries(names.map(n => [n,0]));
        for (let sample = 0; sample < 2700; sample++) {
          Math.random = () => (sample + 0.5) / 2700;
          pieces = [];
          firstDrawCounts[name(randomPiece().type)]++;
        }
        Math.random = () => 0;
        pieces = [];
        const repeated = Array.from({length:4}, () => name(randomPiece().type));
        Math.random = seeded;
        const scoring = [];
        for (let count = 0; count <= 4; count++) {
          clearBlocks(); clearRows(); clearScore();
          for (let y = ny-count; y < ny; y++)
            for (let x = 0; x < nx; x++) setBlock(x,y,j);
          setBlock(0,ny-count-1,t);
          removeLines();
          const once = score;
          removeLines();
          scoring.push({count, score, rows, once, markerAtBottom:getBlock(0,ny-1) === t});
        }
        const locks = [];
        for (let count = 1; count <= 4; count++) {
          clearBlocks(); clearRows(); clearScore(); clearActions();
          for (let y = ny-count; y < ny; y++)
            for (let x = 0; x < nx; x++) if (x !== 5) setBlock(x,y,j);
          current = {type:i, dir:DIR.RIGHT, x:3, y:ny-4};
          next = {type:o, dir:DIR.UP, x:3, y:0};
          playing = true;
          drop();
          const award = score;
          const beforeDisplay = vscore;
          for (let frame = 0; frame < award; frame++) update(0);
          draw();
          locks.push({count,score,rows,beforeDisplay,display:get('score').textContent,playing});
          playing = false;
        }
        // Legal O-piece lock completes only row 0; row 2 provides support.
        clearBlocks(); clearRows(); clearScore(); clearActions();
        for (let x = 2; x < nx; x++) setBlock(x,0,j);
        setBlock(0,2,j); setBlock(1,2,j);
        current = {type:o,dir:DIR.UP,x:0,y:0};
        next = {type:i,dir:DIR.UP,x:3,y:0};
        const legalBeforeLock = unoccupied(current.type,current.x,current.y,current.dir);
        playing = true;
        drop();
        const topRow = {legalBeforeLock, fullAfterLock:Array.from({length:nx},(_,x)=>!!getBlock(x,0)).every(Boolean), score, rows, playing};
        playing = false;
        return {bags,refill,refillRemaining,firstDrawCounts,repeated,scoring,locks,topRow};
      } finally { Math.random = nativeRandom; }
    });
    assert.equal(result.bags.length,100);
    for (const bag of result.bags) {
      assert.deepEqual(bag.counts,[4,4,4,4,4,4,4]);
      assert.equal(bag.remaining,0);
      assert.equal(bag.last,'Z'); // Characterizes the demonstrated defect.
    }
    assert.equal(result.refillRemaining,27);
    assert.deepEqual(result.firstDrawCounts,{I:400,J:400,L:400,O:400,S:400,T:400,Z:300});
    assert.deepEqual(result.repeated,['I','I','I','I']);
    for (const row of result.scoring) {
      assert.equal(row.score,[0,100,200,400,800][row.count]);
      assert.equal(row.rows,row.count);
      assert.equal(row.once,row.score);
      assert.equal(row.markerAtBottom,true);
    }
    for (const row of result.locks) {
      assert.equal(row.score,[0,110,210,410,810][row.count]);
      assert.equal(row.rows,row.count);
      assert.equal(row.beforeDisplay,0);
      assert.equal(row.display,String(row.score).padStart(5,'0'));
      assert.equal(row.playing,true);
    }
    assert.deepEqual(result.topRow,{legalBeforeLock:true,fullAfterLock:true,score:10,rows:0,playing:true});
    fs.writeFileSync('review-evidence.json',JSON.stringify(result,null,2)+'\n');
    console.log('PASS: 100 complete pools + refill; deterministic first-draw bias; valid repeats; 0–4 row awards/collapse/no duplicate award; 1–4 row lock totals/HUD convergence; top-row omission reproduced.');
    console.log('Defect assertions characterize current behavior; passing does not mean defect-free.');
  } finally { await game.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
