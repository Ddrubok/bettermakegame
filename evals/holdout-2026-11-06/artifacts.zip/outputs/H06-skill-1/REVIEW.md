# Focused review: piece repeats and line-clear scoring

The playtester's two observations do **not** by themselves establish a bug. Repeated pieces are compatible with the intended four-of-each pool, and nonlinear scoring is explicitly intended. The implementation preserves the pool totals and ordinary clear awards. Focused checks did, however, demonstrate a draw-order defect and a top-row clear defect. No game source or supplied files were edited.

## Intent supported

- **28 draws per refill, four of each type:** `index.html:161–165` constructs the specified pool and removes one entry per draw. All 100 seeded browser-test pools contained exactly four of each type and were empty after 28 draws. Repeats are normal: a controlled sequence produced `IIII`. Even a correctly uniform 28-piece pool permits adjacent repeats and long gaps; equal totals do not mean evenly spaced pieces.
- **100/200/400/800 line awards:** `removeLines()` at `index.html:333–350` uses `100 * 2^(n-1)` when at least one row clears. Browser fixtures for zero through four adjacent bottom rows returned 0/100/200/400/800 and the correct row counts. Calling removal again awarded nothing further.
- **Lock points and animated display:** `drop()` adds 10 before clearing (`index.html:312–318`), so the tested lock totals were 10/110/210/410/810 for zero through four clears. Those totals do not contradict the line-clear awards. The visible score deliberately catches up one point per update (`index.html:265–268`); synthetic updates verified eventual display of each tested total. This was not a measurement of elapsed animation time.
- **Pool alignment:** source inspection shows `reset()` does not empty `pieces`, and current/next generation consumes draws in advance. A game's first 28 visibly played pieces therefore need not constitute a fresh complete pool. This is a source observation, not a separately tested restart sequence.

## Demonstrated defects

**1. The last pool entry is excluded until it is alone.** At `index.html:164`, `random(0, pieces.length - 1)` supplies a fractional index to `splice`, which truncates it. For a pool of length L > 1, the eligible indices are 0 through L−2; index L−1 is excluded. The pool's original final Z consequently survives until draw 28. All 100 seeded pools ended with Z. A controlled two-entry `[I, Z]` pool with RNG just below 1 still selected I first, then Z. This is positional bias, distinct from legitimate repeats; the four-of-each totals remain correct.

If uniform selection among remaining entries is intended, the targeted correction would be `pieces.splice(Math.floor(Math.random() * pieces.length), 1)[0]`. This preserves the designer's pool and still permits repeats. It is a recommendation only, not applied. Verification of a future correction should test that the last index is selectable while retaining the count/refill checks; the present script intentionally asserts the observed defect and would need updating.

**2. A completed top row is not cleared or rewarded.** `removeLines()` starts at `ny` and loops while `y > 0` (`index.html:335`), although valid board rows are 0 through `ny - 1`. It checks an out-of-board row and skips row 0. A synthetic, collision-valid state placed an O at spawn height with support underneath; locking it completed only row 0. The actual `drop()` path left that row full, reported zero cleared rows and awarded only the 10 lock points; play remained active. This is a row-detection boundary defect, not an error in the exponential award formula. The fixture demonstrates behavior from a constructed valid state, not its frequency or reachability through an uninterrupted natural playthrough.

A targeted correction would scan from `ny - 1` through `0`, preserving the existing recheck after a removal. No correction was applied.

## Design tradeoffs and optional alternatives

Keeping the four-of-each pool is valid: it provides exact refill totals while allowing more local repetition and droughts than a seven-piece bag. A seven-piece bag would reduce those variations and increase predictability, but would change the specified rules. A no-repeat constraint would also change the distribution and is not required to fix the biased index.

Keeping 100/200/400/800 is also valid. A double equals two singles; triples and quadruples reward saving space and taking setup risk more strongly. Linear scoring would weaken that incentive and change the designer's intent. Optional explanatory text describing the pool, award table and separate lock bonus could improve clarity without changing rules; no usability benefit has been measured.

## Actual checks and limits

- `node smoke.cjs` passed, reported **Javascript Tetris**, and generated `smoke.png`. This establishes successful local page loading and screenshot capture, not a visual-quality assessment.
- `node review-checks.cjs` passed all diagnostic assertions in headless Chromium. It uses the supplied `openGame()` helper and the actual page's functions, with seeded/stubbed RNG and constructed boards. It also checked keyboard Space start/Escape stop and collected no page errors during the instrumented reload and tests.
- `review-evidence.json` records sequences, counts, awards, boundary observations, browser version and supplied-file SHA-256 hashes. The script verified those files were unchanged across its execution. Passing diagnostics means the reported existing defects were reproduced, not that the game is defect-free.

Untested: natural-play frequencies and fairness perception; exhaustive random sequences or board states; nonadjacent clear combinations; long-session score behavior; real-time score-animation duration; other browsers/devices. This was not a whole-game, controls, performance or accessibility audit. Added artifacts are this report, the focused verification script, JSON evidence and the smoke screenshot. No network research, external agents, package installation or source fixes were used.
