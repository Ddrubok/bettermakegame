// Focused diagnostics of the unchanged source, including known-defect observations.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { openGame } = require('./browser.cjs');

function suppliedFiles(dir = 'skill') {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(entry => {
    const name = `${dir}/${entry.name}`;
    return entry.isDirectory() ? suppliedFiles(name) : [name];
  });
}
function hashes() {
  return Object.fromEntries([
    'index.html', 'stats.js', 'texture.jpg', 'LICENSE', 'TASK.md',
    'GUIDANCE.md', 'browser.cjs', 'smoke.cjs', ...suppliedFiles()
  ].map(name => [name, crypto.createHash('sha256').update(fs.readFileSync(name)).digest('hex')]));
}

(async () => {
  const before = hashes();
  const game = await openGame();
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    // Reload so error collection includes page initialization.
    await game.page.reload();
    await game.page.keyboard.press('Space');
    assert.equal(await game.page.evaluate(() => playing), true);
    await game.page.keyboard.press('Escape');
    assert.equal(await game.page.evaluate(() => playing), false);
    const evidence = await game.page.evaluate(() => {
      const names = ['I', 'J', 'L', 'O', 'S', 'T', 'Z'];
      const types = [i, j, l, o, s, t, z];
      const name = piece => names[types.indexOf(piece.type)];
      const nativeRandom = Math.random;
      let seed = 123456789;
      const bags = [];
      let repeatPrefix, upperBoundary;
      try {
        Math.random = () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296);
        pieces = [];
        for (let bag = 0; bag < 100; bag++) {
          const sequence = Array.from({ length: 28 }, () => name(randomPiece()));
          bags.push({ sequence: sequence.join(''), counts: names.map(n => sequence.filter(x => x === n).length), remaining: pieces.length });
        }
        pieces = [];
        Math.random = () => 0;
        repeatPrefix = Array.from({ length: 4 }, () => name(randomPiece())).join('');
        // A two-entry pool isolates exclusion of the last entry.
        pieces = [i, z];
        Math.random = () => 1 - Number.EPSILON;
        upperBoundary = [name(randomPiece()), name(randomPiece())];
      } finally {
        Math.random = nativeRandom;
        pieces = [];
      }

      const isolatedAwards = [];
      for (let count = 0; count <= 4; count++) {
        clearBlocks(); clearRows(); clearScore();
        for (let row = ny - count; row < ny; row++)
          for (let col = 0; col < nx; col++) setBlock(col, row, j);
        removeLines();
        const firstScore = score;
        const firstRows = rows;
        removeLines();
        isolatedAwards.push({ count, score: firstScore, rows: firstRows, scoreAfterSecondCall: score, rowsAfterSecondCall: rows });
      }

      const lockAwards = [];
      for (let count = 0; count <= 4; count++) {
        clearBlocks(); clearRows(); clearScore(); clearActions(); dt = 0;
        for (let row = ny - count; row < ny; row++)
          for (let col = 0; col < nx; col++) if (col !== 4) setBlock(col, row, j);
        setCurrentPiece({ type: i, dir: DIR.RIGHT, x: 2, y: ny - 4 });
        setNextPiece({ type: o, dir: DIR.UP, x: 0, y: 0 });
        playing = true;
        drop();
        const lockScore = score;
        const immediatelyDisplayed = vscore;
        for (let frame = 0; frame < lockScore; frame++) update(0);
        drawScore();
        lockAwards.push({ count, score: lockScore, rows, immediatelyDisplayed, settledDisplayed: document.getElementById('score').textContent });
        playing = false;
      }

      // Boundary diagnostic using the real locking path: O completes only row 0.
      clearBlocks(); clearRows(); clearScore(); clearActions(); dt = 0;
      for (let col = 2; col < nx; col++) setBlock(col, 0, j);
      setBlock(0, 2, j); // Supports the O at spawn height; row 1 stays incomplete.
      setCurrentPiece({ type: o, dir: DIR.UP, x: 0, y: 0 });
      setNextPiece({ type: i, dir: DIR.UP, x: 5, y: 0 });
      const topRowStartFits = unoccupied(current.type, current.x, current.y, current.dir);
      playing = true;
      drop();
      const topRow = { startFits: topRowStartFits, score, rows, remainsFull: Array.from({ length: nx }, (_, col) => !!getBlock(col, 0)).every(Boolean), playing };
      playing = false;
      return { bags, repeatPrefix, upperBoundary, isolatedAwards, lockAwards, topRow };
    });
    const awards = [0, 100, 200, 400, 800];
    for (const bag of evidence.bags) {
      assert.deepEqual(bag.counts, [4, 4, 4, 4, 4, 4, 4]);
      assert.equal(bag.remaining, 0);
      assert.equal(bag.sequence.at(-1), 'Z'); // Known positional bias, not desired behavior.
    }
    assert.equal(evidence.repeatPrefix, 'IIII');
    assert.deepEqual(evidence.upperBoundary, ['I', 'Z']);
    for (const row of evidence.isolatedAwards) {
      assert.equal(row.score, awards[row.count]);
      assert.equal(row.rows, row.count);
      assert.equal(row.scoreAfterSecondCall, row.score);
      assert.equal(row.rowsAfterSecondCall, row.rows);
    }
    for (const row of evidence.lockAwards) {
      assert.equal(row.score, 10 + awards[row.count]);
      assert.equal(row.rows, row.count);
      assert.equal(row.immediatelyDisplayed, 0);
      assert.equal(row.settledDisplayed, String(row.score).padStart(5, '0'));
    }
    assert.deepEqual(evidence.topRow, { startFits: true, score: 10, rows: 0, remainsFull: true, playing: true });
    assert.deepEqual(errors, []);
    assert.deepEqual(hashes(), before);
    fs.writeFileSync('review-evidence.json', JSON.stringify({
      status: 'All diagnostic assertions passed; two existing defects reproduced, not fixed.',
      browser: await game.browser.version(), pageErrors: errors,
      suppliedFilesUnchangedDuringChecks: true, suppliedFileHashes: before, ...evidence
    }, null, 2) + '\n');
    console.log('PASS: start/escape; 100 seeded 28-draw pools; repeats; excluded-tail diagnostic; 0–4 clear and lock awards; no double award; score display catch-up; row-0 defect diagnostic; supplied-file hashes unchanged. Evidence: review-evidence.json');
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
