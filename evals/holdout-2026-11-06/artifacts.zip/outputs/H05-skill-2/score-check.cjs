const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Advance the real game update explicitly so assertions do not race frames.
  const game = await openGame(__dirname, () => {
    window.requestAnimationFrame = () => 0;
  });
  try {
    const errors = [];
    game.page.on('pageerror', error => errors.push(error.message));
    const cases = [
      [0, '00000'], [7, '00007'], [1234, '01234'], [99999, '99999'],
      [100000, '100000'], [1234567, '1234567'],
      [2147483648, '2147483648'], [Number.MAX_SAFE_INTEGER, '9007199254740991']
    ];
    for (const [value, expected] of cases) {
      const result = await game.page.evaluate(value => {
        setScore(value);
        drawScore();
        return { text: get('score').textContent, score, vscore, dirty: invalid.score };
      }, value);
      assert.deepEqual(result, { text: expected, score: value, vscore: value, dirty: false });
    }

    const animation = await game.page.evaluate(() => {
      play();
      setScore(99998);
      addScore(5);
      drawScore();
      const frames = [get('score').textContent];
      for (let frame = 0; frame < 6; frame++) {
        update(0);
        drawScore();
        frames.push(get('score').textContent);
      }
      return { frames, score, vscore };
    });
    assert.deepEqual(animation, {
      frames: ['99998', '99999', '100000', '100001', '100002', '100003', '100003'],
      score: 100003, vscore: 100003
    });

    const lifecycle = await game.page.evaluate(() => {
      addScore(100);
      lose();
      drawScore();
      const ended = { text: get('score').textContent, score, vscore, playing };
      play();
      drawScore();
      return { ended, restarted: { text: get('score').textContent, score, vscore, playing } };
    });
    assert.deepEqual(lifecycle, {
      ended: { text: '100103', score: 100103, vscore: 100103, playing: false },
      restarted: { text: '00000', score: 0, vscore: 0, playing: true }
    });

    for (const width of [320, 400, 500, 600, 700, 800, 1000]) {
      await game.page.setViewportSize({ width, height: 900 });
      const bounds = await game.page.evaluate(() => {
        setScore(1234567);
        drawScore();
        const scoreRect = get('score').getBoundingClientRect();
        const menuRect = get('menu').getBoundingClientRect();
        return { text: get('score').textContent, left: scoreRect.left, right: scoreRect.right,
          menuLeft: menuRect.left, menuRight: menuRect.right };
      });
      assert.equal(bounds.text, '1234567');
      assert.ok(bounds.left >= bounds.menuLeft && bounds.right <= bounds.menuRight,
        `Seven-digit score fits the existing HUD at width ${width}`);
    }
    await game.page.screenshot({ path: 'score-high.png' });
    assert.deepEqual(errors, []);
    console.log('PASS: padding, large integers, count-up boundary, score authority, loss/restart, seven HUD viewport widths.');
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
