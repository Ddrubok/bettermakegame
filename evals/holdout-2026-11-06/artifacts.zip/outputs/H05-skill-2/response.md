Fixed `index.html` to retain all score digits while preserving five-digit zero padding, count-up animation, scoring, and layout.

Added `score-check.cjs`; reproduced the original failure, then passed padding, large-integer, count-up, loss/restart, and seven viewport checks. `node smoke.cjs` also passed.

Saved `score-high.png` and `smoke.png`. Supplied files remain unchanged.

Limits: Chromium only; layout checks covered seven-digit scores, numeric checks through JavaScript’s maximum safe integer.