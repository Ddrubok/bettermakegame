Fixed `index.html` so scores retain all digits while smaller scores keep five-digit zero padding. Scoring, animation and layout remain unchanged.

Checks:
- Reproduced `100000` displaying as `00000` before the fix.
- `node score-check.cjs` passed: boundaries, large safe integers, count-up, loss/restart, desktop/mobile bounds.
- `node smoke.cjs` passed and generated `smoke.png`.

Limit: checks used controlled score states, not prolonged gameplay; JavaScript’s existing integer precision limits remain.