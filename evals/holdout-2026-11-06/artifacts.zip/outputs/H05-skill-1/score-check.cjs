const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Advance game updates explicitly so score animation checks are deterministic.
  const game = await openGame(__dirname, () => {
    window.requestAnimationFrame = () => 0;
  });
  try {
    const errors = [];
    game.page.on('pageerror', error => errors.push(error.message));
    const results = await game.page.evaluate(() => {
      const snapshot = () => ({
        score, vscore, text: document.getElementById('score').textContent
      });
      const samples = [0, 7, 9999, 10000, 99999, 100000, 1234567,
        Number.MAX_SAFE_INTEGER].map(value => {
        setScore(value);
        drawScore();
        return snapshot();
      });
      play();
      setScore(99998);
      addScore(4);
      drawScore();
      const animation = [snapshot()];
      for (let frame = 0; frame < 5; frame++) {
        update(0);
        drawScore();
        animation.push(snapshot());
      }
      addScore(800);
      lose();
      drawScore();
      const final = snapshot();
      play();
      drawScore();
      return { samples, animation, final, restart: snapshot() };
    });
    for (const sample of results.samples) {
      assert.equal(sample.text, String(sample.score).padStart(5, '0'));
      assert.equal(sample.vscore, sample.score);
    }
    assert.deepEqual(results.animation.map(s => s.text),
      ['99998', '99999', '100000', '100001', '100002', '100002']);
    assert.ok(results.animation.every(s => s.score === 100002));
    assert.deepEqual(results.final, { score: 100802, vscore: 100802, text: '100802' });
    assert.deepEqual(results.restart, { score: 0, vscore: 0, text: '00000' });

    for (const viewport of [{ width: 1000, height: 900 }, { width: 375, height: 667 }]) {
      await game.page.setViewportSize(viewport);
      const bounds = await game.page.evaluate(() => {
        setScore(Number.MAX_SAFE_INTEGER);
        drawScore();
        const element = document.getElementById('score');
        const rect = element.getBoundingClientRect();
        const range = document.createRange();
        range.selectNodeContents(element);
        const text = range.getBoundingClientRect();
        return { left: rect.left, right: rect.right, bottom: rect.bottom,
          textWidth: text.width, width: rect.width, viewportWidth: innerWidth,
          viewportHeight: innerHeight };
      });
      assert.ok(bounds.left >= 0 && bounds.right <= bounds.viewportWidth);
      assert.ok(bounds.bottom <= bounds.viewportHeight);
      assert.ok(bounds.textWidth <= bounds.width + 1);
    }
    assert.deepEqual(errors, []);
    console.log('PASS: padding, 5/6-digit boundary, large safe integers, count-up, authoritative score, loss, restart, desktop/mobile bounds.');
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
