function KeyboardInputManager() {
  this.events = {};

  if (window.navigator.msPointerEnabled) {
    //Internet Explorer 10 style
    this.eventTouchstart    = "MSPointerDown";
    this.eventTouchmove     = "MSPointerMove";
    this.eventTouchend      = "MSPointerUp";
    this.eventTouchcancel   = "MSPointerCancel";
  } else {
    this.eventTouchstart    = "touchstart";
    this.eventTouchmove     = "touchmove";
    this.eventTouchend      = "touchend";
    this.eventTouchcancel   = "touchcancel";
  }

  this.listen();
}

KeyboardInputManager.prototype.on = function (event, callback) {
  if (!this.events[event]) {
    this.events[event] = [];
  }
  this.events[event].push(callback);
};

KeyboardInputManager.prototype.emit = function (event, data) {
  var callbacks = this.events[event];
  if (callbacks) {
    callbacks.forEach(function (callback) {
      callback(data);
    });
  }
};

KeyboardInputManager.prototype.listen = function () {
  var self = this;

  var map = {
    38: 0, // Up
    39: 1, // Right
    40: 2, // Down
    37: 3, // Left
    75: 0, // Vim up
    76: 1, // Vim right
    74: 2, // Vim down
    72: 3, // Vim left
    87: 0, // W
    68: 1, // D
    83: 2, // S
    65: 3  // A
  };

  // Respond to direction keys
  document.addEventListener("keydown", function (event) {
    var modifiers = event.altKey || event.ctrlKey || event.metaKey ||
                    event.shiftKey;
    var mapped    = map[event.which];

    if (!modifiers) {
      if (mapped !== undefined) {
        event.preventDefault();
        self.emit("move", mapped);
      }
    }

    // R key restarts the game
    if (!modifiers && event.which === 82) {
      self.restart.call(self, event);
    }
  });

  // Respond to button presses
  this.bindButtonPress(".retry-button", this.restart);
  this.bindButtonPress(".restart-button", this.restart);
  this.bindButtonPress(".keep-playing-button", this.keepPlaying);

  // A swipe owns one contact and is consumed or invalidated exactly once.
  var swipe = null;
  var pointers = {};
  var usePointers = window.navigator.msPointerEnabled;
  var gameContainer = document.getElementsByClassName("game-container")[0];

  function clearSwipe() {
    swipe = null;
  }

  function pointerCount() {
    return Object.keys(pointers).length;
  }

  // Observe the whole document so a second finger outside the board also
  // invalidates the gesture, and releases outside the board clean up state.
  document.addEventListener(this.eventTouchstart, function (event) {
    var contact;
    if (usePointers) {
      pointers[event.pointerId] = true;
      if (pointerCount() !== 1 || swipe) {
        clearSwipe();
        return;
      }
      contact = { identifier: event.pointerId,
                  clientX: event.pageX, clientY: event.pageY };
    } else {
      if (event.touches.length !== 1 || swipe) {
        clearSwipe();
        return;
      }
      contact = event.touches[0];
    }

    if (!gameContainer.contains(event.target)) return;
    swipe = { id: contact.identifier,
              x: contact.clientX, y: contact.clientY };
    event.preventDefault();
  }, { passive: false });

  document.addEventListener(this.eventTouchmove, function (event) {
    if (swipe || gameContainer.contains(event.target)) event.preventDefault();
    if (!usePointers && (event.touches.length !== 1 ||
        (swipe && event.touches[0].identifier !== swipe.id))) {
      clearSwipe();
    }
  }, { passive: false });

  document.addEventListener(this.eventTouchcancel, function (event) {
    if (usePointers) delete pointers[event.pointerId];
    clearSwipe();
  });

  document.addEventListener(this.eventTouchend, function (event) {
    var completed = swipe;
    clearSwipe();
    var contact;
    if (usePointers) {
      delete pointers[event.pointerId];
      if (!completed || pointerCount() !== 0 ||
          event.pointerId !== completed.id) return;
      contact = { clientX: event.pageX, clientY: event.pageY };
    } else {
      if (!completed || event.touches.length !== 0 ||
          event.changedTouches.length !== 1 ||
          event.changedTouches[0].identifier !== completed.id) return;
      contact = event.changedTouches[0];
    }

    var dx = contact.clientX - completed.x;
    var absDx = Math.abs(dx);
    var dy = contact.clientY - completed.y;
    var absDy = Math.abs(dy);

    if (Math.max(absDx, absDy) > 10) {
      // (right : left) : (down : up)
      self.emit("move", absDx > absDy ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0));
    }
  });

  window.addEventListener("blur", function () {
    clearSwipe();
    pointers = {};
  });
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) {
      clearSwipe();
      pointers = {};
    }
  });
};

KeyboardInputManager.prototype.restart = function (event) {
  event.preventDefault();
  this.emit("restart");
};

KeyboardInputManager.prototype.keepPlaying = function (event) {
  event.preventDefault();
  this.emit("keepPlaying");
};

KeyboardInputManager.prototype.bindButtonPress = function (selector, fn) {
  var button = document.querySelector(selector);
  button.addEventListener("click", fn.bind(this));
  button.addEventListener(this.eventTouchend, fn.bind(this));
};
