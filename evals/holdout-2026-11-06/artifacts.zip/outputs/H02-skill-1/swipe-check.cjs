const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  for (const pointerMode of [false, true]) {
    const game = await openGame(__dirname, pointerMode ? () => {
      Object.defineProperty(navigator, 'msPointerEnabled', { value: true });
    } : undefined);
    try {
      const results = await game.page.evaluate((pointerMode) => {
        const input = new KeyboardInputManager();
        const moves = [];
        input.on('move', direction => moves.push(direction));
        const board = document.querySelector('.game-container');
        const names = pointerMode
          ? { start: 'MSPointerDown', move: 'MSPointerMove', end: 'MSPointerUp', cancel: 'MSPointerCancel' }
          : { start: 'touchstart', move: 'touchmove', end: 'touchend', cancel: 'touchcancel' };
        const contact = (id, x = 100, y = 100) => ({ identifier: id, clientX: x, clientY: y });
        function send(kind, active, changed, target = board) {
          const event = new Event(names[kind], { bubbles: true, cancelable: true });
          const p = changed[0];
          const fields = pointerMode
            ? { pointerId: p.identifier, pageX: p.clientX, pageY: p.clientY }
            : { touches: active, targetTouches: active, changedTouches: changed };
          Object.entries(fields).forEach(([key, value]) => Object.defineProperty(event, key, { value }));
          target.dispatchEvent(event);
        }
        const start = (id = 1) => send('start', [contact(id)], [contact(id)]);
        const end = (id = 1, x = 130, y = 100) => send('end', [], [contact(id, x, y)]);
        const clean = () => { start(); end(); };
        const results = [];
        function check(name, run, expected) {
          moves.length = 0;
          run();
          results.push({ name, actual: moves.slice(), expected });
        }
        check('orphan release', () => end(), []);
        check('directions and vertical tie', () => {
          for (const [x, y] of [[100, 80], [120, 100], [100, 120], [80, 100], [120, 120]]) {
            start(); end(1, x, y);
          }
        }, [0, 1, 2, 3, 2]);
        check('strict threshold and fresh origin', () => {
          for (const [x, y] of [[100, 100], [110, 100], [90, 100], [100, 110], [100, 90], [110, 110], [111, 100]]) {
            start(); end(1, x, y);
          }
        }, [1]);
        check('consume once', () => { clean(); end(); }, [1]);
        check('cancel then stale release and recovery', () => {
          start(); send('cancel', [], [contact(1)]); end(); clean();
        }, [1]);
        check('second finger outside board and recovery', () => {
          start();
          send('start', [contact(1), contact(2)], [contact(2)], document.body);
          send('end', [contact(1)], [contact(2, 160)], document.body);
          end(); clean();
        }, [1]);
        check('multi-touch reverse release and recovery', () => {
          start(); send('start', [contact(1), contact(2)], [contact(2)]);
          send('end', [contact(2)], [contact(1, 150)]);
          end(2); clean();
        }, [1]);
        check('multi-touch cancellation and recovery', () => {
          start(); send('start', [contact(1), contact(2)], [contact(2)]);
          send('cancel', [contact(1)], [contact(2)]);
          end(); clean();
        }, [1]);
        check('blur interrupts and recovers', () => {
          start(); window.dispatchEvent(new Event('blur')); end(); clean();
        }, [1]);
        check('release outside board consumes once', () => {
          start(); send('end', [], [contact(1, 130)], document.body); end();
        }, [1]);
        check('gesture starting outside board is ignored', () => {
          send('start', [contact(1)], [contact(1)], document.body); end(); clean();
        }, [1]);
        if (!pointerMode) {
          check('wrong contact cannot finish gesture', () => { start(); end(2); clean(); }, [1]);
          check('multi-touch discovered during move', () => {
            start(); send('move', [contact(1), contact(2)], [contact(2)]); end(); clean();
          }, [1]);
          check('simultaneous two-finger start', () => {
            send('start', [contact(1), contact(2)], [contact(1), contact(2)]);
            send('end', [], [contact(1, 130), contact(2, 130)]); clean();
          }, [1]);
        }
        check('keyboard mapping and modifiers', () => {
          for (const key of [38, 39, 40, 37, 75, 76, 74, 72, 87, 68, 83, 65]) {
            document.dispatchEvent(new KeyboardEvent('keydown', { keyCode: key, bubbles: true, cancelable: true }));
          }
          document.dispatchEvent(new KeyboardEvent('keydown', { keyCode: 38, shiftKey: true }));
        }, [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3]);
        return results;
      }, pointerMode);
      for (const result of results) assert.deepEqual(result.actual, result.expected, result.name);
      console.log(`${pointerMode ? 'Legacy pointer' : 'Touch'}: ${results.length} browser checks passed`);
    } finally {
      await game.close();
    }
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
