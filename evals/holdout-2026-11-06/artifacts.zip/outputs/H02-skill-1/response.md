Fixed swipe lifecycle handling in `js/keyboard_input_manager.js`: cancelled or multi-touch gestures cannot move, completed gestures fire once, and clean gestures recover normally.

Added `swipe-check.cjs`. Passed 27 browser checks, JavaScript syntax validation, and the supplied smoke check. Direction mapping, strict >10-pixel threshold, keyboard controls, and game rules are preserved.

Limits: synthetic browser events only; physical devices and native legacy IE remain untested.