﻿const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  let total = 0;
  for (const pointers of [false, true]) {
    const game = await openGame(__dirname, pointers ? () => {
      Object.defineProperty(navigator, 'msPointerEnabled', { value: true });
    } : undefined);
    const errors = [];
    game.page.on('pageerror', error => errors.push(error.message));
    try {
      await game.page.waitForSelector('.tile');
      const results = await game.page.evaluate(pointers => {
        const board = document.querySelector('.game-container');
        const moves = [];
        const emit = KeyboardInputManager.prototype.emit;
        KeyboardInputManager.prototype.emit = function (name, value) {
          if (name === 'move') moves.push(value);
          return emit.call(this, name, value);
        };
        const point = (id, x = 100, y = 100) => ({ id, x, y });
        const a = point(1), b = point(2, 200, 200);
        function send(type, contacts, changed, target = board) {
          let event;
          if (pointers) {
            const names = { start: 'MSPointerDown', move: 'MSPointerMove',
              end: 'MSPointerUp', cancel: 'MSPointerCancel' };
            event = new Event(names[type], { bubbles: true, cancelable: true });
            const p = changed[0];
            Object.assign(event, { pointerId: p.id, pageX: p.x, pageY: p.y });
          } else {
            const touch = p => new Touch({ identifier: p.id, target,
              clientX: p.x, clientY: p.y, pageX: p.x, pageY: p.y });
            event = new TouchEvent('touch' + type, { bubbles: true, cancelable: true,
              touches: contacts.map(touch), targetTouches: contacts.map(touch),
              changedTouches: changed.map(touch) });
          }
          target.dispatchEvent(event);
        }
        const start = () => send('start', [a], [a]);
        const finish = (x = 140, y = 100) => send('end', [], [point(1, x, y)]);
        const swipe = (x = 140, y = 100) => { start(); finish(x, y); };
        const results = [];
        function check(name, expected, action) {
          window.dispatchEvent(new Event('blur'));
          moves.length = 0;
          action();
          results.push({ name, expected, actual: moves.slice() });
        }
        check('four directions', [0, 1, 2, 3], () => {
          swipe(100, 80); swipe(); swipe(100, 120); swipe(80, 100);
        });
        check('strict threshold and vertical ties', [1, 2, 0], () => {
          swipe(110, 100); swipe(100, 90); swipe(100, 100);
          swipe(111, 100); swipe(111, 111); swipe(89, 89);
        });
        check('orphan and duplicate releases', [1], () => {
          finish(); swipe(); finish(180); finish(180);
        });
        check('cancel then stale release and recovery', [1], () => {
          start(); send('cancel', [], [a]); finish(180); swipe();
        });
        check('blur interruption and recovery', [1], () => {
          start(); window.dispatchEvent(new Event('blur')); finish(); swipe();
        });
        for (const outside of [false, true]) {
          check('second contact ' + (outside ? 'outside' : 'inside') + ' board', [1], () => {
            start(); send('start', [a, b], [b], outside ? document.body : board);
            send('end', [a], [b], outside ? document.body : board);
            finish(180); swipe();
          });
        }
        check('first contact released before second', [1], () => {
          start(); send('start', [a, b], [b]);
          send('end', [b], [point(1, 180, 100)]);
          send('end', [], [point(2, 240, 200)]); swipe();
        });
        check('new finger while rejected contact remains', [1], () => {
          start(); send('start', [a, b], [b]); send('end', [a], [b]);
          send('start', [a, b], [b]); send('end', [a], [b]); finish(); swipe();
        });
        check('mismatched ending identity', [1], () => {
          start(); send('end', [], [point(9, 180, 100)]); finish(); swipe();
        });
        check('outside start cannot swipe board', [1], () => {
          send('start', [a], [a], document.body); finish(); swipe();
        });
        check('release outside board consumes once', [1, 1], () => {
          start(); send('end', [], [point(1, 140, 100)], document.body);
          finish(); swipe();
        });
        if (!pointers) {
          check('simultaneous multi-touch start', [1], () => {
            send('start', [a, b], [a, b]); send('end', [], [a, b]); swipe();
          });
          check('multi-touch discovered during movement', [1], () => {
            start(); send('move', [a, b], [a, b]);
            send('end', [a], [b]); finish(); swipe();
          });
          check('partial end invalidates gesture', [1], () => {
            start(); send('end', [b], [point(1, 180, 100)]);
            send('end', [], [point(2, 240, 200)]); swipe();
          });
          check('multiple changed touches cannot complete', [1], () => {
            start(); send('end', [], [point(1, 180, 100), b]); swipe();
          });
          check('movement identity mismatch', [1], () => {
            start(); send('move', [b], [b]); finish(); swipe();
          });
        }
        check('keyboard mappings and modifiers', [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3], () => {
          for (const which of [38, 39, 40, 37, 75, 76, 74, 72, 87, 68, 83, 65]) {
            document.dispatchEvent(new KeyboardEvent('keydown', { keyCode: which, bubbles: true }));
          }
          for (const modifier of ['altKey', 'ctrlKey', 'metaKey', 'shiftKey']) {
            document.dispatchEvent(new KeyboardEvent('keydown', { keyCode: 38, [modifier]: true }));
          }
        });
        return results;
      }, pointers);
      for (const result of results) {
        assert.deepEqual(result.actual, result.expected, `${pointers ? 'MSPointer' : 'touch'}: ${result.name}`);
        total++;
      }
      assert.deepEqual(errors, [], 'browser errors');
      console.log(`${pointers ? 'MSPointer' : 'touch'}: ${results.length} checks passed`);
    } finally {
      await game.close();
    }
  }
  console.log(`${total} browser lifecycle checks passed`);
})().catch(error => { console.error(error); process.exitCode = 1; });


