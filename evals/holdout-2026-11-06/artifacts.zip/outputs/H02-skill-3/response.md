Updated `js/keyboard_input_manager.js` to reject cancelled or multi-touch gestures, prevent stale/duplicate moves, and allow clean recovery. Direction mapping, strict >10-pixel threshold, keyboard controls, and game rules are preserved.

Checks passed: 31 browser regression cases, `node smoke.cjs`, and JavaScript syntax validation.

Added `swipe-check.cjs`. Supplied files remain unchanged. Touch and legacy pointer checks used synthetic events; physical devices and IE10 were not tested.