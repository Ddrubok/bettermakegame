const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

async function checkMode(pointerMode) {
  const game = await openGame(__dirname, pointerMode ? () => {
    Object.defineProperty(navigator, 'msPointerEnabled', { value: true });
  } : undefined);
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    await game.page.waitForSelector('.tile');
    const passed = await game.page.evaluate(pointerMode => {
      const container = document.querySelector('.game-container');
      const moves = [];
      const passed = [];
      const originalEmit = KeyboardInputManager.prototype.emit;
      KeyboardInputManager.prototype.emit = function (name, value) {
        if (name === 'move') moves.push(value);
        else originalEmit.call(this, name, value);
      };
      const contact = (id, x = 100, y = 100) => ({ id, x, y });
      function send(type, active, changed) {
        if (pointerMode) {
          for (const point of changed) {
            const event = new Event({start:'MSPointerDown', move:'MSPointerMove', end:'MSPointerUp', cancel:'MSPointerCancel'}[type], {bubbles:true, cancelable:true});
            Object.assign(event, {pointerId:point.id, pageX:point.x, pageY:point.y});
            container.dispatchEvent(event);
          }
        } else {
          const touch = point => new Touch({identifier:point.id, target:container, clientX:point.x, clientY:point.y});
          container.dispatchEvent(new TouchEvent('touch' + type, {
            bubbles:true, cancelable:true, touches:active.map(touch),
            targetTouches:active.map(touch), changedTouches:changed.map(touch)
          }));
        }
      }
      function check(label, expected, run) {
        moves.length = 0;
        run();
        if (JSON.stringify(moves) !== JSON.stringify(expected)) {
          throw new Error(label + ': expected ' + JSON.stringify(expected) + ', got ' + JSON.stringify(moves));
        }
        passed.push(label);
      }
      function swipe(dx, dy) {
        send('start', [contact(1)], [contact(1)]);
        send('end', [], [contact(1, 100 + dx, 100 + dy)]);
      }
      check('orphan release', [], () => send('end', [], [contact(1, 150)]));
      check('four directions', [0,1,2,3], () => {
        swipe(0,-11); swipe(11,0); swipe(0,11); swipe(-11,0);
      });
      check('strict threshold on both axes', [], () => {
        swipe(0,0); swipe(10,0); swipe(-10,0); swipe(0,10); swipe(0,-10); swipe(10,10);
      });
      check('fraction above threshold and vertical tie', [1,2,0], () => {
        swipe(10.5,0); swipe(11,11); swipe(-11,-11);
      });
      check('duplicate release', [1], () => {
        swipe(20,0); send('end', [], [contact(1, 160)]);
      });
      check('cancel then release and recovery', [3], () => {
        send('start', [contact(1)], [contact(1)]);
        send('cancel', [], [contact(1)]);
        send('end', [], [contact(1,150)]);
        swipe(-20,0);
      });
      check('second finger, staggered releases and recovery', [2], () => {
        send('start', [contact(1)], [contact(1)]);
        send('start', [contact(1),contact(2)], [contact(2)]);
        send('end', [contact(2)], [contact(1,150)]);
        send('end', [], [contact(2,150)]);
        swipe(0,20);
      });
      check('simultaneous fingers and recovery', [0], () => {
        send('start', [contact(1),contact(2)], [contact(1),contact(2)]);
        send('end', [], [contact(1,150),contact(2,150)]);
        swipe(0,-20);
      });
      check('multi-touch cancellation and recovery', [1], () => {
        send('start', [contact(1)], [contact(1)]);
        send('start', [contact(1),contact(2)], [contact(2)]);
        send('cancel', [contact(1)], [contact(2)]);
        send('end', [], [contact(1,150)]);
        swipe(20,0);
      });
      if (!pointerMode) {
        check('multi-touch first observed on move', [1], () => {
          send('start', [contact(1)], [contact(1)]);
          send('move', [contact(1),contact(2)], [contact(2)]);
          send('end', [contact(1)], [contact(2,150)]);
          send('end', [], [contact(1,150)]);
          swipe(20,0);
        });
        check('wrong contact release and recovery', [1], () => {
          send('start', [contact(1)], [contact(1)]);
          send('end', [], [contact(2,150)]);
          swipe(20,0);
        });
      }
      check('keyboard mapping and modifier guard', [0,1,2,3], () => {
        for (const which of [38,39,40,37]) {
          document.dispatchEvent(new KeyboardEvent('keydown', {which, keyCode:which, bubbles:true}));
        }
        document.dispatchEvent(new KeyboardEvent('keydown', {which:39, keyCode:39, ctrlKey:true, bubbles:true}));
      });
      return passed;
    }, pointerMode);
    assert.deepEqual(errors, []);
    console.log(`${pointerMode ? 'Legacy pointer' : 'Touch'}: ${passed.length} checks passed`);
    for (const name of passed) console.log(`  ${name}`);
  } finally {
    await game.close();
  }
}
(async () => { await checkMode(false); await checkMode(true); })().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
