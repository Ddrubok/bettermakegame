Fixed swipe lifecycle handling in `js/keyboard_input_manager.js`: cancelled or multi-touch gestures cannot reuse stale coordinates, and valid gestures emit once. Direction mapping, threshold, keyboard controls, and game rules remain unchanged.

Added `swipe-check.cjs`; all 22 browser checks passed. The supplied smoke check and JavaScript syntax check also passed.

Limit: touch and legacy pointer events were simulated in Chromium; physical devices and IE were not tested.