const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Control elapsed time explicitly, without racing the live animation loop.
  const game = await openGame(__dirname, () => { window.requestAnimationFrame = () => 0; });
  try {
    const results = await game.page.evaluate(() => {
      const checks = [];
      function check(name, condition) {
        if (!condition) throw new Error(name);
        checks.push(name);
      }
      function setup(target = 1000) {
        play();
        addScore(target);
      }
      for (const hz of [30, 60, 120, 144, 240]) {
        setup();
        for (let frame = 0; frame < hz; frame++) update(1 / hz);
        drawScore();
        check(`${hz} Hz: 60 points per second`, Math.abs(vscore - 60) < 1e-9);
        check(`${hz} Hz: real score preserved`, score === 1000);
        check(`${hz} Hz: integer HUD`, get('score').textContent === ('00000' + Math.floor(vscore)).slice(-5));
      }
      setup();
      update(0);
      check('zero elapsed time does not advance or snap', vscore === 0);
      update(1 / 240);
      drawScore();
      check('short frame retains fractional progress', vscore === 0.25 && get('score').textContent === '00000');
      for (let n = 0; n < 3; n++) update(1 / 240);
      drawScore();
      check('fractional progress accumulates into a displayed point', vscore === 1 && get('score').textContent === '00001');
      setup();
      for (const elapsed of [0.003, 0.017, 0.08, 0.2, 0.4, 0.3]) update(elapsed);
      check('uneven frames preserve the rate', Math.abs(vscore - 60) < 1e-9);
      setup(7);
      update(1);
      check('long frame clamps to target', vscore === 7 && score === 7);
      update(0.1);
      addScore(10);
      update(1 / 120);
      check('caught-up time is not banked for later awards', vscore === 7.5 && score === 17);
      lose();
      drawScore();
      check('game over snaps to final score', !playing && vscore === 17 && get('score').textContent === '00017');
      update(1);
      check('inactive update leaves score unchanged', vscore === 17 && score === 17);
      play();
      drawScore();
      check('restart resets score and fractional progress', score === 0 && vscore === 0 && get('score').textContent === '00000');
      setCurrentPiece({ type: o, dir: DIR.UP, x: 4, y: 0 });
      update(0.6);
      check('gravity retains its existing strict threshold', current.y === 0);
      update(0.001);
      check('gravity drops after threshold', current.y === 1 && Math.abs(dt - 0.001) < 1e-9);
      keydown({ keyCode: KEY.LEFT, preventDefault() {} });
      update(0);
      check('queued movement still works', current.x === 3);
      setCurrentPiece({ type: o, dir: DIR.UP, x: 4, y: 18 });
      drop();
      check('locking still awards ten points', score === 10);
      clearBlocks();
      for (let x = 0; x < nx; x++) setBlock(x, 19, o);
      removeLines();
      check('line clearing preserves reward and speed', score === 110 && rows === 1 && step === 0.595 && !getBlock(0, 19));
      keydown({ keyCode: KEY.ESC, preventDefault() {} });
      check('Escape still ends game and snaps score', !playing && vscore === 110);
      return checks;
    });
    assert.ok(results.length > 0);
    console.log(`PASS: ${results.length} browser checks\n${results.join('\n')}`);
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
