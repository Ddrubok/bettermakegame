Updated `index.html` to advance the displayed score at 60 points per second, retain fractional progress, prevent overshoot, and preserve integer rendering and the end-game snap.

Added `score-check.cjs`: reproduced the original failure, then passed 30 browser checks covering refresh rates, boundaries, restart, gravity, controls, and scoring. `node smoke.cjs` also passed.

Limits: refresh rates were simulated; physical displays weren’t tested. The existing elapsed-time cap remains unchanged.