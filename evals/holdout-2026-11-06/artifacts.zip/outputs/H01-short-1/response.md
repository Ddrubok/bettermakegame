Fixed `js/keyboard_input_manager.js` to ignore game shortcuts in inputs, textareas, and contenteditable elements, including nested spans.

Added `keyboard-routing-check.cjs`. Confirmed it failed before the fix and passes afterward: 128 routing cases plus typing, caret movement, board preservation, focus changes, and restart controls. `node smoke.cjs` also passed.

Validation used Chromium; touch checks used synthetic events. Supplied task, guidance, and helper files remain unchanged.