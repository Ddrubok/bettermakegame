const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    const { page } = game;
    await page.waitForSelector('.tile');
    await page.evaluate(() => {
      window.gameEvents = [];
      const emit = KeyboardInputManager.prototype.emit;
      KeyboardInputManager.prototype.emit = function (name, data) {
        window.gameEvents.push({ name, data });
        return emit.call(this, name, data);
      };
      const fixture = document.createElement('div');
      fixture.innerHTML = '<input id="nickname"><textarea id="notes"></textarea>' +
        '<div id="editor" contenteditable="true"><span id="nested">text</span>' +
        '<span id="locked" contenteditable="false">locked</span></div>' +
        '<div id="plain" tabindex="0">outside</div>';
      document.body.appendChild(fixture);
    });

    const dispatch = (selector, code, modifiers = {}) => page.evaluate(
      ({ selector, code, modifiers }) => {
        window.gameEvents = [];
        const event = new KeyboardEvent('keydown', {
          bubbles: true, cancelable: true, keyCode: code, which: code, ...modifiers
        });
        document.querySelector(selector).dispatchEvent(event);
        return { prevented: event.defaultPrevented, events: window.gameEvents };
      }, { selector, code, modifiers });

    const directions = { 38: 0, 39: 1, 40: 2, 37: 3, 75: 0, 76: 1,
      74: 2, 72: 3, 87: 0, 68: 1, 83: 2, 65: 3 };
    const ignored = { prevented: false, events: [] };
    let cases = 0;
    for (const selector of ['#nickname', '#notes', '#editor', '#nested']) {
      for (const code of [...Object.keys(directions).map(Number), 82]) {
        assert.deepEqual(await dispatch(selector, code), ignored, `${selector}: ${code}`);
        cases++;
      }
    }
    for (const selector of ['#plain', '#locked']) {
      for (const [code, direction] of Object.entries(directions)) {
        assert.deepEqual(await dispatch(selector, Number(code)), {
          prevented: true, events: [{ name: 'move', data: direction }]
        }, `${selector}: ${code}`);
        cases++;
      }
      assert.deepEqual(await dispatch(selector, 82), {
        prevented: true, events: [{ name: 'restart', data: undefined }]
      });
      assert.deepEqual(await dispatch(selector, 88), ignored);
    }
    for (const modifier of ['altKey', 'ctrlKey', 'metaKey', 'shiftKey']) {
      for (const code of [...Object.keys(directions).map(Number), 82]) {
        assert.deepEqual(await dispatch('#plain', code, { [modifier]: true }), ignored);
        cases++;
      }
    }

    for (const selector of ['#nickname', '#notes', '#editor']) {
      await page.locator(selector).fill('');
      await page.locator(selector).focus();
      const before = await page.evaluate(() => {
        window.gameEvents = [];
        return localStorage.getItem('gameState');
      });
      await page.keyboard.type('wasdhjklr');
      await page.keyboard.press('ArrowLeft');
      await page.keyboard.type('x');
      const value = await page.locator(selector).evaluate(el =>
        el.isContentEditable ? el.textContent : el.value);
      assert.equal(value, 'wasdhjklxr', `${selector}: native typing and caret movement`);
      assert.deepEqual(await page.evaluate(() => window.gameEvents), []);
      assert.equal(await page.evaluate(() => localStorage.getItem('gameState')), before);
    }
    await page.locator('#plain').focus();
    await page.evaluate(() => { window.gameEvents = []; });
    await page.keyboard.press('w');
    await page.keyboard.press('r');
    assert.deepEqual(await page.evaluate(() => window.gameEvents), [
      { name: 'move', data: 0 }, { name: 'restart', data: undefined }
    ]);

    // The handler must consult current editability, without cached focus state.
    await page.locator('#plain').evaluate(el => { el.contentEditable = 'true'; });
    assert.deepEqual(await dispatch('#plain', 82), ignored);
    await page.locator('#plain').evaluate(el => { el.contentEditable = 'false'; });
    assert.equal((await dispatch('#plain', 82)).events[0].name, 'restart');

    for (const selector of ['.restart-button', '.retry-button']) {
      for (const type of ['click', 'touchend']) {
        await page.locator('#nickname').focus();
        const result = await page.evaluate(({ selector, type }) => {
          window.gameEvents = [];
          const event = new Event(type, { bubbles: true, cancelable: true });
          document.querySelector(selector).dispatchEvent(event);
          return { prevented: event.defaultPrevented, events: window.gameEvents };
        }, { selector, type });
        assert.deepEqual(result, {
          prevented: true, events: [{ name: 'restart', data: undefined }]
        });
      }
    }
    console.log(`PASS: ${cases} key-routing cases; native typing/caret behavior; board preservation; focus and editability changes; restart click/touch controls.`);
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
