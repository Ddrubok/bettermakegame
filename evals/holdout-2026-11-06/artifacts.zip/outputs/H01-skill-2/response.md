Fixed `js/keyboard_input_manager.js` so inputs, textareas, and contenteditable elements—including nested spans—keep normal keyboard behavior.

Added `keyboard-routing-check.cjs`. Reproduced the original typing failure, then passed real typing/caret/newline checks and 256 routing checks covering shortcuts, modifiers, and restart controls. Smoke and syntax checks also passed.

Verification used Chromium; touch button checks were simulated. Supplied files remain unchanged.