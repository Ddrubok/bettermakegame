const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    const { page } = game;
    await page.waitForSelector('.tile');
    await page.evaluate(() => {
      window.routedEvents = [];
      const emit = KeyboardInputManager.prototype.emit;
      KeyboardInputManager.prototype.emit = function (name, value) {
        window.routedEvents.push([name, value]);
        return emit.call(this, name, value);
      };
      const fixtures = document.createElement('div');
      fixtures.innerHTML = '<input id="nickname"><textarea id="notes"></textarea>' +
        '<div id="editor" contenteditable="true"><span id="nested">text</span></div>' +
        '<div contenteditable="true"><span id="readonly" contenteditable="false" tabindex="0">fixed</span></div>' +
        '<button id="outside">Outside editor</button>';
      document.body.appendChild(fixtures);
    });

    // Real browser typing must insert letters without emitting game actions.
    for (const selector of ['#nickname', '#notes', '#editor']) {
      await page.locator(selector).fill('');
      await page.evaluate(() => { window.routedEvents = []; });
      await page.locator(selector).focus();
      for (const letter of 'wasdhjklr') await page.keyboard.press(letter);
      assert.equal(await page.locator(selector).evaluate(el =>
        el.value === undefined ? el.textContent : el.value), 'wasdhjklr', selector);
      assert.deepEqual(await page.evaluate(() => window.routedEvents), [], selector);
    }

    // Native caret movement and textarea newlines remain available.
    await page.locator('#nickname').evaluate(el => {
      el.focus();
      el.setSelectionRange(el.value.length, el.value.length);
    });
    await page.keyboard.press('ArrowLeft');
    assert.equal(await page.locator('#nickname').evaluate(el => el.selectionStart), 8);
    await page.locator('#notes').evaluate(el => {
      el.focus();
      el.setSelectionRange(el.value.length, el.value.length);
    });
    await page.keyboard.press('Enter');
    assert.equal(await page.locator('#notes').inputValue(), 'wasdhjklr\n');

    const result = await page.evaluate(() => {
      // Restore a nested target after the real typing check replaced its contents.
      document.querySelector('#editor').innerHTML = '<span id="nested">text</span>';
      const mappings = [[38, 0], [39, 1], [40, 2], [37, 3],
        [75, 0], [76, 1], [74, 2], [72, 3], [87, 0], [68, 1], [83, 2], [65, 3]];
      const checks = [];
      function key(target, code, modifiers = {}) {
        window.routedEvents = [];
        const event = new KeyboardEvent('keydown', Object.assign({
          bubbles: true, cancelable: true, keyCode: code, which: code
        }, modifiers));
        target.dispatchEvent(event);
        return { prevented: event.defaultPrevented, events: window.routedEvents.slice() };
      }
      for (const selector of ['#nickname', '#notes', '#editor', '#nested']) {
        for (const code of [...mappings.map(pair => pair[0]), 82]) {
          checks.push({ label: selector + ':' + code,
            actual: key(document.querySelector(selector), code),
            expected: { prevented: false, events: [] } });
        }
      }
      for (const target of [document.body, document.querySelector('#outside'), document.querySelector('#readonly')]) {
        for (const [code, direction] of mappings) {
          checks.push({ label: 'outside:' + code,
            actual: key(target, code),
            expected: { prevented: true, events: [['move', direction]] } });
        }
        checks.push({ label: 'restart', actual: key(target, 82),
          expected: { prevented: true, events: [['restart', undefined]] } });
        for (const modifier of ['altKey', 'ctrlKey', 'metaKey', 'shiftKey']) {
          for (const code of [...mappings.map(pair => pair[0]), 82]) {
            checks.push({ label: modifier + ':' + code,
              actual: key(target, code, { [modifier]: true }),
              expected: { prevented: false, events: [] } });
          }
        }
        checks.push({ label: 'unmapped', actual: key(target, 88),
          expected: { prevented: false, events: [] } });
      }
      // Existing click and touch bindings also work while an editor has focus.
      for (const [selector, name] of [['.restart-button', 'restart'], ['.retry-button', 'restart'], ['.keep-playing-button', 'keepPlaying']]) {
        for (const type of ['click', 'touchend']) {
          document.querySelector('#nickname').focus();
          window.routedEvents = [];
          const event = new Event(type, { bubbles: true, cancelable: true });
          document.querySelector(selector).dispatchEvent(event);
          checks.push({ label: selector + ':' + type,
            actual: { prevented: event.defaultPrevented, events: window.routedEvents.slice() },
            expected: { prevented: true, events: [[name, undefined]] } });
        }
      }
      return checks;
    });
    for (const check of result) assert.deepEqual(check.actual, check.expected, check.label);
    console.log(`PASS: real typing/caret/newline checks and ${result.length} routing checks`);
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
