const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Advance updates explicitly so boundary checks do not race the game loop.
  const game = await openGame(__dirname, () => {
    window.requestAnimationFrame = () => 0;
  });
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    const cases = [
      [0, '00000'], [7, '00007'], [42, '00042'], [9999, '09999'],
      [10000, '10000'], [99999, '99999'], [100000, '100000'],
      [1234567, '1234567'], [4294967296, '4294967296'],
      [Number.MAX_SAFE_INTEGER, '9007199254740991']
    ];
    for (const [value, expected] of cases) {
      const result = await game.page.evaluate(value => {
        setScore(value);
        drawScore();
        return { text: get('score').textContent, score, vscore, dirty: invalid.score };
      }, value);
      assert.deepEqual(result, { text: expected, score: value, vscore: value, dirty: false });
    }

    const animation = await game.page.evaluate(() => {
      play();
      setScore(99998);
      addScore(5);
      const frames = [];
      for (let frame = 0; frame < 7; frame++) {
        drawScore();
        frames.push({ text: get('score').textContent, score, vscore });
        update(0);
      }
      return frames;
    });
    assert.deepEqual(animation, [99998, 99999, 100000, 100001, 100002, 100003, 100003]
      .map(value => ({ text: String(value), score: 100003, vscore: value })));

    const lifecycle = await game.page.evaluate(() => {
      addScore(100);
      lose();
      drawScore();
      const lost = { text: get('score').textContent, score, vscore, playing };
      play();
      drawScore();
      return { lost, restarted: { text: get('score').textContent, score, vscore, playing } };
    });
    assert.deepEqual(lifecycle, {
      lost: { text: '100103', score: 100103, vscore: 100103, playing: false },
      restarted: { text: '00000', score: 0, vscore: 0, playing: true }
    });

    for (const viewport of [{ width: 320, height: 568 }, { width: 1000, height: 900 }]) {
      await game.page.setViewportSize(viewport);
      const bounds = await game.page.evaluate(() => {
        setScore(1234567);
        drawScore();
        const rect = get('score').getBoundingClientRect();
        const menu = get('menu').getBoundingClientRect();
        return { text: get('score').textContent, left: rect.left, right: rect.right,
          top: rect.top, bottom: rect.bottom, menuLeft: menu.left, menuRight: menu.right };
      });
      assert.equal(bounds.text, '1234567');
      assert.ok(bounds.left >= bounds.menuLeft && bounds.right <= bounds.menuRight,
        'Seven-digit score should fit inside the existing menu');
      assert.ok(bounds.top >= 0 && bounds.bottom <= viewport.height,
        'Score should remain inside the viewport');
    }
    assert.deepEqual(errors, []);
    console.log('PASS: padding, large integers, count-up boundary, authoritative score, loss/restart, and mobile/desktop HUD bounds.');
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
