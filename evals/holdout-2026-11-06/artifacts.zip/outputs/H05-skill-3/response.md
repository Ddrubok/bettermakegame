Fixed `index.html` to retain all score digits while padding smaller scores to five digits. Scoring, count-up animation, and layout remain unchanged.

Added `score-check.cjs`; it reproduced the original failure at 100000 and now passes padding, large-number, animation, loss/restart, and mobile/desktop bounds checks. `node smoke.cjs` also passed.

Limits: Chromium only; no extended gameplay testing. Supplied guidance, helper, and skill files remain unchanged.