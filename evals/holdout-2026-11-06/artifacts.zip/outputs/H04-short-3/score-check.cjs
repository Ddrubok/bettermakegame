const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Disable automatic frames so each browser update has a controlled elapsed time.
  const game = await openGame(__dirname, () => {
    window.requestAnimationFrame = () => 0;
  });
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    const results = await game.page.evaluate(() => {
      const passed = [];
      function check(condition, label) {
        if (!condition) throw new Error(label);
        passed.push(label);
      }
      function near(actual, expected) { return Math.abs(actual - expected) < 1e-9; }
      function begin(target = 1000) { play(); addScore(target); }
      function rendered() { drawScore(); return document.getElementById('score').textContent; }

      for (const hz of [20, 30, 60, 120, 144, 240]) {
        begin();
        for (let frame = 0; frame < hz; frame++) update(1 / hz);
        check(near(vscore, 60) && score === 1000, `${hz} Hz: 60 points per second, awarded score unchanged`);
        check(/^\d{5}$/.test(rendered()) && Number(rendered()) === Math.floor(vscore), `${hz} Hz: integral rendering`);
      }

      begin();
      for (const seconds of [0.001, 0.004, 0.02, 0.175, 0.3]) update(seconds);
      check(near(vscore, 30), 'uneven frame durations accumulate elapsed time');
      begin(10);
      update(0);
      check(vscore === 0 && rendered() === '00000', 'zero elapsed time does not snap to target');
      update(0.005);
      check(near(vscore, 0.3) && rendered() === '00000', 'sub-point progress is retained but not rendered');
      update(0.015);
      check(near(vscore, 1.2) && rendered() === '00001', 'short frames combine to advance the display');
      update(1);
      check(vscore === 10 && score === 10 && rendered() === '00010', 'long update clamps to the real score');
      update(0.1);
      addScore(10);
      update(0.005);
      check(near(vscore, 10.3), 'time at the target is not banked toward future awards');

      begin();
      update(0.005);
      lose();
      check(!playing && vscore === score && rendered() === '01000', 'end game snaps to final score');
      update(0.5);
      check(vscore === 1000, 'inactive game leaves score unchanged');
      play();
      check(score === 0 && vscore === 0 && rendered() === '00000', 'restart resets fractional progress and displayed score');
      addScore(10);
      update(0.005);
      check(near(vscore, 0.3), 'restart has no leftover fractional progress');

      play();
      const initialY = current.y;
      update(0.3);
      check(current.y === initialY, 'gravity does not drop before its interval');
      update(0.31);
      check(current.y === initialY + 1 && near(dt, 0.01), 'gravity retains its interval and remainder');
      current = { type: o, dir: DIR.UP, x: 4, y: 18 };
      drop();
      check(score === 10, 'locking a piece still awards 10 points');

      for (let count = 1; count <= 4; count++) {
        play();
        for (let y = ny - count; y < ny; y++)
          for (let x = 0; x < nx; x++) setBlock(x, y, o);
        removeLines();
        check(rows === count && score === 100 * Math.pow(2, count - 1), `${count} line clear retains awarded points`);
        check(!getBlock(0, ny - 1), `${count} line clear removes filled rows`);
      }

      play();
      current = { type: t, dir: DIR.UP, x: 4, y: 0 };
      keydown({ keyCode: KEY.LEFT, preventDefault() {} });
      update(0);
      check(current.x === 3, 'queued movement still works with zero elapsed time');
      keydown({ keyCode: KEY.UP, preventDefault() {} });
      update(0);
      check(current.dir === DIR.RIGHT, 'rotation control still works');
      keydown({ keyCode: KEY.DOWN, preventDefault() {} });
      update(0);
      check(current.y === 1, 'manual drop still works');
      addScore(10);
      keydown({ keyCode: KEY.ESC, preventDefault() {} });
      check(!playing && vscore === 10, 'Escape still ends the game and snaps the score');
      keydown({ keyCode: KEY.SPACE, preventDefault() {} });
      check(playing && score === 0 && vscore === 0, 'Space still restarts the game');
      return passed;
    });
    assert.deepEqual(errors, [], 'browser runtime errors');
    console.log(`Passed ${results.length} browser assertions:\n${results.join('\n')}`);
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
