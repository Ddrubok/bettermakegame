Updated `index.html` to count up at 60 points per elapsed second, retain fractional progress, and clamp to the real score. Integer rendering and end-game snapping remain intact.

Checks passed: 38 assertions in `node score-check.cjs` and the supplied `node smoke.cjs` check.

Limits: refresh rates were simulated in Chromium; the existing one-second elapsed-time cap remains unchanged. Supplied files were left unchanged.