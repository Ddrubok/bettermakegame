const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    await game.page.waitForSelector('.tile');
    const results = await game.page.evaluate(() => {
      const nativeRAF = window.requestAnimationFrame;
      let queue = [];
      window.requestAnimationFrame = callback => queue.push(callback);
      const frame = () => {
        const pending = queue;
        queue = [];
        pending.forEach(callback => callback());
      };
      const check = (value, label) => {
        if (!value) throw new Error(label);
      };
      const message = document.querySelector('.game-message');
      const hidden = () => !message.classList.contains('game-won') &&
        !message.classList.contains('game-over');
      const score = () => document.querySelector('.score-container').firstChild.textContent;
      const best = () => document.querySelector('.best-container').textContent;
      const results = [];
      function Input() {}
      Input.prototype.on = function () {};
      function Storage() { this.best = 0; }
      Storage.prototype.getGameState = function () { return null; };
      Storage.prototype.setGameState = Storage.prototype.clearGameState = function () {};
      Storage.prototype.getBestScore = function () { return this.best; };
      Storage.prototype.setBestScore = function (value) { this.best = value; };
      const makeGame = () => {
        queue = [];
        const manager = new GameManager(4, Input, HTMLActuator, Storage);
        manager.actuator.clearMessage();
        frame();
        return manager;
      };
      const terminal = (manager, won) => {
        manager.grid = new Grid(4);
        manager.grid.insertTile(new Tile({ x: 0, y: 0 }, won ? 2048 : 4));
        manager.score = 2048;
        manager.won = won;
        manager.over = !won;
        manager.actuate();
      };
      try {
        for (const won of [true, false]) {
          const manager = makeGame();
          terminal(manager, won);
          manager.restart();
          frame();
          check(hidden(), `queued ${won ? 'win' : 'loss'} survives restart`);
          check(score() === '0' && best() === '2048', 'restart score/best');
          check(document.querySelectorAll('.tile').length === 2, 'restart board');
          terminal(manager, !won);
          frame();
          check(message.classList.contains(won ? 'game-over' : 'game-won'), 'later terminal missing');
          check(message.querySelector('p').textContent === (won ? 'Game over!' : 'You win!'), 'later message text');
          manager.restart();
          check(hidden(), 'visible message not immediately cleared');
          frame();
          results.push(`restart after queued ${won ? 'win' : 'loss'}, later terminal, visible cleanup`);
        }

        const manager = makeGame();
        terminal(manager, true);
        GameManager.prototype.keepPlaying.call(manager);
        check(queue.length === 1, 'keep playing unexpectedly schedules a render');
        frame();
        check(hidden(), 'queued win survives keep playing');
        check(score() === '2048' && best() === '2048', 'continued score/best lost');
        check(document.querySelector('.tile-2048'), 'continued board lost');
        check(document.querySelector('.score-addition').textContent === '+2048', 'score feedback lost');
        terminal(manager, false);
        frame();
        check(message.classList.contains('game-over'), 'loss after keep playing missing');
        results.push('keep playing without another render; board, score feedback and later loss');

        const actuator = manager.actuator;
        actuator.clearMessage();
        const grid = new Grid(4);
        const moving = new Tile({ x: 1, y: 0 }, 2);
        moving.previousPosition = { x: 0, y: 0 };
        grid.insertTile(moving);
        const merged = new Tile({ x: 2, y: 1 }, 8);
        merged.mergedFrom = [new Tile({ x: 2, y: 1 }, 4), new Tile({ x: 2, y: 2 }, 4)];
        grid.insertTile(merged);
        grid.insertTile(new Tile({ x: 3, y: 3 }, 4096));
        actuator.actuate(grid, { score: 2056, bestScore: 2056, terminated: true, won: true });
        actuator.clearMessage();
        actuator.clearMessage();
        frame();
        check(hidden(), 'direct/repeated clear allows stale message');
        check(document.querySelector('.tile-2.tile-position-1-1'), 'movement start lost');
        check(document.querySelector('.tile-8.tile-merged'), 'merge feedback lost');
        check(document.querySelectorAll('.tile-4').length === 2, 'merge source tiles lost');
        check(document.querySelector('.tile-4096.tile-new.tile-super'), 'spawn/super feedback lost');
        check(document.querySelector('.score-addition').textContent === '+8', 'score delta lost');
        check(score() === '2056' && best() === '2056', 'current score/best lost');
        frame();
        check(document.querySelector('.tile-2.tile-position-2-1'), 'movement destination lost');
        results.push('repeated direct clear; movement, merge, spawn, super tile and score delta');

        // Multiple old lifecycles must not interfere with a newly queued terminal.
        for (let i = 0; i < 3; i++) {
          actuator.actuate(grid, { score: 2056, bestScore: 2056, terminated: true, over: true });
          actuator.continueGame();
        }
        actuator.actuate(grid, { score: 2056, bestScore: 2056, terminated: true, won: true });
        frame();
        check(message.classList.contains('game-won') && !message.classList.contains('game-over'), 'new terminal corrupted by obsolete callbacks');
        check(!document.querySelector('.score-addition'), 'unchanged score adds feedback');
        results.push('multiple obsolete lifecycles and fresh terminal in the same frame');
        return results;
      } finally {
        window.requestAnimationFrame = nativeRAF;
      }
    });
    assert.equal(results.length, 5);
    results.forEach(result => console.log(`PASS ${result}`));
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
