Fixed `js/html_actuator.js` so clearing a terminal message invalidates older queued message writes. Later win/loss messages, board rendering, scores, and tile feedback remain functional. GameManager and supplied files are unchanged.

Checks:
- Added `lifecycle-check.cjs`; reproduced the original failure, then passed all five browser regression groups.
- `node smoke.cjs` passed.
- JavaScript syntax check passed.

Limit: regression checks control frame timing in Chromium; animation appearance was not manually assessed.