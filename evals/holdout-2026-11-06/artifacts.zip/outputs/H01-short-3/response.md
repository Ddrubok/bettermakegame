Added an early editor guard in `js/keyboard_input_manager.js`, preserving typing in inputs, textareas, and nested contenteditable elements while retaining game shortcuts and restart controls.

Added `keyboard-routing-check.cjs`: reproduced the original failure, then passed 585 routing/modifier cases plus native typing, caret, focus-transition, and button checks. `node smoke.cjs` also passed.

Verification used Chromium only. Supplied task, guidance, and helper files remain unchanged.