const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  const { page } = game;
  try {
    await page.waitForSelector('.tile');
    await page.evaluate(() => {
      window.routedEvents = [];
      const emit = KeyboardInputManager.prototype.emit;
      KeyboardInputManager.prototype.emit = function (name, data) {
        window.routedEvents.push([name, data]);
        return emit.call(this, name, data);
      };
      const fixture = document.createElement('div');
      fixture.innerHTML = '<input id="nickname"><textarea id="notes"></textarea>' +
        '<div id="editor" contenteditable="true"><span id="nested">text</span>' +
        '<span id="noneditable" contenteditable="false" tabindex="0">fixed</span></div>' +
        '<div id="plain" tabindex="0">outside</div>' +
        '<div id="plaintext" contenteditable="plaintext-only">text</div>';
      document.body.appendChild(fixture);
    });

    // Check cancellation and routing for every shortcut, including nested targets.
    const results = await page.evaluate(() => {
      const keys = [38, 39, 40, 37, 75, 76, 74, 72, 87, 68, 83, 65, 82];
      const rows = [];
      for (const id of ['nickname', 'notes', 'editor', 'nested', 'plaintext']) {
        for (const which of keys) {
          for (const modifier of [null, 'altKey', 'ctrlKey', 'metaKey', 'shiftKey']) {
            window.routedEvents = [];
            const event = new KeyboardEvent('keydown', {
              bubbles: true, cancelable: true, keyCode: which, which,
              ...(modifier ? { [modifier]: true } : {})
            });
            document.getElementById(id).dispatchEvent(event);
            rows.push({ id, which, modifier, canceled: event.defaultPrevented,
              events: window.routedEvents.slice() });
          }
        }
      }
      return rows;
    });
    for (const row of results) {
      assert.equal(row.canceled, false, JSON.stringify(row));
      assert.deepEqual(row.events, [], JSON.stringify(row));
    }

    // Real keyboard input must retain native text insertion and caret movement.
    for (const id of ['nickname', 'notes', 'editor', 'plaintext']) {
      await page.locator('#' + id).fill('');
      await page.evaluate(() => { window.routedEvents = []; });
      await page.locator('#' + id).pressSequentially('wasdhjklr');
      await page.keyboard.press('ArrowLeft');
      await page.keyboard.press('Backspace');
      const value = await page.locator('#' + id).evaluate(el =>
        el.matches('input, textarea') ? el.value : el.textContent);
      assert.equal(value, 'wasdhjkr', id);
      assert.deepEqual(await page.evaluate(() => window.routedEvents), [], id);
    }

    // Editing-state changes must take effect immediately without rebinding.
    const outside = await page.evaluate(() => {
      const keys = [[38, 0], [39, 1], [40, 2], [37, 3], [75, 0], [76, 1],
        [74, 2], [72, 3], [87, 0], [68, 1], [83, 2], [65, 3], [82, 'restart']];
      const editor = document.getElementById('editor');
      editor.contentEditable = 'false';
      const island = document.createElement('span');
      island.contentEditable = 'false';
      document.getElementById('plaintext').appendChild(island);
      const rows = [];
      for (const target of [document.body, document.getElementById('plain'), editor, island]) {
        for (const [which, expected] of keys) {
          for (const modifier of [null, 'altKey', 'ctrlKey', 'metaKey', 'shiftKey']) {
            window.routedEvents = [];
            const event = new KeyboardEvent('keydown', {
              bubbles: true, cancelable: true, keyCode: which, which,
              ...(modifier ? { [modifier]: true } : {})
            });
            target.dispatchEvent(event);
            rows.push({ which, expected, modifier, canceled: event.defaultPrevented,
              events: window.routedEvents.slice() });
          }
        }
      }
      editor.contentEditable = 'true';
      return rows;
    });
    for (const row of outside) {
      assert.equal(row.canceled, !row.modifier, JSON.stringify(row));
      assert.deepEqual(row.events, row.modifier ? [] :
        row.expected === 'restart' ? [['restart', undefined]] : [['move', row.expected]],
      JSON.stringify(row));
    }

    await page.locator('#nickname').focus();
    await page.evaluate(() => { window.routedEvents = []; });
    await page.keyboard.press('r');
    await page.locator('#plain').focus();
    await page.keyboard.press('w');
    await page.keyboard.press('r');
    assert.deepEqual(await page.evaluate(() => window.routedEvents),
      [['move', 0], ['restart', undefined]]);

    for (const [selector, name] of [['.restart-button', 'restart'],
      ['.retry-button', 'restart'], ['.keep-playing-button', 'keepPlaying']]) {
      for (const type of ['click', 'touchend']) {
        const result = await page.evaluate(({ selector, type }) => {
          window.routedEvents = [];
          const event = new Event(type, { bubbles: true, cancelable: true });
          document.querySelector(selector).dispatchEvent(event);
          return { events: window.routedEvents, canceled: event.defaultPrevented };
        }, { selector, type });
        assert.equal(result.canceled, true);
        assert.deepEqual(result.events, [[name, undefined]]);
      }
    }
    console.log(`PASS: ${results.length} editor cases, ${outside.length} outside/modifier cases, native typing/caret behavior, focus transitions, and six button events`);
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
