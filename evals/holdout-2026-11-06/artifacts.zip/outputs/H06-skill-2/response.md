Review complete; game source and supplied files are unchanged.

- Repeated pieces and 100/200/400/800 awards match the designer’s intent.
- Confirmed defects: selection excludes the last pool entry until forced, making every refill end in Z; completed top rows can be skipped.
- Both `node smoke.cjs` and `node review-check.cjs` passed. Focused checks covered 100 pools, scoring, lock bonuses, HUD catch-up, and row boundaries. Defect assertions reproduce existing bugs.
- Natural playthroughs, subjective fairness, real-time animation, and other browsers remain untested.

Added verification evidence and a [review with optional alternatives](C:/Users/DooBokWie/orca/projects/Default/.skill-validation/bmg-comparison-2026-11-06/sessions/H06-skill-2/REVIEW.md).