# Focused review: piece selection and line-clear scoring

The playtester's two observations do not, by themselves, establish a broken game. Repeated pieces are compatible with the designer's four-of-each pool, and nonlinear line awards are explicitly intended. The implementation preserves both the pool totals and the award formula. Focused checks nevertheless demonstrate a selection bias and a top-row clearing defect. No game source or supplied task, guidance, helper, or skill files were changed.

## Intended behavior supported

- **28 draws per refill, four of each type:** `index.html:160–165` refills only an empty pool, then removes one entry per draw. All 100 seeded pools tested in Chromium contained exactly four I/J/L/O/S/T/Z pieces and were empty after draw 28. Repeats occurred during these checks. Four copies permit adjacent identical pieces; this is not a seven-piece bag and does not promise one of each type every seven draws. Refill boundaries can also permit repeats.
- **100/200/400/800 line awards:** `index.html:333–350` uses `100 * 2^(n-1)` when at least one row clears. Direct fixtures for zero through four bottom rows produced 0/100/200/400/800 and the correct row counts. Calling the clear routine again awarded nothing extra.
- **Lock bonus is separate:** `index.html:313–324` adds 10 on locking before calculating line awards. Valid vertical-I lock fixtures clearing zero through four rows therefore produced total increases of 10/110/210/410/810. This does not contradict the stated line-clear awards; the task does not specify whether the independent lock bonus is desired.
- **The HUD is delayed:** `index.html:265–268` advances the visual score by one per update. With automatic animation frozen, explicit zero-time updates brought each tested lock's displayed score and row count to the correct totals. An immediate HUD reading can understate an award. These checks establish update behavior, not real-time animation duration or usability.

The pool and queued preview persist through reset (`index.html:255–263`); startup also draws pieces. A player's first 28 visible pieces need not align with an actual refill. Pool-total claims here refer to generator refill boundaries.

## Demonstrated defects

1. **The final pool entry is excluded from selection until it stands alone.** `random(0, pieces.length - 1)` produces a fractional value below the last index, and `splice` truncates that value (`index.html:54,164`). For a pool of length greater than one, the final entry is never selected. The refill's final entry is Z, so every complete refill ends in Z. All 100 seeded pools reproduced this; a two-entry `[I,Z]` pool also drew I first at five controlled random values spanning zero to just below one. Equal per-refill counts survive, but ordering is biased. This is distinct from normal repeated pieces. If repaired later, a uniform integer index over all remaining entries would preserve the designer's 28-piece rule; a seven-bag conversion is unnecessary.

2. **A full top row is not cleared or scored when it is the only completed row.** The board uses rows 0–19, but the clear loop scans 20 down through 1 (`index.html:335`). Controlled full-row fixtures cleared rows 1 and 19 for 100 points, while row 0 remained full with no award. A constructed nonoverlapping, supported O-piece lock also completed row 0: the game remained playing, the full row stayed, and only the 10-point lock bonus was awarded. This is a boundary defect in applying line clears, not an error in the nonlinear award formula. A later repair should scan the playable row range including zero. The fixture was injected; reachability through an ordinary session was not demonstrated.

## Tradeoffs and optional alternatives

Keeping the four-copy pool and existing scoring is consistent with the design. The pool allows more clustering and drought than a seven-piece bag, while preserving totals per refill. A seven-bag alternative would constrain streaks and improve short-term predictability, but changes the intended randomizer and challenge. Fixing the excluded index would remove the demonstrated ordering bias without making that design change.

The current awards give three- and four-row clears a higher return per row, rewarding setup and risk. Linear awards would simplify comparison but remove that deliberate incentive. Neither linear scoring nor a different pool is a required fix. Optional rules text or a separate line-award/lock-bonus indication could explain outcomes; showing the authoritative total immediately would improve immediate readability but change the existing count-up presentation. No usability benefit was measured here.

## Actual checks and limits

- `node smoke.cjs` passed in the supplied headless Chromium setup, reported `Javascript Tetris`, and wrote `smoke.png`. This is a load/screenshot smoke check, not a full playthrough or visual-quality review.
- `node review-check.cjs` passed: Space starts play; 100 seeded full pools; repeats and final-entry bias; controlled two-entry endpoint checks; zero-to-four-row direct clears and actual lock calls; no duplicate award; explicit HUD catch-up; rows 0/1/19; and the constructed top-row lock. No window errors were captured. The helper blocks external requests.
- `review-evidence.json` contains the runtime results. The verification script freezes automatic frames, seeds or substitutes randomness only for selection checks, and injects board fixtures in memory. Assertions for known defects deliberately reproduce current behavior; passing them does **not** mean those behaviors are correct.
- No source repair, package installation, external search, other agents, or broader game audit was performed. Natural-play reproduction, statistical quality of native randomness, subjective fairness, real-time score-animation feel, long sessions/high scores, and other browsers/devices remain untested.

Added review artifacts: `REVIEW.md`, `review-check.cjs`, `review-evidence.json`, and the smoke-generated `smoke.png`.
