const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const { openGame } = require('./browser.cjs');

(async () => {
  // Freeze automatic frames so fixtures and HUD checks are deterministic.
  // The original game functions still run in Chromium, without source edits.
  const game = await openGame(__dirname, () => {
    window.requestAnimationFrame = () => 0;
    window.reviewErrors = [];
    window.addEventListener('error', e => window.reviewErrors.push(e.message));
  });
  try {
    await game.page.keyboard.press('Space');
    assert.equal(await game.page.evaluate(() => playing), true);
    const evidence = await game.page.evaluate(() => {
      const names = ['I', 'J', 'L', 'O', 'S', 'T', 'Z'];
      const types = [i, j, l, o, s, t, z];
      const name = type => names[types.indexOf(type)];
      const originalRandom = Math.random;
      let state = 123456789;
      const bags = [];
      const endpoints = [];
      try {
        Math.random = () => {
          state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
          return state / 4294967296;
        };
        pieces = [];
        for (let b = 0; b < 100; b++) {
          const draws = Array.from({ length: 28 }, () => name(randomPiece().type));
          bags.push({
            counts: names.map(n => draws.filter(d => d === n).length),
            last: draws[27],
            repeats: draws.slice(1).filter((d, k) => d === draws[k]).length,
            remaining: pieces.length,
            ...(b === 0 ? { draws } : {})
          });
        }
        // Isolate the last-index defect with a two-entry pool.
        for (const r of [0, 0.25, 0.5, 0.75, 1 - Number.EPSILON]) {
          Math.random = () => r;
          pieces = [i, z];
          endpoints.push({ random: r, first: name(randomPiece().type), second: name(randomPiece().type) });
        }
      } finally {
        Math.random = originalRandom;
        pieces = [];
      }

      const direct = [];
      const locks = [];
      const fill = y => { for (let x = 0; x < nx; x++) setBlock(x, y, j); };
      for (let n = 0; n <= 4; n++) {
        reset();
        for (let y = ny - n; y < ny; y++) fill(y);
        removeLines();
        const first = { rows, score };
        removeLines();
        direct.push({ n, first, second: { rows, score }, empty: blocks.every(col => col.every(b => !b)) });

        reset();
        playing = true;
        for (let y = ny - n; y < ny; y++) {
          for (let x = 0; x < nx; x++) if (x !== 4) setBlock(x, y, j);
        }
        current = { type: i, dir: DIR.RIGHT, x: 2, y: 16 };
        next = { type: o, dir: DIR.UP, x: 6, y: 0 };
        const validBefore = unoccupied(current.type, current.x, current.y, current.dir);
        drop();
        const immediate = { score, vscore, rows, playing };
        // Check score catch-up without elapsed simulation time or extra input.
        const frames = score;
        for (let frame = 0; frame < frames; frame++) update(0);
        draw();
        locks.push({ n, validBefore, immediate, frames, displayed: get('score').textContent, displayedRows: get('rows').textContent });
      }

      const boundaries = [];
      for (const y of [0, 1, 19]) {
        reset();
        fill(y);
        removeLines();
        boundaries.push({ y, rows, score, remainsFull: Array.from({ length: nx }, (_, x) => !!getBlock(x, y)).every(Boolean) });
      }
      // A legal, supported O lock completes row zero without completing row one.
      reset();
      playing = true;
      for (let x = 2; x < nx; x++) setBlock(x, 0, j);
      setBlock(0, 2, j);
      current = { type: o, dir: DIR.UP, x: 0, y: 0 };
      next = { type: i, dir: DIR.UP, x: 4, y: 0 };
      const validBefore = unoccupied(current.type, current.x, current.y, current.dir);
      drop();
      const topLock = { validBefore, score, rows, playing, topFull: Array.from({ length: nx }, (_, x) => !!getBlock(x, 0)).every(Boolean) };
      return { bags, endpoints, direct, locks, boundaries, topLock, errors: window.reviewErrors };
    });

    assert.deepEqual(evidence.errors, []);
    for (const bag of evidence.bags) {
      assert.deepEqual(bag.counts, [4, 4, 4, 4, 4, 4, 4]);
      assert.equal(bag.remaining, 0);
      assert.equal(bag.last, 'Z'); // Reproduces a defect; not a desired requirement.
    }
    assert.ok(evidence.bags.some(b => b.repeats > 0));
    for (const e of evidence.endpoints) assert.deepEqual([e.first, e.second], ['I', 'Z']);
    const awards = [0, 100, 200, 400, 800];
    for (const e of evidence.direct) {
      assert.deepEqual(e.first, { rows: e.n, score: awards[e.n] });
      assert.deepEqual(e.second, e.first);
      assert.equal(e.empty, true);
    }
    for (const e of evidence.locks) {
      assert.equal(e.validBefore, true);
      assert.deepEqual(e.immediate, { score: awards[e.n] + 10, vscore: 0, rows: e.n, playing: true });
      assert.equal(e.displayed, String(awards[e.n] + 10).padStart(5, '0'));
      assert.equal(e.displayedRows, String(e.n));
    }
    assert.deepEqual(evidence.boundaries, [
      { y: 0, rows: 0, score: 0, remainsFull: true },
      { y: 1, rows: 1, score: 100, remainsFull: false },
      { y: 19, rows: 1, score: 100, remainsFull: false }
    ]);
    assert.deepEqual(evidence.topLock, { validBefore: true, score: 10, rows: 0, playing: true, topFull: true });
    await fs.writeFile('review-evidence.json', JSON.stringify(evidence, null, 2) + '\n');
    console.log('Verified 100 complete pools, repeated pieces, biased final entry, 0-4 row awards, lock bonus, score catch-up, once-only awards, and top-row omission. Known-defect assertions reproduce current behavior.');
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
