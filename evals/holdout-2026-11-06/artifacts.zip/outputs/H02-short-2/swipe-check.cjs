const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

async function check(pointer) {
  const game = await openGame(__dirname, pointer ? () => {
    Object.defineProperty(navigator, 'msPointerEnabled', { value: true });
  } : undefined);
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    await game.page.waitForSelector('.tile');
    const results = await game.page.evaluate(pointer => {
      const target = document.querySelector('.game-container');
      const moves = [];
      const originalEmit = KeyboardInputManager.prototype.emit;
      KeyboardInputManager.prototype.emit = function (name, value) {
        if (name === 'move') moves.push(value);
        else originalEmit.call(this, name, value);
      };
      const contact = (id, x = 100, y = 100) => ({ id, x, y });
      const a = contact(1), b = contact(2);
      function send(kind, changed, current = []) {
        let event;
        if (pointer) {
          event = new Event('MSPointer' + {
            start: 'Down', move: 'Move', end: 'Up', cancel: 'Cancel'
          }[kind], { bubbles: true, cancelable: true });
          Object.assign(event, {
            pointerId: changed.id, pageX: changed.x, pageY: changed.y
          });
        } else {
          const touch = c => new Touch({
            identifier: c.id, target, clientX: c.x, clientY: c.y
          });
          event = new TouchEvent('touch' + kind, {
            bubbles: true, cancelable: true,
            touches: current.map(touch), targetTouches: current.map(touch),
            changedTouches: (Array.isArray(changed) ? changed : [changed]).map(touch)
          });
        }
        target.dispatchEvent(event);
      }
      const results = [];
      function test(name, expected, action) {
        moves.length = 0;
        action();
        const actual = moves.slice();
        // Every lifecycle case must also permit the next clean swipe.
        send('start', contact(99), [contact(99)]);
        send('end', contact(99, 125, 100));
        results.push({ name, actual, expected, recovery: moves.slice(actual.length) });
      }
      for (const [name, dx, dy, expected] of [
        ['right', 11, 0, [1]], ['left', -11, 0, [3]],
        ['down', 0, 11, [2]], ['up', 0, -11, [0]],
        ['horizontal boundary', 10, 0, []], ['negative boundary', -10, 0, []],
        ['vertical boundary', 0, 10, []], ['negative vertical boundary', 0, -10, []],
        ['tap', 0, 0, []], ['below threshold', 9, 9, []],
        ['tie goes down', 11, 11, [2]], ['tie goes up', -11, -11, [0]],
        ['horizontal dominance', 20, 15, [1]]
      ]) test(name, expected, () => {
        send('start', a, [a]);
        send('end', contact(1, 100 + dx, 100 + dy));
      });
      test('orphan end', [], () => send('end', contact(1, 150)));
      test('duplicate end emits once', [1], () => {
        send('start', a, [a]);
        send('end', contact(1, 150));
        send('end', contact(1, 180));
      });
      test('cancel then delayed end', [], () => {
        send('start', a, [a]);
        send('cancel', a);
        send('end', contact(1, 150));
      });
      test('cancel then fresh start', [0], () => {
        send('start', a, [a]);
        send('cancel', a);
        send('start', b, [b]);
        send('end', contact(2, 100, 70));
      });
      for (const reverse of [false, true]) test('two fingers release order ' + reverse, [], () => {
        send('start', a, [a]);
        send('start', b, [a, b]);
        send('end', reverse ? b : a, [reverse ? a : b]);
        send('move', contact(reverse ? 1 : 2, 140), [contact(reverse ? 1 : 2, 140)]);
        send('end', contact(reverse ? 1 : 2, 160));
      });
      test('multi-touch cancel does not rearm remaining contact', [], () => {
        send('start', a, [a]);
        send('start', b, [a, b]);
        send('cancel', b, [a]);
        send('move', contact(1, 140), [contact(1, 140)]);
        send('end', contact(1, 160));
      });
      test('mismatched release invalidates gesture', [], () => {
        send('start', a, [a]);
        send('end', contact(2, 150));
        send('end', contact(1, 150));
      });
      if (!pointer) {
        test('simultaneous multi-touch start', [], () => {
          send('start', [a, b], [a, b]);
          send('end', a, [b]);
          send('end', contact(2, 160));
        });
        test('multi-touch detected on move', [], () => {
          send('start', a, [a]);
          send('move', b, [a, b]);
          send('end', [contact(1, 150), contact(2, 150)]);
        });
        test('multi-touch detected on end', [], () => {
          send('start', a, [a]);
          send('end', contact(2, 150), [a]);
          send('end', contact(1, 150));
        });
        test('multiple changed touches rejected', [], () => {
          send('start', a, [a]);
          send('end', [contact(1, 150), contact(2, 150)]);
        });
      }
      test('keyboard mappings and modifier', [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3], () => {
        for (const code of [38, 39, 40, 37, 75, 76, 74, 72, 87, 68, 83, 65]) {
          document.dispatchEvent(new KeyboardEvent('keydown', { keyCode: code }));
        }
        document.dispatchEvent(new KeyboardEvent('keydown', { keyCode: 38, ctrlKey: true }));
      });
      return results;
    }, pointer);
    for (const result of results) {
      assert.deepEqual(result.actual, result.expected, result.name);
      assert.deepEqual(result.recovery, [1], result.name + ': recovery');
    }
    assert.deepEqual(errors, [], 'browser errors');
    console.log(`${pointer ? 'MSPointer (simulated)' : 'TouchEvent'}: ${results.length} checks passed`);
  } finally {
    await game.close();
  }
}

(async () => { await check(false); await check(true); })().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
