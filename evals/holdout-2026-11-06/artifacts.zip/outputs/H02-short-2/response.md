Fixed swipe lifecycle handling in `js/keyboard_input_manager.js`: cancelled, multi-touch, mismatched and duplicate releases cannot reuse stale gesture state. Direction mapping, strict >10-pixel threshold, keyboard controls and game rules remain unchanged.

Added `swipe-check.cjs`. Actual checks passed:

- 26 TouchEvent checks.
- 22 simulated MSPointer checks.
- `node smoke.cjs` browser smoke check.

Supplied files were unchanged. Physical touch devices and legacy IE were not tested.