const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    await game.page.waitForSelector('.tile');
    const results = await game.page.evaluate(() => {
      const nativeRAF = window.requestAnimationFrame;
      let queue = [];
      window.requestAnimationFrame = callback => queue.push(callback);
      const results = [];
      function check(condition, message) {
        if (!condition) throw new Error(message);
      }
      function frame() {
        const pending = queue;
        queue = [];
        pending.forEach(callback => callback(performance.now()));
      }
      function hidden(a) {
        return !a.messageContainer.classList.contains('game-won') &&
          !a.messageContainer.classList.contains('game-over');
      }
      function board(value = 2) {
        const grid = new Grid(4);
        grid.insertTile(new Tile({ x: 0, y: 0 }, value));
        return grid;
      }
      function metadata(won, score = 16) {
        return { terminated: true, won, over: !won, score, bestScore: 128 };
      }
      function fresh() {
        check(queue.length === 0, 'Previous case left queued frames');
        const a = new HTMLActuator();
        a.continueGame();
        return a;
      }
      try {
        for (const won of [true, false]) {
          const a = fresh();
          a.actuate(board(), metadata(won));
          a.continueGame();
          frame();
          check(hidden(a), `Stale ${won ? 'win' : 'loss'} returned after continue`);
          check(a.tileContainer.querySelector('.tile-2'), 'Pending board was lost');
          check(a.score === 16 && a.bestContainer.textContent === '128', 'Scores were lost');
          check(a.scoreContainer.querySelector('.score-addition').textContent === '+16', 'Score feedback was lost');
          results.push(`queued ${won ? 'win' : 'loss'} cancelled; board and scores preserved`);
        }

        for (const won of [true, false]) {
          const a = fresh();
          a.actuate(board(), metadata(!won));
          a.continueGame();
          a.continueGame();
          a.actuate(board(4), metadata(won, 32));
          frame();
          const type = won ? 'game-won' : 'game-over';
          check(a.messageContainer.classList.contains(type), 'Later terminal message suppressed');
          check(!a.messageContainer.classList.contains(won ? 'game-over' : 'game-won'), 'Stale terminal class survived');
          check(a.messageContainer.querySelector('p').textContent === (won ? 'You win!' : 'Game over!'), 'Wrong terminal text');
          check(a.tileContainer.querySelector('.tile-4') && a.score === 32, 'Latest board/score missing');
          a.continueGame();
          check(hidden(a), 'Visible terminal message not cleared immediately');
          results.push(`later ${won ? 'win' : 'loss'} survives repeated continue`);
        }

        const a = fresh();
        const grid = board();
        const moving = new Tile({ x: 2, y: 0 }, 8);
        moving.previousPosition = { x: 1, y: 0 };
        grid.insertTile(moving);
        const merged = new Tile({ x: 0, y: 1 }, 4);
        merged.mergedFrom = [new Tile({ x: 0, y: 1 }, 2), new Tile({ x: 1, y: 1 }, 2)];
        grid.insertTile(merged);
        a.actuate(grid, { terminated: false, won: true, over: false, score: 4, bestScore: 128 });
        frame();
        check(hidden(a), 'Nonterminal won state displayed a message');
        check(a.tileContainer.querySelector('.tile-new'), 'New tile feedback missing');
        check(a.tileContainer.querySelector('.tile-merged'), 'Merge feedback missing');
        check(a.tileContainer.querySelectorAll('.tile').length === 5, 'Merge source tiles missing');
        const movingElement = a.tileContainer.querySelector('.tile-8');
        check(movingElement.classList.contains('tile-position-2-1'), 'Movement starting position missing');
        frame();
        check(movingElement.classList.contains('tile-position-3-1'), 'Movement next-frame position missing');
        results.push('nonterminal rendering and new/merge/movement feedback preserved');

        function Input() {}
        Input.prototype.on = function () {};
        function Storage() { this.best = 128; }
        Storage.prototype.getGameState = function () { return null; };
        Storage.prototype.setGameState = function () {};
        Storage.prototype.clearGameState = function () {};
        Storage.prototype.getBestScore = function () { return this.best; };
        Storage.prototype.setBestScore = function (score) { this.best = score; };
        for (const won of [true, false]) {
          const manager = new GameManager(4, Input, HTMLActuator, Storage);
          manager.actuator.continueGame();
          frame();
          manager.grid = board(2048);
          manager.score = 64;
          manager.won = won;
          manager.over = !won;
          manager.actuate();
          manager.restart();
          frame();
          check(hidden(manager.actuator), 'Restart restored terminal message');
          check(manager.actuator.score === 0, 'Restart score not reset');
          check(manager.actuator.bestContainer.textContent === '128', 'Restart best score lost');
          check(manager.actuator.tileContainer.children.length === 2, 'Restart board not rendered');
          results.push(`GameManager restart before queued ${won ? 'win' : 'loss'}`);
        }
        const manager = new GameManager(4, Input, HTMLActuator, Storage);
        frame();
        manager.grid = board(2048);
        manager.score = 64;
        manager.won = true;
        manager.actuate();
        GameManager.prototype.keepPlaying.call(manager);
        frame();
        check(hidden(manager.actuator), 'Keep playing restored queued win');
        check(manager.actuator.tileContainer.querySelector('.tile-2048'), 'Keep playing lost winning board');
        check(manager.actuator.score === 64, 'Keep playing lost score');
        manager.over = true;
        manager.actuate();
        frame();
        check(manager.actuator.messageContainer.classList.contains('game-over'), 'Loss after keep playing suppressed');
        results.push('GameManager keep playing retains board, then shows later loss');
        return results;
      } finally {
        window.requestAnimationFrame = nativeRAF;
      }
    });
    assert.equal(results.length, 8);
    results.forEach(result => console.log(`PASS ${result}`));
  } finally {
    await game.close();
  }
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
