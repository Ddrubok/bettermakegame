Fixed `js/html_actuator.js` so restart/continue invalidates queued terminal messages while preserving board, score, best score, tile feedback, and later terminal messages. GameManager and rules are unchanged.

Added `lifecycle-check.cjs`: reproduced the original failure, then passed eight regression scenarios. Browser smoke and JavaScript syntax checks passed.

Limit: verification used headless Chromium with controlled animation-frame timing; other browsers/devices were not tested.