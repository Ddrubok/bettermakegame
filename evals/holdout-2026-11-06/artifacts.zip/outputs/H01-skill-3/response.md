Updated `js/keyboard_input_manager.js` to ignore keystrokes from inputs, textareas, and contenteditable elements, including nested spans.

Added regression checks: reproduced the original failure, then passed 455 routing cases plus native typing, caret movement, and restart controls. Browser smoke and JavaScript syntax checks passed.

Limits: Chromium only; touch handlers tested with synthetic events. Supplied files remain unchanged.