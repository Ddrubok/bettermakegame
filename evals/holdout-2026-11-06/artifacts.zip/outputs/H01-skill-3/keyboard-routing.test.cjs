const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  const { page } = game;
  try {
    await page.waitForSelector('.tile');
    await page.evaluate(() => {
      window.commands = [];
      const emit = KeyboardInputManager.prototype.emit;
      KeyboardInputManager.prototype.emit = function (name, data) {
        window.commands.push(data === undefined ? { name } : { name, data });
        return emit.call(this, name, data);
      };
      const fixture = document.createElement('div');
      fixture.innerHTML = '<input id="nickname"><textarea id="notes"></textarea>' +
        '<div id="editor" contenteditable="true"><span id="nested">text</span>' +
        '<span id="locked" contenteditable="false" tabindex="0">locked</span></div>' +
        '<div id="plain-editor" contenteditable="plaintext-only">plain</div>' +
        '<button id="outside">Outside editor</button>';
      document.body.appendChild(fixture);
    });

    const bindings = [[38, 0], [39, 1], [40, 2], [37, 3],
      [75, 0], [76, 1], [74, 2], [72, 3],
      [87, 0], [68, 1], [83, 2], [65, 3], [82, null]];
    const modifiers = [{}, { altKey: true }, { ctrlKey: true },
      { metaKey: true }, { shiftKey: true }];
    let cases = 0;
    for (const selector of ['#nickname', '#notes', '#editor', '#nested', '#plain-editor', '#outside', '#locked']) {
      const editing = !['#outside', '#locked'].includes(selector);
      for (const [which, direction] of bindings) {
        for (const modifier of modifiers) {
          const result = await page.evaluate(({ selector, which, modifier }) => {
            window.commands = [];
            const event = new KeyboardEvent('keydown', {
              bubbles: true, cancelable: true, keyCode: which, which, ...modifier
            });
            document.querySelector(selector).dispatchEvent(event);
            return { commands: window.commands, prevented: event.defaultPrevented };
          }, { selector, which, modifier });
          const active = !editing && Object.keys(modifier).length === 0;
          const expected = active ? [direction === null ? { name: 'restart' } : { name: 'move', data: direction }] : [];
          const label = `${selector}, key ${which}, ${JSON.stringify(modifier)}`;
          assert.deepEqual(result.commands, expected, label);
          assert.equal(result.prevented, active, label);
          cases++;
        }
      }
    }

    // Real browser keyboard events verify native insertion and caret movement.
    for (const selector of ['#nickname', '#notes', '#editor', '#plain-editor']) {
      await page.locator(selector).fill('');
      await page.locator(selector).focus();
      const before = await page.evaluate(() => {
        window.commands = [];
        return localStorage.getItem('gameState');
      });
      await page.keyboard.type('wasdhjklr');
      await page.keyboard.press('ArrowLeft');
      await page.keyboard.type('x');
      const result = await page.locator(selector).evaluate(el => ({
        text: 'value' in el ? el.value : el.textContent,
        commands: window.commands,
        state: localStorage.getItem('gameState')
      }));
      assert.equal(result.text, 'wasdhjklxr', selector);
      assert.deepEqual(result.commands, [], selector);
      assert.equal(result.state, before, selector);
    }
    await page.locator('#notes').focus();
    await page.keyboard.press('Enter');
    assert.ok((await page.locator('#notes').inputValue()).includes('\n'));

    await page.locator('#outside').focus();
    await page.evaluate(() => { window.commands = []; });
    await page.keyboard.press('ArrowLeft');
    await page.keyboard.press('r');
    assert.deepEqual(await page.evaluate(() => window.commands), [
      { name: 'move', data: 3 }, { name: 'restart' }
    ]);

    for (const [selector, name] of [['.restart-button', 'restart'], ['.retry-button', 'restart'], ['.keep-playing-button', 'keepPlaying']]) {
      for (const type of ['click', 'touchend']) {
        // Dispatch also covers controls normally hidden behind the game overlay.
        await page.locator('#nickname').focus();
        const result = await page.evaluate(({ selector, type }) => {
          window.commands = [];
          const event = new Event(type, { bubbles: true, cancelable: true });
          document.querySelector(selector).dispatchEvent(event);
          return { commands: window.commands, prevented: event.defaultPrevented };
        }, { selector, type });
        assert.deepEqual(result.commands, [{ name }], `${selector} ${type}`);
        assert.equal(result.prevented, true);
      }
    }
    console.log(`PASS: ${cases} routing cases; native typing/caret/newline; focus re-entry; click/touch control handlers.`);
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
