Fixed swipe lifecycle handling in `js/keyboard_input_manager.js`: cancelled, multi-touch, mismatched, and duplicate endings cannot emit stale moves. Clean gestures recover normally. Direction mapping, strict `>10px` threshold, keyboard controls, and game rules remain unchanged.

Added `swipe-check.cjs`. Passed 21 browser scenario groups, `node smoke.cjs`, and JavaScript syntax validation.

Limit: touch and legacy pointer checks use synthetic browser events, not physical devices.