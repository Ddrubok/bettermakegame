const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

async function check(pointer) {
  const game = await openGame(__dirname, pointer ? () => {
    Object.defineProperty(navigator, 'msPointerEnabled', { value: true });
  } : undefined);
  await game.page.waitForSelector(".tile");
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    const results = await game.page.evaluate(({ pointer }) => {
      const moves = [];
      KeyboardInputManager.prototype.emit = function (event, value) {
        if (event === 'move') moves.push(value);
      };
      const container = document.querySelector('.game-container');
      const t = (id, x = 100, y = 100) => ({ identifier: id, clientX: x, clientY: y });
      function send(kind, touches, changed) {
        const name = pointer ? {start:'MSPointerDown', move:'MSPointerMove', end:'MSPointerUp', cancel:'MSPointerCancel'}[kind] : 'touch' + kind;
        const event = new Event(name, { bubbles: true, cancelable: true });
        const touch = changed[0];
        Object.assign(event, pointer ? { pointerId: touch.identifier, pageX: touch.clientX, pageY: touch.clientY } : { touches, targetTouches: touches, changedTouches: changed });
        container.dispatchEvent(event);
      }
      function swipe(dx, dy) {
        send('start', [t(0)], [t(0)]);
        send('end', [], [t(0, 100 + dx, 100 + dy)]);
      }
      const results = [];
      function test(name, expected, fn) {
        moves.length = 0;
        fn();
        results.push({ name, actual: moves.slice(), expected });
      }
      test('directions, dominant axis, vertical ties', [0,1,2,3,1,2,0], () => {
        swipe(0,-11); swipe(11,0); swipe(0,11); swipe(-11,0);
        swipe(20,15); swipe(15,15); swipe(-15,-15);
      });
      test('strict threshold and tap', [1,3,2,0], () => {
        swipe(0,0); swipe(9,0); swipe(10,0); swipe(-10,0);
        swipe(0,10); swipe(0,-10); swipe(10,10);
        swipe(10.1,0); swipe(-10.1,0); swipe(0,10.1); swipe(0,-10.1);
      });
      test('end without start and repeated end', [1], () => {
        send('end', [], [t(0,200)]);
        swipe(20,0);
        send('end', [], [t(0,300)]);
      });
      test('cancel, stale end, recovery', [3], () => {
        send('start', [t(0)], [t(0)]);
        send('cancel', [], [t(0)]);
        send('end', [], [t(0,200)]);
        swipe(-20,0);
      });
      for (const first of [0,1]) {
        test('second finger and staggered releases ' + first, [2], () => {
          send('start', [t(0)], [t(0)]);
          send('start', [t(0),t(1)], [t(1)]);
          send('end', [t(1-first)], [t(first,200)]);
          send('move', [t(1-first,250)], [t(1-first,250)]);
          send('end', [], [t(1-first,300)]);
          swipe(0,20);
        });
      }
      test('multi-touch cancellation and recovery', [0], () => {
        send('start', [t(0)], [t(0)]);
        send('start', [t(0),t(1)], [t(1)]);
        send('cancel', [t(0)], [t(1)]);
        send('end', [], [t(0,200)]);
        swipe(0,-20);
      });
      test('wrong contact cannot complete gesture', [1], () => {
        send('start', [t(0)], [t(0)]);
        send('end', [], [t(1,200)]);
        send('end', [], [t(0,200)]);
        swipe(20,0);
      });
      if (!pointer) {
        test('simultaneous multi-touch start/end', [1], () => {
          send('start', [t(0),t(1)], [t(0),t(1)]);
          send('end', [], [t(0,200),t(1,200)]);
          swipe(20,0);
        });
        test('multi-touch first observed during move', [1], () => {
          send('start', [t(0)], [t(0)]);
          send('move', [t(0),t(1)], [t(0)]);
          send('end', [t(0)], [t(1)]);
          send('end', [], [t(0,200)]);
          swipe(20,0);
        });
        test('empty changed list consumes gesture', [1], () => {
          send('start', [t(0)], [t(0)]);
          send('end', [], []);
          send('end', [], [t(0,200)]);
          swipe(20,0);
        });
      }
      test('keyboard mapping and modifiers unchanged', [0,1,2,3,0,1,2,3,0,1,2,3], () => {
        for (const which of [38,39,40,37,75,76,74,72,87,68,83,65]) {
          document.dispatchEvent(new KeyboardEvent('keydown', { keyCode:which, bubbles:true }));
        }
        for (const modifier of ['altKey','ctrlKey','metaKey','shiftKey']) {
          document.dispatchEvent(new KeyboardEvent('keydown', { keyCode:38, [modifier]:true, bubbles:true }));
        }
      });
      return results;
    }, { pointer });
    for (const result of results) assert.deepEqual(result.actual, result.expected, (pointer ? 'pointer: ' : 'touch: ') + result.name);
    assert.deepEqual(errors, [], 'browser errors');
    console.log(`${pointer ? 'MSPointer emulation' : 'Touch events'}: ${results.length} scenario groups passed`);
  } finally {
    await game.close();
  }
}
(async () => { await check(false); await check(true); })().catch(error => { console.error(error); process.exitCode = 1; });


