function KeyboardInputManager() {
  this.events = {};

  if (window.navigator.msPointerEnabled) {
    //Internet Explorer 10 style
    this.eventTouchstart    = "MSPointerDown";
    this.eventTouchmove     = "MSPointerMove";
    this.eventTouchend      = "MSPointerUp";
    this.eventTouchcancel   = "MSPointerCancel";
  } else {
    this.eventTouchstart    = "touchstart";
    this.eventTouchmove     = "touchmove";
    this.eventTouchend      = "touchend";
    this.eventTouchcancel   = "touchcancel";
  }

  this.listen();
}

KeyboardInputManager.prototype.on = function (event, callback) {
  if (!this.events[event]) {
    this.events[event] = [];
  }
  this.events[event].push(callback);
};

KeyboardInputManager.prototype.emit = function (event, data) {
  var callbacks = this.events[event];
  if (callbacks) {
    callbacks.forEach(function (callback) {
      callback(data);
    });
  }
};

KeyboardInputManager.prototype.listen = function () {
  var self = this;

  var map = {
    38: 0, // Up
    39: 1, // Right
    40: 2, // Down
    37: 3, // Left
    75: 0, // Vim up
    76: 1, // Vim right
    74: 2, // Vim down
    72: 3, // Vim left
    87: 0, // W
    68: 1, // D
    83: 2, // S
    65: 3  // A
  };

  // Respond to direction keys
  document.addEventListener("keydown", function (event) {
    var modifiers = event.altKey || event.ctrlKey || event.metaKey ||
                    event.shiftKey;
    var mapped    = map[event.which];

    if (!modifiers) {
      if (mapped !== undefined) {
        event.preventDefault();
        self.emit("move", mapped);
      }
    }

    // R key restarts the game
    if (!modifiers && event.which === 82) {
      self.restart.call(self, event);
    }
  });

  // Respond to button presses
  this.bindButtonPress(".retry-button", this.restart);
  this.bindButtonPress(".restart-button", this.restart);
  this.bindButtonPress(".keep-playing-button", this.keepPlaying);

  // Respond to swipe events
  var touchStartClientX, touchStartClientY;
  var activeTouch = null;
  var pointerIds = {};
  var pointerCount = 0;
  var isPointer = window.navigator.msPointerEnabled;
  var gameContainer = document.getElementsByClassName("game-container")[0];

  function resetSwipe() {
    activeTouch = null;
    touchStartClientX = touchStartClientY = undefined;
  }

  gameContainer.addEventListener(this.eventTouchstart, function (event) {
    if (isPointer) {
      if (!pointerIds[event.pointerId]) {
        pointerIds[event.pointerId] = true;
        pointerCount++;
      }
      if (pointerCount !== 1 || activeTouch !== null) {
        resetSwipe();
        return;
      }
      activeTouch = event.pointerId;
      touchStartClientX = event.pageX;
      touchStartClientY = event.pageY;
    } else {
      if (event.touches.length !== 1 || activeTouch !== null) {
        resetSwipe();
        return;
      }
      activeTouch = event.touches[0].identifier;
      touchStartClientX = event.touches[0].clientX;
      touchStartClientY = event.touches[0].clientY;
    }

    event.preventDefault();
  });

  gameContainer.addEventListener(this.eventTouchmove, function (event) {
    if (!isPointer && (event.touches.length !== 1 ||
        event.touches[0].identifier !== activeTouch)) {
      resetSwipe();
    }
    event.preventDefault();
  });

  function releasePointer(event) {
    if (pointerIds[event.pointerId]) {
      delete pointerIds[event.pointerId];
      pointerCount--;
    }
  }

  gameContainer.addEventListener(this.eventTouchcancel, function (event) {
    if (isPointer) releasePointer(event);
    resetSwipe();
  });

  gameContainer.addEventListener(this.eventTouchend, function (event) {
    var touchEndClientX, touchEndClientY;
    var valid;

    if (isPointer) {
      valid = activeTouch !== null && activeTouch === event.pointerId &&
              pointerCount === 1;
      releasePointer(event);
      touchEndClientX = event.pageX;
      touchEndClientY = event.pageY;
    } else {
      valid = activeTouch !== null && event.touches.length === 0 &&
              event.changedTouches.length === 1 &&
              event.changedTouches[0].identifier === activeTouch;
      if (valid) {
        touchEndClientX = event.changedTouches[0].clientX;
        touchEndClientY = event.changedTouches[0].clientY;
      }
    }

    // Consume the gesture before emitting, including rejected endings.
    var startX = touchStartClientX;
    var startY = touchStartClientY;
    resetSwipe();
    if (!valid) return;

    var dx = touchEndClientX - startX;
    var absDx = Math.abs(dx);

    var dy = touchEndClientY - startY;
    var absDy = Math.abs(dy);

    if (Math.max(absDx, absDy) > 10) {
      // (right : left) : (down : up)
      self.emit("move", absDx > absDy ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0));
    }
  });
};

KeyboardInputManager.prototype.restart = function (event) {
  event.preventDefault();
  this.emit("restart");
};

KeyboardInputManager.prototype.keepPlaying = function (event) {
  event.preventDefault();
  this.emit("keepPlaying");
};

KeyboardInputManager.prototype.bindButtonPress = function (selector, fn) {
  var button = document.querySelector(selector);
  button.addEventListener("click", fn.bind(this));
  button.addEventListener(this.eventTouchend, fn.bind(this));
};
