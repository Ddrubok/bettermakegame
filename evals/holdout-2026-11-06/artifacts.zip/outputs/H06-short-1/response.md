Added [REVIEW.md](REVIEW.md), focused browser checks, and evidence. Supplied files and game source remain unchanged.

- Four-of-each pools and 100/200/400/800 awards match the design; repeats are expected.
- Confirmed defects: biased selection forces Z last in every pool, and completed row 0 is skipped.
- Passed `node smoke.cjs` and `node verify-review.cjs`, covering 100 seeded pools, scoring, boundaries, and restart behavior.

Limits: controlled Chromium fixtures; no full interactive playthrough, cross-browser testing, or whole-game audit.