const assert = require('node:assert/strict');
const fs = require('node:fs');
const { openGame } = require('./browser.cjs');

(async () => {
  // Stop automatic animation so fixtures and score animation are deterministic.
  const game = await openGame(__dirname, () => {
    window.requestAnimationFrame = () => 0;
  });
  try {
    const evidence = await game.page.evaluate(() => {
      const names = new Map([[i, 'I'], [j, 'J'], [l, 'L'], [o, 'O'],
        [s, 'S'], [t, 'T'], [z, 'Z']]);
      const originalRandom = Math.random;
      let seed = 123456789;
      Math.random = () => {
        seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
        return seed / 4294967296;
      };
      const bags = [];
      pieces = [];
      for (let bag = 0; bag < 100; bag++) {
        const sequence = Array.from({ length: 28 }, () => names.get(randomPiece().type));
        bags.push({ sequence: sequence.join(''), remaining: pieces.length,
          counts: Object.fromEntries([...names.values()].map(name =>
            [name, sequence.filter(value => value === name).length])) });
      }
      // Distinct sentinel identities expose the selected array index, despite
      // the real pool having several references to each piece type.
      const indexBoundaries = [];
      for (const size of [1, 2, 28]) {
        for (const randomValue of [0, 0.5, 1 - Number.EPSILON / 2]) {
          pieces = Array.from({ length: size }, (_, id) => ({ id, size: 1 }));
          Math.random = () => randomValue;
          const selected = randomPiece().type.id;
          indexBoundaries.push({ size, randomValue, selected });
        }
      }
      // A valid RNG stream can produce four consecutive identical pieces.
      pieces = [];
      Math.random = () => 0;
      const repeatExample = Array.from({ length: 4 }, () => names.get(randomPiece().type));
      Math.random = originalRandom;
      pieces = [];

      const prepare = () => {
        playing = false;
        clearBlocks(); clearRows(); clearScore(); clearActions(); dt = 0;
      };
      const fill = y => { for (let x = 0; x < nx; x++) setBlock(x, y, j); };
      const awards = [];
      for (let count = 0; count <= 4; count++) {
        prepare();
        for (let y = ny - count; y < ny; y++) fill(y);
        setBlock(0, ny - count - 1, t);
        removeLines();
        awards.push({ count, score, rows, markerAtBottom: getBlock(0, ny - 1) === t });
      }
      prepare(); fill(17); fill(19); removeLines();
      const separatedRows = { score, rows };

      const lockAwards = [];
      for (let count = 0; count <= 4; count++) {
        prepare();
        for (let y = ny - count; y < ny; y++) {
          for (let x = 0; x < nx; x++) if (x !== 4) setBlock(x, y, j);
        }
        current = { type: i, dir: DIR.RIGHT, x: 2, y: 16 };
        next = { type: o, dir: DIR.UP, x: 0, y: 0 };
        playing = true;
        drop();
        const beforeDisplay = vscore;
        update(0); draw();
        const afterOneUpdate = vscore;
        for (let frame = 1; frame < score; frame++) update(0);
        draw();
        lockAwards.push({ count, score, rows, beforeDisplay, afterOneUpdate,
          settledDisplay: document.getElementById('score').textContent, playing });
      }

      prepare(); fill(0); removeLines();
      const topRowDirect = { score, rows, stillFull: Array.from({ length: nx },
        (_, x) => !!getBlock(x, 0)).every(Boolean) };
      prepare();
      for (let x = 0; x < nx; x++) if (x !== 4 && x !== 5) setBlock(x, 0, j);
      setBlock(4, 2, j);
      current = { type: o, dir: DIR.UP, x: 4, y: 0 };
      next = { type: i, dir: DIR.UP, x: 0, y: 0 };
      playing = true;
      const legalBeforeLock = unoccupied(current.type, current.x, current.y, current.dir);
      drop();
      const topRowLock = { legalBeforeLock, score, rows, playing,
        stillFull: Array.from({ length: nx }, (_, x) => !!getBlock(x, 0)).every(Boolean) };

      pieces = []; prepare(); next = undefined; reset();
      const afterReset = pieces.length;
      const preview = next;
      play();
      const lifecycle = { afterReset, afterPlay: pieces.length,
        promotedPreview: current === preview, score, rows };
      lose();
      const remainingBeforeRestart = pieces.length;
      play();
      lifecycle.restartDraws = remainingBeforeRestart - pieces.length;
      return { bags, indexBoundaries, repeatExample, awards, separatedRows,
        lockAwards, topRowDirect, topRowLock, lifecycle };
    });
    for (const bag of evidence.bags) {
      assert.equal(bag.remaining, 0);
      assert.deepEqual(Object.values(bag.counts), [4, 4, 4, 4, 4, 4, 4]);
      assert.equal(bag.sequence.at(-1), 'Z');
    }
    for (const boundary of evidence.indexBoundaries) {
      assert.equal(boundary.selected, Math.trunc(boundary.randomValue * (boundary.size - 1)));
      if (boundary.size > 1) assert.ok(boundary.selected < boundary.size - 1);
    }
    assert.deepEqual(evidence.repeatExample, ['I', 'I', 'I', 'I']);
    const expected = [0, 100, 200, 400, 800];
    evidence.awards.forEach((result, count) => {
      assert.equal(result.score, expected[count]);
      assert.equal(result.rows, count);
      assert.equal(result.markerAtBottom, true);
    });
    assert.deepEqual(evidence.separatedRows, { score: 200, rows: 2 });
    evidence.lockAwards.forEach((result, count) => {
      assert.equal(result.score, expected[count] + 10);
      assert.equal(result.rows, count);
      assert.equal(result.beforeDisplay, 0);
      assert.equal(result.afterOneUpdate, 1);
      assert.equal(Number(result.settledDisplay), result.score);
      assert.equal(result.playing, true);
    });
    // These assertions document demonstrated defects; they do not endorse them.
    assert.deepEqual(evidence.topRowDirect, { score: 0, rows: 0, stillFull: true });
    assert.deepEqual(evidence.topRowLock, {
      legalBeforeLock: true, score: 10, rows: 0, playing: true, stillFull: true
    });
    assert.deepEqual(evidence.lifecycle, { afterReset: 26, afterPlay: 25,
      promotedPreview: true, score: 0, rows: 0, restartDraws: 1 });
    fs.writeFileSync('review-evidence.json', JSON.stringify(evidence, null, 2) + '\n');
    console.log('PASS: 100 seeded pools; index boundaries; repeats; 0–4 line awards and locks; separated rows; score display; top-row defect; reset/restart lifecycle.');
    console.log('Known defects reproduced: biased pool selection and skipped top-row clear.');
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
