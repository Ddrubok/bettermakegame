# Focused review: piece pool and line-clear scoring

The stated design is implemented in its pool composition and scoring formula.
Repeated pieces and nonlinear awards do not themselves demonstrate a defect.
Two narrower implementation defects were reproduced. No game source or supplied
task, guidance, helper, or skill files were edited.

## Intended behavior

- `index.html:163` refills the pool with four copies of each of seven types.
  Drawing removes one entry. All 100 seeded, complete pools checked contained
  exactly four of each type and emptied after 28 draws.
- Consecutive repeats are allowed by this design. A deterministic valid random
  stream produced four consecutive I pieces. Equal counts per refill do not
  guarantee short-term variety or evenly spaced pieces.
- `index.html:349` awards `100 * 2^(n-1)` when at least one row clears:
  100, 200, 400, and 800 for one through four rows. Browser fixtures verified
  these awards and zero for no clear. Two separated rows cleared in the same
  call also earned 200.
- `index.html:315` independently awards 10 points when a piece locks. Actual
  lock fixtures therefore earned 10/110/210/410/810 for zero through four rows.
  The visible score advances by one per update (`index.html:265`); all five
  fixtures reached the correct displayed total when explicitly advanced.
- Reset promotes the existing preview and draws another piece; it does not
  empty the pool (`index.html:255`). A fresh initialization consumed two draws,
  starting play consumed one more, and restarting consumed one more. Thus a
  player's first 28 placed pieces need not align with a pool boundary. This is
  observed lifecycle behavior, not a demonstrated violation of the stated design.

## Demonstrated defects

1. **Pool ordering is biased** (`index.html:164`). `random(0, length-1)` produces
   a value below `length-1`; `splice` truncates the fractional index. While more
   than one entry remains, the last entry cannot be selected. The initial last
   entry is Z and remains last as earlier entries are removed, forcing Z as
   draw 28 of every refill. All 100 seeded pools reproduced this. Distinct
   sentinel entries additionally verified selection at RNG values 0, 0.5,
   and the largest representable value below 1 for pool sizes 1, 2, and 28.
   Counts remain correct; this is an ordering defect, not proof that repeats
   are wrong. A targeted future correction is an index such as
   `Math.floor(random(0, pieces.length))`, preserving the 28-piece design.

2. **A completed top row is skipped** (`index.html:335`). The scan starts at
   `ny` (20, outside the board) and stops before row 0. A full row-0 fixture
   remained uncleared with zero rows and zero score. A separate fixture used
   a collision-free O piece at `(4,0)`, support at `(4,2)`, and row 0 filled
   except for columns 4 and 5. Calling `drop()` legally locked it and completed
   row 0, but awarded only the 10 lock points; the full row remained and play
   continued. This is a line-clear boundary defect, distinct from the intended
   award formula. A targeted future correction is scanning from `ny-1` through
   `0`, retaining the existing recheck after removal. No correction was applied.

## Design tradeoffs and optional alternatives

The 28-piece pool guarantees totals per refill while allowing clustering and
longer waits for a type than a seven-piece bag. A seven-piece bag would tighten
short-term distribution but change the designer's rule; repeats can still
occur across bag boundaries. Independent uniform draws would remove refill
structure but lose guaranteed counts and permit arbitrarily long droughts.
Neither alternative is necessary to correct the index bias.

The intended score rewards clearing three or four rows together more than
clearing the same number separately; two together equals two single clears.
Linear scoring would reduce that incentive and is an optional design change,
not a required fix.

## Actual verification and limits

- `node smoke.cjs` passed in the supplied Chromium helper, returned the title
  `Javascript Tetris`, and wrote `smoke.png`.
- `node verify-review.cjs` passed all assertions and wrote
  `review-evidence.json`. It exercises the existing game functions in Chromium
  with automatic animation disabled, controlled board states, and controlled
  RNG streams. It covers pool exhaustion/refill, selection boundaries, repeats,
  zero-to-four clears and locks, row compaction via a marker, separated clears,
  score display catch-up, the top-row defect, and reset/restart consumption.
  Assertions for the two known defects intentionally record current faulty
  behavior; a passing script does not mean those defects are fixed.
- The top-row position was constructed directly and checked for a legal lock;
  it was not reached through a recorded keyboard playthrough. Display checks
  advanced updates manually and do not establish wall-clock animation timing.
  No exhaustive randomness analysis, long interactive playthrough, cross-browser
  checks, or unrelated whole-game audit was performed. No network access,
  external research, other agents, or prior solutions were used.
