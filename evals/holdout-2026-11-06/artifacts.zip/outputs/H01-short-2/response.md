Fixed `js/keyboard_input_manager.js` so inputs, textareas and contenteditable descendants retain normal keyboard behavior. Existing shortcuts, modifiers and restart controls remain intact.

Added `keyboard-routing-check.cjs`; all 490 routing cases passed, plus typing, caret movement, focus changes, editable toggles and button checks. `node smoke.cjs` also passed.

Supplied files remain unchanged. Validation used Chromium only; legacy browsers and physical touch devices were not tested.