const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    const { page } = game;
    await page.waitForSelector('.tile');
    await page.evaluate(() => {
      window.gameEvents = [];
      const emit = KeyboardInputManager.prototype.emit;
      KeyboardInputManager.prototype.emit = function (name, data) {
        window.gameEvents.push([name, data]);
        return emit.call(this, name, data);
      };
      const fixture = document.createElement('div');
      fixture.innerHTML = '<input id="nickname"><textarea id="notes"></textarea>' +
        '<div id="editor" contenteditable="true"><span id="nested">text</span>' +
        '<span id="locked" contenteditable="false" tabindex="0">locked</span></div>' +
        '<div id="plain" contenteditable="plaintext-only">text</div>' +
        '<div id="outside" tabindex="0">outside</div>';
      document.body.appendChild(fixture);
    });

    const matrix = await page.evaluate(() => {
      const failures = [];
      let checks = 0;
      const keys = [[38, 0], [39, 1], [40, 2], [37, 3], [75, 0], [76, 1],
        [74, 2], [72, 3], [87, 0], [68, 1], [83, 2], [65, 3], [82, 'restart'], [88, null]];
      const modifiers = [null, 'altKey', 'ctrlKey', 'metaKey', 'shiftKey'];
      for (const id of ['nickname', 'notes', 'editor', 'nested', 'plain', 'locked', 'outside']) {
        const editing = !['locked', 'outside'].includes(id);
        for (const [which, action] of keys) {
          for (const modifier of modifiers) {
            window.gameEvents = [];
            const event = new KeyboardEvent('keydown', {
              bubbles: true, cancelable: true, which, keyCode: which,
              ...(modifier ? { [modifier]: true } : {})
            });
            document.getElementById(id).dispatchEvent(event);
            const handled = !editing && !modifier && action !== null;
            const expected = handled ? (action === 'restart' ? [['restart', null]] : [['move', action]]) : [];
            if (event.defaultPrevented !== handled || JSON.stringify(window.gameEvents) !== JSON.stringify(expected)) {
              failures.push({ id, which, modifier, prevented: event.defaultPrevented, events: window.gameEvents });
            }
            checks++;
          }
        }
      }
      return { checks, failures };
    });
    assert.deepEqual(matrix.failures, [], 'keyboard routing matrix');

    for (const id of ['nickname', 'notes', 'editor', 'plain']) {
      await page.locator('#' + id).fill('');
      await page.locator('#' + id).focus();
      await page.evaluate(() => { window.gameEvents = []; });
      await page.keyboard.type('wasdhjklr');
      await page.keyboard.press('ArrowLeft');
      await page.keyboard.type('x');
      const result = await page.locator('#' + id).evaluate(el => ({
        text: 'value' in el ? el.value : el.textContent,
        events: window.gameEvents
      }));
      assert.equal(result.text, 'wasdhjklxr', id + ' typing and caret navigation');
      assert.deepEqual(result.events, [], id + ' must not control the game');
    }

    await page.locator('#outside').focus();
    await page.evaluate(() => { window.gameEvents = []; });
    await page.keyboard.press('w');
    await page.keyboard.press('r');
    assert.deepEqual(await page.evaluate(() => window.gameEvents), [['move', 0], ['restart', undefined]]);

    const lifecycle = await page.evaluate(() => {
      const editor = document.getElementById('editor');
      const results = [];
      for (const editable of ['false', 'true', 'false']) {
        editor.contentEditable = editable;
        window.gameEvents = [];
        const event = new KeyboardEvent('keydown', { bubbles: true, cancelable: true, which: 82, keyCode: 82 });
        editor.dispatchEvent(event);
        results.push([event.defaultPrevented, window.gameEvents.length]);
      }
      return results;
    });
    assert.deepEqual(lifecycle, [[true, 1], [false, 0], [true, 1]]);

    for (const [selector, expected] of [['.restart-button', 'restart'], ['.retry-button', 'restart'], ['.keep-playing-button', 'keepPlaying']]) {
      for (const type of ['click', 'touchend']) {
        const events = await page.evaluate(({ selector, type }) => {
          window.gameEvents = [];
          document.querySelector(selector).dispatchEvent(new Event(type, { bubbles: true, cancelable: true }));
          return window.gameEvents.map(event => event[0]);
        }, { selector, type });
        assert.deepEqual(events, [expected], selector + ' ' + type);
      }
    }
    console.log(`PASS: ${matrix.checks} routing cases; real typing/caret checks in four editors; focus transitions; editable toggles; six button events.`);
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
