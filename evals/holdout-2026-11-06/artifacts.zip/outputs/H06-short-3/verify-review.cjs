const assert = require('node:assert/strict');
const fs = require('node:fs');
const { openGame } = require('./browser.cjs');

(async () => {
  // Disable automatic frames so fixtures cannot change between assertions.
  const game = await openGame(__dirname, () => {
    window.requestAnimationFrame = () => 0;
  });
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    const result = await game.page.evaluate(() => {
      const originalRandom = Math.random;
      const types = [i, j, l, o, s, t, z];
      const names = ['i', 'j', 'l', 'o', 's', 't', 'z'];
      const name = type => names[types.indexOf(type)];
      try {
        let seed = 123456789;
        Math.random = () => {
          seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
          return seed / 4294967296;
        };
        pieces = [];
        const bags = [];
        for (let bag = 0; bag < 20; bag++) {
          const draws = Array.from({ length: 28 }, () => name(randomPiece().type));
          bags.push({ counts: names.map(n => draws.filter(v => v === n).length),
            last: draws[27], remaining: pieces.length });
        }
        randomPiece();
        const afterRefill = pieces.length;

        // Distinguish valid repeats from a reproducible indexing defect.
        pieces = [];
        Math.random = () => 0;
        const repeats = Array.from({ length: 4 }, () => name(randomPiece().type));
        const endpointChoices = [0, 0.5, 1 - Number.EPSILON].map(value => {
          pieces = [i, z];
          Math.random = () => value;
          return name(randomPiece().type);
        });
        const finalSingleton = name(randomPiece().type);

        const fixture = fullRows => {
          clearBlocks(); clearRows(); clearScore();
          fullRows.forEach(y => {
            for (let x = 0; x < nx; x++) setBlock(x, y, t);
          });
        };
        const awards = [];
        for (let count = 0; count <= 4; count++) {
          fixture(Array.from({ length: count }, (_, n) => ny - 1 - n));
          removeLines();
          awards.push({ rows, score });
        }
        fixture([17, 19]);
        setBlock(0, 16, j);
        removeLines();
        const separated = { rows, score, shiftedMarker: getBlock(0, 18) === j };
        fixture([]);
        for (let x = 0; x < nx - 1; x++) setBlock(x, ny - 1, t);
        removeLines();
        const incomplete = { rows, score };

        // Exercise the real lock path: a horizontal I completes the bottom row.
        fixture([]);
        for (let x = 4; x < nx; x++) setBlock(x, ny - 1, t);
        current = { type: i, dir: DIR.UP, x: 0, y: ny - 2 };
        next = { type: o, dir: DIR.UP, x: 4, y: 0 };
        playing = true;
        drop();
        const lock = { rows, score, vscore };
        update(0);
        lock.visualAfterOneUpdate = vscore;
        lose(); draw();
        lock.visualOnLoss = document.getElementById('score').textContent;

        fixture([0]);
        removeLines();
        const topBoundary = { rows, score,
          rowStillFull: Array.from({ length: nx }, (_, x) => !!getBlock(x, 0)).every(Boolean) };

        pieces = [i, j, l, o];
        const preview = { type: t, dir: DIR.UP, x: 3, y: 0 };
        next = preview;
        reset();
        const restart = { previewPromoted: current === preview,
          poolRemaining: pieces.length, rows, score };
        return { bags, afterRefill, repeats, endpointChoices, finalSingleton,
          awards, separated, incomplete, lock, topBoundary, restart };
      } finally { Math.random = originalRandom; }
    });
    for (const bag of result.bags) {
      assert.deepEqual(bag.counts, [4, 4, 4, 4, 4, 4, 4]);
      assert.equal(bag.remaining, 0);
      assert.equal(bag.last, 'z');
    }
    assert.equal(result.afterRefill, 27);
    assert.deepEqual(result.repeats, ['i', 'i', 'i', 'i']);
    assert.deepEqual(result.endpointChoices, ['i', 'i', 'i']);
    assert.equal(result.finalSingleton, 'z');
    assert.deepEqual(result.awards, [0, 100, 200, 400, 800].map((score, rows) => ({ rows, score })));
    assert.deepEqual(result.separated, { rows: 2, score: 200, shiftedMarker: true });
    assert.deepEqual(result.incomplete, { rows: 0, score: 0 });
    assert.deepEqual(result.lock, { rows: 1, score: 110, vscore: 0,
      visualAfterOneUpdate: 1, visualOnLoss: '00110' });
    assert.deepEqual(result.topBoundary, { rows: 0, score: 0, rowStillFull: true });
    assert.deepEqual(result.restart, { previewPromoted: true, poolRemaining: 3, rows: 0, score: 0 });
    assert.deepEqual(errors, []);
    fs.writeFileSync('review-evidence.json', JSON.stringify(result, null, 2) + '\n');
    console.log('PASS: pool counts/refill/repeats, selection-bias reproduction, scoring 0–4, separated/incomplete rows, lock bonus/display, top-row reproduction, restart continuity.');
    console.log('Assertions characterize this snapshot, including known defects; they do not certify correctness.');
  } finally { await game.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
