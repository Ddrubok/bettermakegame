# Focused review: piece pool and line-clear awards

Repeated pieces and nonlinear awards do not establish that the game is broken. Both are consistent with the stated design. The implementation preserves the intended pool counts and award values, but has a demonstrated selection bias and a line-scanning boundary defect. Game source and supplied files were left unchanged.

## Expected behavior

- `index.html:161–165` refills with four copies of each of seven types and removes one entry per draw. Twenty seeded, complete 28-draw pools each contained exactly four of every type; each emptied before refill. Draw 29 left 27 entries in the new pool.
- Four copies permit immediate repeats, including four identical pieces in succession within a pool. A controlled random value of zero reproduced four I pieces. Repeats alone are not evidence of a defect. Counts are guaranteed per refill, not per arbitrary sliding window of 28 pieces.
- `index.html:348–350` awards `100 * 2 ** (n - 1)` for a positive number of rows cleared together. Browser fixtures for zero through four rows produced 0/100/200/400/800, respectively. Two separated full rows in one call also earned 200; an incomplete row earned zero.
- `drop()` separately adds 10 when a piece locks (`index.html:315`). A real lock completing one bottom row therefore increased score by 110. The displayed score catches up one point per update; the fixture showed internal score 110, display state initially 0, then 1 after an update, and 00110 on loss. These differences do not contradict the line-clear awards.
- `reset()` preserves the existing pool and promotes the preview to current. A controlled reset confirmed preview identity, one new draw, and cleared score/row totals. Pool boundaries therefore need not align with a new game or the first piece a player observes; startup also draws current and preview pieces.

## Demonstrated defects

1. **The last pool entry is excluded while multiple entries remain** (`index.html:164`). `random(0, pieces.length - 1)` supplies a nonnegative fractional index to `splice`, which truncates it. With N entries, the chosen indices are 0 through N-2. The initially last Z entry survives until the final draw, so every complete pool ends in Z. All 20 seeded pools exhibited this; a two-entry `[I, Z]` fixture selected I at random values 0, 0.5, and just below 1, then selected Z as the singleton. This is an ordering bias, not a loss of the four-per-type guarantee, and it does not make every observed repeat erroneous. If uniform selection among remaining entries is intended, the localized correction would be `pieces.splice(Math.floor(Math.random() * pieces.length), 1)[0]`. This review does not apply that change.

2. **A full top row is skipped** (`index.html:335`). The line scan visits indices 20 through 1 on a board whose valid rows are 0 through 19. An injected full row at index 0 remained full and yielded zero rows/points. This is a boundary defect in which rows are considered, not in the nonlinear award formula. Starting at `ny - 1` and including zero would address that boundary. Normal-play reachability and interaction with top-out were not tested; the reproduction calls the actual line-clear routine on a controlled board.

## Tradeoffs and optional alternatives

The 28-piece pool balances totals over longer batches while permitting clusters and longer waits for a particular type. Uniformly choosing each remaining entry would remove the identified ordering bias while preserving that design. A one-of-each seven-piece bag would constrain clusters and waits more tightly, but changes the designer's rule and is optional. Independent draws would remove pool-boundary structure but lose guaranteed batch counts.

The intended awards give more points per row for triples and four-row clears, rewarding setup and risk. Linear awards would reduce that incentive but would change the explicit scoring intent; they are not a required fix.

## Actual checks and limits

- `node smoke.cjs` passed, returned title `Javascript Tetris`, and wrote `smoke.png`. This verifies startup and screenshot capture, not visual correctness or a full playthrough.
- `node verify-review.cjs` passed all assertions described above, including a marker shifting down through two cleared rows. It uses the supplied browser helper and actual page functions, freezes automatic animation, and injects deterministic random values and board states. Detailed output is saved in `review-evidence.json`. Its assertions intentionally characterize the current defects; a passing run does not mean the implementation is defect-free.
- Added only this report, the focused verification script, and generated evidence. No game, helper, guidance, task, or supplied skill files were edited.
- No full-game audit, long manual play session, statistical randomness study, exhaustive game-over/restart testing, cross-browser/mobile testing, or evaluation of unrelated controls/rendering was performed. No external network sources or other agents were used.
