const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Freeze automatic frames so the real update/render functions get exact deltas.
  const game = await openGame(__dirname, () => {
    window.requestAnimationFrame = () => 0;
  });
  try {
    const result = await game.page.evaluate(() => {
      const checks = [];
      function check(ok, name) {
        if (!ok) throw new Error(name);
        checks.push(name);
      }
      function close(actual, expected, name) {
        check(Math.abs(actual - expected) < 1e-8, name);
      }
      function start(target = 1000) {
        play();
        addScore(target);
      }
      function tick(seconds) {
        update(seconds);
        draw();
        check(/^\d{5}$/.test(get('score').textContent), 'integral HUD');
        check(vscore <= score, 'no overshoot');
      }
      const rates = [];
      for (const hz of [30, 60, 120, 144, 240]) {
        start();
        for (let frame = 0; frame < hz; frame++) tick(1 / hz);
        close(vscore, 60, `${hz} Hz: 60 points after one second`);
        check(score === 1000, `${hz} Hz: real score preserved`);
        rates.push({ hz, progress: vscore, rendered: get('score').textContent });
      }
      start();
      tick(0);
      check(vscore === 0, 'zero delta does not snap or advance');
      tick(1 / 240);
      close(vscore, 0.25, 'fraction retained');
      check(get('score').textContent === '00000', 'fraction not rendered');
      for (let n = 0; n < 3; n++) tick(1 / 240);
      close(vscore, 1, 'short frames accumulate');
      check(get('score').textContent === '00001', 'accumulated point rendered');

      start();
      for (const delta of [0.003, 0.007, 0.04, 0.2, 0.75]) tick(delta);
      close(vscore, 60, 'uneven frames use elapsed time');
      addScore(100);
      tick(0.1);
      close(vscore, 66, 'new award preserves existing progress');
      check(score === 1100, 'new award preserved');

      start(2);
      tick(1);
      check(vscore === 2, 'long frame clamps to target');
      tick(1);
      addScore(10);
      tick(1 / 240);
      close(vscore, 2.25, 'idle time is not banked');
      lose();
      draw();
      check(vscore === 12 && get('score').textContent === '00012', 'loss snaps to final score');
      tick(1);
      check(vscore === 12 && !playing, 'stopped game remains stable');
      play();
      draw();
      check(score === 0 && vscore === 0 && get('score').textContent === '00000', 'restart clears progress');

      current = { type: o, dir: DIR.UP, x: 4, y: 0 };
      tick(0.59);
      check(current.y === 0, 'gravity waits for original threshold');
      tick(0.02);
      check(current.y === 1, 'gravity drops at original threshold');
      close(dt, 0.01, 'gravity retains original remainder');
      document.dispatchEvent(new KeyboardEvent('keydown', { keyCode: KEY.LEFT, bubbles: true }));
      tick(0);
      check(current.x === 3, 'left control still processes');
      document.dispatchEvent(new KeyboardEvent('keydown', { keyCode: KEY.DOWN, bubbles: true }));
      tick(0);
      check(current.y === 2, 'down control still processes');

      for (let count = 1; count <= 4; count++) {
        play();
        for (let y = ny - count; y < ny; y++)
          for (let x = 0; x < nx; x++) setBlock(x, y, o);
        removeLines();
        check(rows === count && score === 100 * Math.pow(2, count - 1), `${count} line clear award`);
        check(!getBlock(0, ny - 1), `${count} lines removed`);
      }
      play();
      current = { type: o, dir: DIR.UP, x: 4, y: 18 };
      drop();
      check(score === 10, 'locked piece award preserved');
      check(getBlock(4, 18) === o, 'locked piece retained');

      pieces = [];
      const counts = {};
      for (let n = 0; n < 28; n++) {
        const color = randomPiece().type.color;
        counts[color] = (counts[color] || 0) + 1;
      }
      check(Object.keys(counts).length === 7 && Object.values(counts).every(n => n === 4), 'piece bag composition preserved');
      return { assertions: checks.length, rates };
    });
    assert.ok(result.assertions > 0);
    console.log(JSON.stringify(result, null, 2));
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
