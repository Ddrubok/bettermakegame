Updated `index.html` to count up at 60 points per elapsed second, retain fractions, clamp to the real score, and render integers. Zero-duration frames and the end-game snap work correctly.

Added `score-check.cjs`. It reproduced the original defect, then passed simulated 30–240 Hz, fractional-progress, reset, scoring, gravity, controls, and piece-bag checks. `node smoke.cjs` also passed.

Limits: headless simulation only; the existing one-second frame-delta cap remains. Supplied helper, guidance, and skill files are unchanged.