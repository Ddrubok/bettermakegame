Updated `index.html` to advance the displayed score at 60 points/second, retain fractional progress, prevent overshoot, and preserve integer rendering and end-game snapping.

Passed `node score-check.cjs` and `node smoke.cjs`, covering simulated refresh rates, score boundaries, restart, gravity, and point awards.

Limits: refresh rates were simulated; floating-point rounding can delay an integer display boundary by one frame. The existing one-second frame-delta cap remains.