const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Freeze automatic frames so each check supplies its own elapsed time.
  const game = await openGame(__dirname, () => { window.requestAnimationFrame = () => 0; });
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    const results = await game.page.evaluate(() => {
      function check(condition, message) {
        if (!condition) throw new Error(message);
      }
      function near(actual, expected, message) {
        check(Math.abs(actual - expected) < 1e-9, `${message}: ${actual} != ${expected}`);
      }
      function start(target = 1000) { play(); addScore(target); }
      function tick(seconds) {
        update(seconds);
        drawScore();
        check(vscore <= score, 'visual score overshot');
        check(/^\d{5}$/.test(get('score').textContent), 'nonintegral rendered score');
        check(Number(get('score').textContent) === Math.floor(vscore), 'rendered score mismatch');
      }
      const rates = [30, 60, 120, 144, 240].map(hz => {
        start();
        for (let frame = 0; frame < hz; frame++) tick(1 / hz);
        near(vscore, 60, `${hz} Hz rate`);
        check(score === 1000, 'presentation changed awarded score');
        check(current.y === 1, 'gravity timing changed');
        return { hz, visual: vscore, rendered: get('score').textContent };
      });

      start();
      tick(0);
      check(vscore === 0, 'zero elapsed time snapped score');
      tick(1 / 240);
      near(vscore, 0.25, 'fractional progress');
      check(get('score').textContent === '00000', 'fraction rendered too early');
      for (let n = 0; n < 3; n++) tick(1 / 240);
      check(get('score').textContent === '00001', 'short frames lost progress');

      start();
      [0.003, 0.017, 0.08, 0.15, 0.25, 0.5].forEach(tick);
      near(vscore, 60, 'mixed frame durations');
      start(10);
      tick(1);
      check(vscore === 10, 'catch-up clamp');
      tick(1);
      addScore(10);
      tick(1 / 240);
      near(vscore, 10.25, 'idle time must not accumulate credit');

      lose();
      drawScore();
      check(vscore === score && get('score').textContent === '00020', 'end-game snap');
      tick(1);
      check(vscore === 20, 'stopped game changed score');
      play();
      tick(0);
      check(score === 0 && vscore === 0 && get('score').textContent === '00000', 'restart reset');

      // Exercise real point awards and line clearing with a deterministic board.
      current = { type: o, dir: DIR.UP, x: 4, y: 18 };
      drop();
      check(score === 10, 'piece lock award changed');
      for (let count = 1; count <= 4; count++) {
        play();
        for (let y = ny - count; y < ny; y++)
          for (let x = 0; x < nx; x++) setBlock(x, y, o);
        removeLines();
        check(score === 100 * Math.pow(2, count - 1), 'line award changed');
        check(rows === count, 'line count changed');
        check(step === Math.max(speed.min, speed.start - speed.decrement * count), 'drop speed changed');
        for (let x = 0; x < nx; x++) check(!getBlock(x, ny - 1), 'line not cleared');
      }
      return rates;
    });
    assert.deepEqual(errors, []);
    console.log('PASS: refresh rates, fractional/zero/mixed deltas, clamping, idle, loss/restart, gravity, lock and line awards.');
    console.table(results);
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
