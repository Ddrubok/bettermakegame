const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    const { page } = game;
    const errors = [];
    page.on('pageerror', error => errors.push(error.message));
    await page.waitForSelector('.tile');
    await page.evaluate(() => {
      window.routedEvents = [];
      const emit = KeyboardInputManager.prototype.emit;
      KeyboardInputManager.prototype.emit = function (name, data) {
        window.routedEvents.push(data === undefined ? { name } : { name, data });
        return emit.call(this, name, data);
      };
      const fixture = document.createElement('div');
      fixture.innerHTML = '<input id="nickname"><textarea id="notes"></textarea>' +
        '<div id="editor" contenteditable="true"><span id="nested">edit</span>' +
        '<span id="readonly" contenteditable="false">fixed</span></div>' +
        '<div id="plain-editor" contenteditable="plaintext-only">plain</div>' +
        '<button id="ordinary">ordinary</button>';
      document.body.appendChild(fixture);
    });

    const routes = [
      [38, 0], [39, 1], [40, 2], [37, 3],
      [75, 0], [76, 1], [74, 2], [72, 3],
      [87, 0], [68, 1], [83, 2], [65, 3], [82, 'restart']
    ];
    async function dispatch(selector, code, modifiers = {}) {
      return page.evaluate(({ selector, code, modifiers }) => {
        window.routedEvents = [];
        const event = new KeyboardEvent('keydown', {
          bubbles: true, cancelable: true, keyCode: code, which: code, ...modifiers
        });
        document.querySelector(selector).dispatchEvent(event);
        return { prevented: event.defaultPrevented, events: window.routedEvents };
      }, { selector, code, modifiers });
    }

    let cases = 0;
    for (const selector of ['#nickname', '#notes', '#editor', '#nested', '#plain-editor']) {
      for (const [code] of routes) {
        for (const modifiers of [{}, { shiftKey: true }, { ctrlKey: true }, { altKey: true }, { metaKey: true }]) {
          assert.deepEqual(await dispatch(selector, code, modifiers),
            { prevented: false, events: [] }, `${selector}, key ${code}, ${JSON.stringify(modifiers)}`);
          cases++;
        }
      }
    }

    for (const selector of ['body', '#ordinary', '#readonly']) {
      for (const [code, direction] of routes) {
        const expected = direction === 'restart' ? { name: 'restart' } : { name: 'move', data: direction };
        assert.deepEqual(await dispatch(selector, code), { prevented: true, events: [expected] });
        cases++;
        for (const modifier of ['altKey', 'ctrlKey', 'metaKey', 'shiftKey']) {
          assert.deepEqual(await dispatch(selector, code, { [modifier]: true }),
            { prevented: false, events: [] });
          cases++;
        }
      }
      assert.deepEqual(await dispatch(selector, 81), { prevented: false, events: [] });
      cases++;
    }

    for (const selector of ['#nickname', '#notes', '#editor', '#plain-editor']) {
      await page.locator(selector).fill('');
      await page.locator(selector).focus();
      await page.evaluate(() => { window.routedEvents = []; });
      await page.keyboard.type('wasdhjklr');
      await page.keyboard.press('ArrowLeft');
      await page.keyboard.type('X');
      const value = await page.locator(selector).evaluate(element =>
        'value' in element ? element.value : element.textContent);
      assert.equal(value, 'wasdhjklXr', `${selector}: native text insertion and caret movement`);
      assert.deepEqual(await page.evaluate(() => window.routedEvents), []);
    }
    await page.locator('#notes').fill('first');
    await page.keyboard.press('End');
    await page.keyboard.press('Enter');
    await page.keyboard.type('second');
    assert.equal(await page.locator('#notes').inputValue(), 'first\nsecond');

    for (const selector of ['.restart-button', '.retry-button']) {
      for (const type of ['click', 'touchend']) {
        const result = await page.evaluate(({ selector, type }) => {
          window.routedEvents = [];
          const button = document.querySelector(selector);
          const options = { bubbles: true, cancelable: true };
          const event = type === 'touchend' ? new TouchEvent(type, {
            ...options, changedTouches: [new Touch({ identifier: 1, target: button, clientX: 0, clientY: 0 })]
          }) : new MouseEvent(type, options);
          button.dispatchEvent(event);
          return { prevented: event.defaultPrevented, events: window.routedEvents };
        }, { selector, type });
        assert.deepEqual(result, { prevented: true, events: [{ name: 'restart' }] });
      }
    }
    assert.deepEqual(errors, []);
    console.log(`PASS: ${cases} routing cases, native editing/caret/newline checks, and click/touch restart controls`);
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
