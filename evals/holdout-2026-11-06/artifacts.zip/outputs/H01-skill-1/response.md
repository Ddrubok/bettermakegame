Updated `js/keyboard_input_manager.js` to ignore keyboard events from inputs, textareas, and contenteditable elements, including nested spans.

Added `keyboard-routing-check.cjs`. Verified:
- 523 routing cases, native typing, caret movement, and newlines.
- Existing shortcuts, modifiers, and restart controls.
- Supplied smoke check and JavaScript syntax checks.

Limits: tested in headless Chromium; touch checks used synthetic events. Supplied files remain unchanged.