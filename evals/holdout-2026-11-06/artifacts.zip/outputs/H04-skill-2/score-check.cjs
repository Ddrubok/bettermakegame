const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Drive the real update/draw code deterministically, without competing RAFs.
  const game = await openGame(__dirname, () => {
    window.requestAnimationFrame = () => 0;
  });
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    const results = await game.page.evaluate(() => {
      const results = [];
      function check(condition, message) {
        if (!condition) throw new Error(message);
      }
      function near(actual, expected, message) {
        check(Math.abs(actual - expected) < 1e-9,
          `${message}: expected ${expected}, got ${actual}`);
      }
      function start(target = 1000) {
        play();
        setCurrentPiece({ type: o, dir: DIR.UP, x: 4, y: 0 });
        addScore(target);
      }
      function frame(seconds) {
        const previous = vscore;
        update(seconds);
        draw();
        check(vscore >= previous && vscore <= score, 'monotonic and bounded');
        check(/^\d{5}$/.test(get('score').textContent), 'integral padded HUD');
        check(Number(get('score').textContent) === Math.floor(vscore), 'HUD floors progress');
      }

      for (const hz of [30, 60, 90, 120, 144, 165, 240]) {
        start();
        for (let n = 0; n < hz; n++) frame(1 / hz);
        near(vscore, 60, `${hz} Hz: 60 points in one second`);
        check(score === 1000, 'presentation preserves actual score');
        check(current.y === 1, 'gravity still uses elapsed seconds');
        results.push(`${hz} Hz: ${vscore.toFixed(9)} points/second`);
      }

      start();
      for (const ms of [0, 1, 3, 7, 19, 70, 200, 400, 300]) frame(ms / 1000);
      near(vscore, 60, 'irregular frames total one second');
      start();
      frame(0);
      check(vscore === 0, 'zero delta must not snap to target');
      for (let n = 1; n <= 4; n++) {
        frame(1 / 240);
        near(vscore, n / 4, 'fractional progress survives short frames');
        check(Number(get('score').textContent) === Math.floor(n / 4), 'fractional HUD');
      }
      results.push('Zero delta, fractional retention, irregular timing and integral rendering passed');

      start(10);
      frame(1);
      check(vscore === 10, 'large delta clamps to target');
      frame(1);
      addScore(10);
      frame(1 / 240);
      near(vscore, 10.25, 'idle time does not bank progress');
      lose();
      draw();
      check(!playing && vscore === 20 && get('score').textContent === '00020', 'end-game snap');
      update(1);
      check(vscore === 20, 'stopped game keeps final score');
      play();
      draw();
      check(score === 0 && vscore === 0 && get('score').textContent === '00000', 'restart clears progress');
      results.push('Clamping, subsequent awards, idle, end-game snap and restart passed');

      start(0);
      update(step);
      check(current.y === 0, 'original strict gravity threshold');
      update(0.001);
      check(current.y === 1, 'gravity drops after threshold');
      for (const [keyCode, field, expected] of [
        [KEY.LEFT, 'x', 3], [KEY.RIGHT, 'x', 4],
        [KEY.UP, 'dir', DIR.RIGHT], [KEY.DOWN, 'y', 2]
      ]) {
        document.dispatchEvent(new KeyboardEvent('keydown', { keyCode, bubbles: true }));
        update(0);
        check(current[field] === expected, `control ${keyCode}`);
      }
      start(0);
      current.y = 18;
      drop();
      check(score === 10, 'locked piece awards 10 points');
      for (let count = 1; count <= 4; count++) {
        start(0);
        for (let y = ny - count; y < ny; y++)
          for (let x = 0; x < nx; x++) setBlock(x, y, j);
        removeLines();
        check(score === 100 * Math.pow(2, count - 1), `${count}-line award`);
        check(rows === count && step === speed.start - speed.decrement * count, 'rows and speed');
        for (let x = 0; x < nx; x++) check(!getBlock(x, ny - 1), 'cleared bottom row');
      }
      results.push('Gravity threshold, all arrow controls, piece award and 1–4 line clears passed');
      return results;
    });
    assert.deepEqual(errors, [], 'browser runtime errors');
    console.log(results.join('\n'));
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
