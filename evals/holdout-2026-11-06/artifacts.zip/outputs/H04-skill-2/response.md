Updated `index.html` to advance the score at 60 points per elapsed second, retain fractional progress, clamp to the actual score, and preserve integer rendering and the end-game snap.

Passed `node smoke.cjs` and added `node score-check.cjs`, covering simulated 30–240 Hz timing, fractional progress, restart, gravity, controls, and scoring.

Limits: headless Chromium checks, not physical displays. The existing one-second frame-delta cap remains unchanged.