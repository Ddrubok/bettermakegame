Fixed `js/html_actuator.js` so clearing a message invalidates queued terminal messages while preserving board, score, and animation updates. Later win/loss messages still display. GameManager and supplied files remain unchanged.

Checks passed:
- 21 browser lifecycle/rendering assertions in `lifecycle-check.cjs`
- `node smoke.cjs`
- JavaScript syntax check

Limit: verified in Chromium with controlled animation frames; no cross-browser testing.