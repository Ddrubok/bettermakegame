const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    await game.page.waitForSelector('.tile');
    const results = await game.page.evaluate(() => {
      const originalRAF = window.requestAnimationFrame;
      let queue = [];
      window.requestAnimationFrame = callback => queue.push(callback);
      const results = [];
      function check(condition, description) {
        if (!condition) throw new Error(description);
        results.push(description);
      }
      function frame() {
        const callbacks = queue;
        queue = [];
        callbacks.forEach(callback => callback());
      }
      const actuator = new HTMLActuator();
      const grid = new Grid(4);
      const moving = new Tile({ x: 1, y: 0 }, 2);
      moving.previousPosition = { x: 0, y: 0 };
      grid.insertTile(moving);
      grid.insertTile(new Tile({ x: 2, y: 0 }, 4));
      const merged = new Tile({ x: 3, y: 0 }, 8);
      merged.mergedFrom = [new Tile({ x: 2, y: 0 }, 4), new Tile({ x: 3, y: 0 }, 4)];
      grid.insertTile(merged);
      const metadata = (won, score = 8) => ({ won, over: !won, terminated: true, score, bestScore: 32 });
      const visible = () => actuator.messageContainer.matches('.game-won, .game-over');
      try {
        for (const won of [true, false]) {
          actuator.actuate(grid, metadata(won));
          actuator.continueGame();
          frame();
          check(!visible(), `Queued ${won ? 'win' : 'loss'} stays cleared after continue`);
          check(actuator.score === 8 && actuator.bestContainer.textContent === '32', 'Queued score and best-score updates survive continue');
          check(actuator.tileContainer.querySelectorAll('.tile').length === 5, 'Board and merged source tiles still render');
          check(!!actuator.tileContainer.querySelector('.tile-new') && !!actuator.tileContainer.querySelector('.tile-merged'), 'New and merged tile feedback survives');
          check(!!actuator.tileContainer.querySelector('.tile-2.tile-position-1-1'), 'Moving tile starts at its previous position');
          frame();
          check(!!actuator.tileContainer.querySelector('.tile-2.tile-position-2-1'), 'Moving tile advances on the next frame');
        }

        actuator.actuate(grid, metadata(true, 16));
        frame();
        check(actuator.messageContainer.classList.contains('game-won') && actuator.messageContainer.querySelector('p').textContent === 'You win!', 'Later legitimate win is shown');
        check(actuator.scoreContainer.querySelector('.score-addition').textContent === '+8', 'Score increase feedback is preserved');
        actuator.continueGame();
        check(!visible(), 'Already displayed message clears immediately');
        actuator.actuate(grid, metadata(false, 16));
        frame();
        check(actuator.messageContainer.classList.contains('game-over') && actuator.messageContainer.querySelector('p').textContent === 'Game over!', 'Later legitimate loss is shown');
        check(!actuator.scoreContainer.querySelector('.score-addition'), 'Unchanged score has no addition feedback');

        actuator.continueGame();
        actuator.actuate(grid, metadata(true));
        actuator.actuate(grid, metadata(false));
        actuator.continueGame();
        actuator.continueGame();
        const restartGrid = new Grid(4);
        restartGrid.insertTile(new Tile({ x: 0, y: 0 }, 2));
        actuator.actuate(restartGrid, { won: false, over: false, terminated: false, score: 0, bestScore: 32 });
        frame();
        check(!visible(), 'Multiple obsolete terminal callbacks cannot restore a message after restart');
        check(actuator.tileContainer.querySelectorAll('.tile').length === 1 && actuator.scoreContainer.textContent === '0' && actuator.bestContainer.textContent === '32', 'Restart retains the current board, reset score and best score');
        actuator.actuate(grid, metadata(true));
        actuator.clearMessage();
        actuator.actuate(grid, metadata(false));
        frame();
        check(!actuator.messageContainer.classList.contains('game-won') && actuator.messageContainer.classList.contains('game-over'), 'Clear invalidates older callbacks and preserves a newer terminal message in the same frame');
        actuator.continueGame();
        actuator.actuate(grid, { ...metadata(true), terminated: false });
        frame();
        check(!visible(), 'A continued game with won=true remains active');
        return results;
      } finally {
        window.requestAnimationFrame = originalRAF;
      }
    });
    assert.ok(results.length >= 20);
    console.log(`PASS: ${results.length} browser lifecycle and rendering assertions`);
    results.forEach(result => console.log(`  ${result}`));
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
