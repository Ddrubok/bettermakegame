Fixed `index.html` so scores retain all digits, with leading zeros below five digits. Animation, scoring, and layout remain unchanged.

Added `score-check.cjs`; reproduced the original failure, then passed checks for boundaries, count-up, loss/restart, scoring awards, and mobile/desktop visibility. `node smoke.cjs` also passed.

Limits: tested in Chromium only; existing JavaScript number precision remains unchanged.