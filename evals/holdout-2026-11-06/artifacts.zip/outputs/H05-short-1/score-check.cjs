const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Advance updates explicitly so the animation assertions are deterministic.
  const game = await openGame(__dirname, () => { window.requestAnimationFrame = () => 0; });
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    const { page } = game;
    assert.equal(await page.locator('#score').textContent(), '00000');
    for (const [value, expected] of [
      [100000, '100000'], [0, '00000'], [1, '00001'], [42, '00042'],
      [9999, '09999'], [10000, '10000'], [99999, '99999'],
      [123456, '123456'], [999999, '999999'], [1000000, '1000000'],
      [Number.MAX_SAFE_INTEGER, '9007199254740991'], [123.9, '00123']
    ]) {
      const result = await page.evaluate(value => {
        setScore(value);
        drawScore();
        return { text: get('score').textContent, score, vscore, dirty: invalid.score };
      }, value);
      assert.deepEqual(result, { text: expected, score: value, vscore: value, dirty: false });
    }

    await page.keyboard.press('Space');
    const animation = await page.evaluate(() => {
      setScore(99998);
      addScore(5);
      drawScore();
      const frames = [get('score').textContent];
      for (let tick = 0; tick < 6; tick++) {
        update(0);
        drawScore();
        frames.push(get('score').textContent);
      }
      return { frames, score, vscore };
    });
    assert.deepEqual(animation, {
      frames: ['99998', '99999', '100000', '100001', '100002', '100003', '100003'],
      score: 100003, vscore: 100003
    });

    await page.evaluate(() => addScore(123));
    await page.keyboard.press('Escape');
    assert.deepEqual(await page.evaluate(() => {
      draw();
      update(0);
      return { text: get('score').textContent, score, vscore, playing };
    }), { text: '100126', score: 100126, vscore: 100126, playing: false });

    await page.keyboard.press('Space');
    assert.deepEqual(await page.evaluate(() => {
      draw();
      return { text: get('score').textContent, score, vscore, playing, rows };
    }), { text: '00000', score: 0, vscore: 0, playing: true, rows: 0 });

    // Exercise existing scoring paths as well as the display setter.
    assert.equal(await page.evaluate(() => {
      setCurrentPiece({ type: o, dir: DIR.UP, x: 0, y: ny - 2 });
      drop();
      return score;
    }), 10);
    for (const [count, award] of [[1, 100], [2, 200], [3, 400], [4, 800]]) {
      assert.deepEqual(await page.evaluate(count => {
        reset();
        for (let y = ny - count; y < ny; y++)
          for (let x = 0; x < nx; x++) setBlock(x, y, o);
        removeLines();
        return { score, rows };
      }, count), { score: award, rows: count });
    }

    for (const viewport of [{ width: 320, height: 480 }, { width: 1000, height: 900 }]) {
      await page.setViewportSize(viewport);
      const visible = await page.evaluate(() => {
        setScore(1234567);
        draw();
        const element = get('score');
        const rect = element.getBoundingClientRect();
        const range = document.createRange();
        range.selectNodeContents(element);
        const text = range.getBoundingClientRect();
        return element.textContent === '1234567' && rect.width > 0 &&
          rect.left >= 0 && rect.right <= innerWidth &&
          text.left >= rect.left && text.right <= rect.right;
      });
      assert.equal(visible, true, `Full score visible at ${viewport.width}px`);
    }
    assert.deepEqual(errors, []);
    console.log('PASS: score boundaries, animation, loss/restart, scoring awards, and 320px/1000px visibility');
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
