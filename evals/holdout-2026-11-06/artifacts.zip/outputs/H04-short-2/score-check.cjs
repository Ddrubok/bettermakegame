const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Drive updates ourselves so monitor refresh and wall-clock scheduling cannot affect checks.
  const game = await openGame(__dirname, () => { window.requestAnimationFrame = () => {}; });
  try {
    const result = await game.page.evaluate(() => {
      const checks = [];
      function check(condition, name) {
        if (!condition) throw new Error(name);
        checks.push(name);
      }
      function start(target = 1000) { play(); addScore(target); }
      const rates = {};
      for (const hz of [30, 60, 120, 144, 240]) {
        start();
        for (let frame = 0; frame < hz; frame++) update(1 / hz);
        drawScore();
        rates[hz] = { progress: vscore, rendered: get('score').textContent };
        check(Math.abs(vscore - 60) < 1e-9, `${hz} Hz advances 60 points in one second`);
        check(/^\d{5}$/.test(get('score').textContent) &&
          Number(get('score').textContent) === Math.floor(vscore), `${hz} Hz renders an integer`);
        check(score === 1000, `${hz} Hz preserves awarded score`);
      }
      start();
      update(0);
      check(vscore === 0, 'zero elapsed time does not advance or snap');
      update(1 / 240);
      drawScore();
      check(vscore === 0.25 && get('score').textContent === '00000', 'fraction retained while rendering zero');
      for (let frame = 0; frame < 3; frame++) update(1 / 240);
      drawScore();
      check(vscore === 1 && get('score').textContent === '00001', 'short frames accumulate into a point');
      start();
      for (const seconds of [0.003, 0.017, 0.08, 0.2, 0.1, 0.6]) update(seconds);
      check(Math.abs(vscore - 60) < 1e-9, 'uneven frames use elapsed time');
      start(7);
      update(1);
      check(vscore === 7 && score === 7, 'large update clamps to actual score');
      update(1);
      addScore(10);
      update(1 / 240);
      check(vscore === 7.25, 'caught-up time is not banked for future awards');
      lose();
      drawScore();
      check(!playing && vscore === 17 && get('score').textContent === '00017', 'loss snaps to final integral score');
      const endedY = current.y;
      update(1);
      check(vscore === 17 && current.y === endedY, 'inactive update preserves end state');
      start();
      update(1 / 240);
      play();
      check(score === 0 && vscore === 0 && dt === 0, 'restart clears fractional progress and timing');
      addScore(10);
      update(1 / 240);
      check(vscore === 0.25, 'restart has no carried fractional progress');
      play();
      const initialY = current.y;
      update(step);
      check(current.y === initialY, 'gravity retains strict timing threshold');
      update(0.001);
      check(current.y === initialY + 1 && Math.abs(dt - 0.001) < 1e-9, 'gravity drops once and retains remainder');
      play();
      setCurrentPiece({ type: o, dir: DIR.UP, x: 4, y: 18 });
      drop();
      check(score === 10, 'locking a piece still awards ten points');
      for (let count = 1; count <= 4; count++) {
        play();
        for (let y = ny - count; y < ny; y++)
          for (let x = 0; x < nx; x++) setBlock(x, y, o);
        removeLines();
        check(rows === count && score === 100 * Math.pow(2, count - 1), `${count} line clear preserves award and row count`);
      }
      return { checks, rates };
    });
    assert.ok(result.checks.length > 0);
    console.log(JSON.stringify(result, null, 2));
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
