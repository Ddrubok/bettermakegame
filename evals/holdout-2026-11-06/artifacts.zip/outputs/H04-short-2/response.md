Updated `index.html` to advance the displayed score at 60 points/second, retain fractions, clamp to the actual score, and preserve integer rendering and the end-game snap.

Added `score-check.cjs`: all 32 checks passed, covering simulated 30–240 Hz, timing boundaries, restart, gravity and scoring. `node smoke.cjs` also passed.

Limits: no physical-monitor testing; floating-point rounding can delay an integer boundary by one frame. Supplied files remained unchanged.