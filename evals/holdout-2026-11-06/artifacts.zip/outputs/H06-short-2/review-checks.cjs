const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { openGame } = require('./browser.cjs');

// Characterization checks against the unchanged game, including known defects.
// Browser state is injected only in memory; animation is paused for repeatability.
(async () => {
  const protectedFiles = ['index.html', 'stats.js', 'browser.cjs', 'smoke.cjs', 'TASK.md', 'GUIDANCE.md'];
  const hashes = () => Object.fromEntries(protectedFiles.map(name => [name,
    crypto.createHash('sha256').update(fs.readFileSync(name)).digest('hex')]));
  const before = hashes();
  const game = await openGame(__dirname, () => { window.requestAnimationFrame = () => 0; });
  try {
    const result = await game.page.evaluate(() => {
      const types = [i, j, l, o, s, t, z];
      const names = ['i', 'j', 'l', 'o', 's', 't', 'z'];
      const name = type => names[types.indexOf(type)];
      const originalRandom = Math.random;
      const result = {};
      try {
        let seed = 123456789;
        Math.random = () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296);
        pieces = [];
        result.refills = Array.from({ length: 20 }, () => {
          const draws = Array.from({ length: 28 }, () => name(randomPiece().type));
          return { counts: names.map(n => draws.filter(d => d === n).length),
            last: draws[27], remaining: pieces.length };
        });
        Math.random = () => 0;
        pieces = [];
        result.repeatedDraws = Array.from({ length: 4 }, () => name(randomPiece().type));
        result.poolAfterFourDraws = pieces.length;
        result.twoPieceBoundary = [0, 0.5, 0.999999].map(value => {
          Math.random = () => value;
          pieces = [i, z];
          return { random: value, drawn: name(randomPiece().type), remaining: pieces.map(name) };
        });
        pieces = [z];
        result.singleton = name(randomPiece().type);
        result.emptyAfterSingleton = pieces.length;
        result.refillFirst = name(randomPiece().type);
        result.refillRemaining = pieces.length;

        const blank = () => { clearBlocks(); clearRows(); clearScore(); clearActions(); dt = 0; };
        result.clearAwards = [0, 1, 2, 3, 4].map(n => {
          blank();
          for (let y = ny - n; y < ny; y++)
            for (let x = 0; x < nx; x++) setBlock(x, y, j);
          removeLines();
          return { n, score, rows, bottomEmpty: Array.from({ length: nx }, (_, x) => !getBlock(x, ny - 1)).every(Boolean) };
        });
        result.lockAwards = [0, 1, 2, 3, 4].map(n => {
          blank(); playing = true;
          for (let y = ny - n; y < ny; y++)
            for (let x = 0; x < nx; x++) if (x !== 2) setBlock(x, y, j);
          current = { type: i, dir: DIR.RIGHT, x: 0, y: 16 };
          next = { type: o, dir: DIR.UP, x: 6, y: 0 };
          drop();
          return { n, score, rows, playing };
        });
        blank();
        for (const y of [17, 19]) for (let x = 0; x < nx; x++) setBlock(x, y, j);
        setBlock(0, 16, t);
        removeLines();
        result.separatedRows = { score, rows, markerShifted: getBlock(0, 18) === t };

        blank(); playing = true;
        // A valid vertical I at the ceiling is blocked below and completes row 0.
        for (let x = 0; x < nx; x++) if (x !== 2) setBlock(x, 0, j);
        setBlock(2, 4, j);
        current = { type: i, dir: DIR.RIGHT, x: 0, y: 0 };
        next = { type: o, dir: DIR.UP, x: 6, y: 0 };
        const fitsBeforeLock = unoccupied(current.type, current.x, current.y, current.dir);
        drop();
        result.topRowDefect = { fitsBeforeLock, score, rows, playing,
          rowStillFull: Array.from({ length: nx }, (_, x) => !!getBlock(x, 0)).every(Boolean) };

        pieces = [i, j, l];
        next = { type: t, dir: DIR.UP, x: 3, y: 0 };
        Math.random = () => 0;
        play();
        result.restart = { current: name(current.type), next: name(next.type),
          remaining: pieces.map(name), score, rows, playing };
      } finally { Math.random = originalRandom; }
      return result;
    });
    for (const refill of result.refills) {
      assert.deepEqual(refill.counts, [4, 4, 4, 4, 4, 4, 4]);
      assert.equal(refill.remaining, 0);
      assert.equal(refill.last, 'z'); // Reproduces positional bias, not desired randomness.
    }
    assert.deepEqual(result.repeatedDraws, ['i', 'i', 'i', 'i']);
    assert.equal(result.poolAfterFourDraws, 24);
    for (const sample of result.twoPieceBoundary) {
      assert.equal(sample.drawn, 'i');
      assert.deepEqual(sample.remaining, ['z']);
    }
    assert.equal(result.singleton, 'z');
    assert.equal(result.emptyAfterSingleton, 0);
    assert.equal(result.refillRemaining, 27);
    const awards = [0, 100, 200, 400, 800];
    for (const c of result.clearAwards) {
      assert.equal(c.score, awards[c.n]); assert.equal(c.rows, c.n); assert.equal(c.bottomEmpty, true);
    }
    for (const c of result.lockAwards) {
      assert.equal(c.score, 10 + awards[c.n]); assert.equal(c.rows, c.n); assert.equal(c.playing, true);
    }
    assert.deepEqual(result.separatedRows, { score: 200, rows: 2, markerShifted: true });
    assert.deepEqual(result.topRowDefect, { fitsBeforeLock: true, score: 10, rows: 0, playing: false, rowStillFull: true });
    assert.deepEqual(result.restart, { current: 't', next: 'i', remaining: ['j', 'l'], score: 0, rows: 0, playing: true });
    assert.deepEqual(hashes(), before);
    fs.writeFileSync('review-evidence.json', JSON.stringify({ status: 'PASS: characterization, including reproduced defects', result, protectedFileHashes: before }, null, 2) + '\n');
    console.log('PASS: 20 complete pools; repeat/refill boundaries; 0-4 clear and lock awards; separated-row compaction; top-row defect; restart continuity; protected files unchanged during checks.');
  } finally { await game.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
