# Focused review: piece pool and line-clear scoring

The playtester's observations do not by themselves show a broken game. The source implements a pool of four copies of each of seven types and the intended 100/200/400/800 line-clear awards. However, the checks reproduced a selection bias and a line-clear boundary defect. No game source or supplied task, guidance, helper, or skill files were edited.

## Intended behavior confirmed

- `index.html:160–165` refills only when the pool is empty, with 28 entries, and removes one entry per draw. Twenty deterministic full refills each produced exactly four of every type and exhausted at 28 draws. Repeated pieces are allowed: forcing random input to zero produced four consecutive I pieces. Equal totals per refill do not imply alternation or a particular order.
- `index.html:346–349` awards `100 * 2^(n - 1)` for a positive number of rows cleared together. Browser fixtures verified zero through four rows: 0/100/200/400/800. Adjacent rows were removed correctly in these bottom-board cases. Two separated full rows also earned 200, and a marker above them shifted down twice.
- `index.html:313–320` independently awards 10 points when a piece locks. Actual `drop()` fixtures for zero through four cleared rows therefore earned 10/110/210/410/810. These totals are consistent with the stated *line-clear* awards. The displayed score catches up gradually (`update`, lines 265–268), so an immediate screen reading can lag the internal total; this display behavior was inspected in source, not timed in a live animation test.
- `reset()` preserves the remaining pool and promotes the existing preview. A controlled `play()` restart confirmed preview promotion, one new draw, unchanged remaining-pool order, and reset score/rows. Pool boundaries are generation boundaries, not necessarily game-start or visible-piece boundaries. This is an observed lifecycle choice, not a violation of the given refill rule.

## Demonstrated defects

1. **The final pool slot is excluded until it is alone** (`index.html:164`). `random(0, pieces.length - 1)` yields a nonnegative fractional index below the final slot; `splice` truncates it. With two entries `[I, Z]`, random inputs 0, 0.5, and 0.999999 all selected I. The single remaining Z then drew correctly and the next call refilled to 27 remaining entries. Since a fresh pool ends in Z, its last Z is reserved until draw 28; all twenty tested refills ended in Z. Counts remain correct, but ordering is biased. This is independent of repeats being permitted. If uniform selection is intended, a narrowly scoped future correction is `Math.floor(Math.random() * pieces.length)` for this index. No change was applied.

2. **A full top row is not cleared** (`index.html:335`). The scan runs from `ny` down to 1, while playable rows are 0 through `ny - 1`. A browser fixture placed an unobstructed vertical I at y=0, blocked its downward motion, and filled the rest of row 0. Calling `drop()` completed that row, but it stayed full: rows remained 0, only the 10-point lock award was added, and the next piece collided, ending play. This is a row-detection defect, not evidence that exponential awards are wrong. Scanning from `ny - 1` through 0 would address the demonstrated boundary in a future repair; it was not implemented or retested as a patch. The out-of-board `ny` iteration is also unnecessary.

## Tradeoffs and optional alternatives

The four-copy pool balances counts over 28 draws while allowing clusters and longer waits between types than a one-copy seven-piece bag. A seven-piece bag would constrain that variability but change the designer's rule; independent draws would remove the fixed-count guarantee. Neither is a required fix for repeats. Correcting the index bias can preserve the chosen 28-piece design.

The stated scoring rewards setting up larger simultaneous clears: four singles award 400 in line bonuses, while one four-row clear awards 800. Linear scoring would reduce that incentive but change the intended design. Clearer rule text could help players understand both systems; it is optional polish.

## Checks actually run and limits

- `node review-checks.cjs` passed all characterization assertions against the unchanged game in Chromium using the supplied helper. Results are saved in `review-evidence.json`; passing includes explicit assertions reproducing both defects, not declaring them fixed. The script pauses animation and injects controlled game state and random inputs in browser memory. It checks the scenarios above and compares SHA-256 hashes of the supplied code/task/helper files before and after its run.
- `node smoke.cjs` completed successfully, reported title `Javascript Tetris`, and saved `smoke.png`. This verifies page loading and screenshot capture, not a full gameplay session.
- No manual playthrough, statistical randomness certification, long-duration scoring/display test, cross-browser/mobile testing, or whole-game audit was performed. The top-row fixture demonstrates the local locking/clearing path; a naturally played sequence reaching that board was not exercised. Optional corrections and alternative designs remain unimplemented and untested.

Added only this review, the focused verification script, its JSON evidence, and the smoke screenshot.
