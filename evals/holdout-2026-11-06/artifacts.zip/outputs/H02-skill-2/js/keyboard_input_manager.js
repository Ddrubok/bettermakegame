function KeyboardInputManager() {
  this.events = {};

  if (window.navigator.msPointerEnabled) {
    //Internet Explorer 10 style
    this.eventTouchstart    = "MSPointerDown";
    this.eventTouchmove     = "MSPointerMove";
    this.eventTouchend      = "MSPointerUp";
    this.eventTouchcancel   = "MSPointerCancel";
  } else {
    this.eventTouchstart    = "touchstart";
    this.eventTouchmove     = "touchmove";
    this.eventTouchend      = "touchend";
    this.eventTouchcancel   = "touchcancel";
  }

  this.listen();
}

KeyboardInputManager.prototype.on = function (event, callback) {
  if (!this.events[event]) {
    this.events[event] = [];
  }
  this.events[event].push(callback);
};

KeyboardInputManager.prototype.emit = function (event, data) {
  var callbacks = this.events[event];
  if (callbacks) {
    callbacks.forEach(function (callback) {
      callback(data);
    });
  }
};

KeyboardInputManager.prototype.listen = function () {
  var self = this;

  var map = {
    38: 0, // Up
    39: 1, // Right
    40: 2, // Down
    37: 3, // Left
    75: 0, // Vim up
    76: 1, // Vim right
    74: 2, // Vim down
    72: 3, // Vim left
    87: 0, // W
    68: 1, // D
    83: 2, // S
    65: 3  // A
  };

  // Respond to direction keys
  document.addEventListener("keydown", function (event) {
    var modifiers = event.altKey || event.ctrlKey || event.metaKey ||
                    event.shiftKey;
    var mapped    = map[event.which];

    if (!modifiers) {
      if (mapped !== undefined) {
        event.preventDefault();
        self.emit("move", mapped);
      }
    }

    // R key restarts the game
    if (!modifiers && event.which === 82) {
      self.restart.call(self, event);
    }
  });

  // Respond to button presses
  this.bindButtonPress(".retry-button", this.restart);
  this.bindButtonPress(".restart-button", this.restart);
  this.bindButtonPress(".keep-playing-button", this.keepPlaying);

  // Respond to swipe events
  var gesture = null;
  var pointerIds = [];
  var usePointer = window.navigator.msPointerEnabled;
  var gameContainer = document.getElementsByClassName("game-container")[0];

  // Observe all contacts, including a second finger outside the board.
  document.addEventListener(this.eventTouchstart, function (event) {
    var contact;
    var alreadyActive = gesture !== null;
    gesture = null;

    if (usePointer) {
      if (pointerIds.indexOf(event.pointerId) !== -1) return;
      pointerIds.push(event.pointerId);
      if (pointerIds.length !== 1 || alreadyActive) return;
      contact = { id: event.pointerId, x: event.pageX, y: event.pageY };
    } else {
      if (event.touches.length !== 1 || event.changedTouches.length !== 1 ||
          alreadyActive) return;
      contact = { id: event.touches[0].identifier,
                  x: event.touches[0].clientX, y: event.touches[0].clientY };
    }

    if (!gameContainer.contains(event.target)) return;
    gesture = contact;
    event.preventDefault();
  }, { passive: false });

  gameContainer.addEventListener(this.eventTouchmove, function (event) {
    event.preventDefault();
  }, { passive: false });

  document.addEventListener(this.eventTouchmove, function (event) {
    if (!gesture) return;
    if (usePointer ? event.pointerId !== gesture.id :
        event.touches.length !== 1 || event.touches[0].identifier !== gesture.id) {
      gesture = null;
    }
  });

  function releasePointer(event) {
    var index = pointerIds.indexOf(event.pointerId);
    if (index !== -1) pointerIds.splice(index, 1);
  }

  document.addEventListener(this.eventTouchcancel, function (event) {
    gesture = null;
    if (usePointer) releasePointer(event);
  });

  window.addEventListener("blur", function () {
    gesture = null;
    pointerIds = [];
  });

  document.addEventListener(this.eventTouchend, function (event) {
    var start = gesture;
    // Consume before emitting so duplicate or reentrant releases cannot move.
    gesture = null;
    if (usePointer) releasePointer(event);
    if (!start) return;

    var touchEndClientX, touchEndClientY;
    if (usePointer) {
      if (pointerIds.length || event.pointerId !== start.id) return;
      touchEndClientX = event.pageX;
      touchEndClientY = event.pageY;
    } else {
      if (event.touches.length !== 0 || event.changedTouches.length !== 1 ||
          event.changedTouches[0].identifier !== start.id) return;
      touchEndClientX = event.changedTouches[0].clientX;
      touchEndClientY = event.changedTouches[0].clientY;
    }

    var dx = touchEndClientX - start.x;
    var absDx = Math.abs(dx);

    var dy = touchEndClientY - start.y;
    var absDy = Math.abs(dy);

    if (Math.max(absDx, absDy) > 10) {
      // (right : left) : (down : up)
      self.emit("move", absDx > absDy ? (dx > 0 ? 1 : 3) : (dy > 0 ? 2 : 0));
    }
  });
};

KeyboardInputManager.prototype.restart = function (event) {
  event.preventDefault();
  this.emit("restart");
};

KeyboardInputManager.prototype.keepPlaying = function (event) {
  event.preventDefault();
  this.emit("keepPlaying");
};

KeyboardInputManager.prototype.bindButtonPress = function (selector, fn) {
  var button = document.querySelector(selector);
  button.addEventListener("click", fn.bind(this));
  button.addEventListener(this.eventTouchend, fn.bind(this));
};
