Fixed swipe lifecycle handling in `js/keyboard_input_manager.js`: cancelled or multi-touch gestures cannot move, completed gestures are consumed once, and clean gestures recover normally. Direction mapping, strict >10px threshold, keyboard controls, and game rules remain unchanged.

Added `swipe-check.cjs`. Passed 18 browser checks, a Chromium-generated touch sequence, syntax checks, and `node smoke.cjs`.

Limit: no physical-device testing; legacy MSPointer coverage uses simulated events. Supplied task, guidance, helper, and skill files remain unchanged.