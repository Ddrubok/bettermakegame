const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

async function check(pointer) {
  const game = await openGame(__dirname, pointer ? () => {
    Object.defineProperty(navigator, 'msPointerEnabled', { value: true });
  } : undefined);
  const errors = [];
  game.page.on('pageerror', error => errors.push(error.message));
  try {
    await game.page.waitForSelector('.tile');
    const results = await game.page.evaluate(pointer => {
      const board = document.querySelector('.game-container');
      const moves = [];
      const original = KeyboardInputManager.prototype.emit;
      KeyboardInputManager.prototype.emit = function (name, value) {
        if (name === 'move') moves.push(value);
        else original.call(this, name, value);
      };
      const names = pointer
        ? { start: 'MSPointerDown', move: 'MSPointerMove', end: 'MSPointerUp', cancel: 'MSPointerCancel' }
        : { start: 'touchstart', move: 'touchmove', end: 'touchend', cancel: 'touchcancel' };
      const contact = (id, x = 100, y = 100) => ({ identifier: id, clientX: x, clientY: y });
      const a = contact(1), b = contact(2);
      function send(type, live, changed, target = board) {
        const e = new Event(names[type], { bubbles: true, cancelable: true });
        Object.assign(e, pointer ? {
          pointerId: changed[0].identifier, pageX: changed[0].clientX, pageY: changed[0].clientY
        } : { touches: live, targetTouches: live, changedTouches: changed });
        target.dispatchEvent(e);
      }
      const start = () => send('start', [a], [a]);
      const end = (x = 140, y = 100) => send('end', [], [contact(1, x, y)]);
      const cases = [];
      function test(name, run, expected) {
        moves.length = 0;
        run();
        cases.push({ name, actual: moves.slice(), expected });
      }
      test('cancel then stale release, followed by recovery', () => {
        start(); send('cancel', [], [a]); end(); start(); end();
      }, [1]);
      test('duplicate and orphan releases', () => { end(); start(); end(); end(); }, [1]);
      test('multiple fingers with staggered releases and recovery', () => {
        start(); send('start', [a, b], [b]);
        send('end', [a], [contact(2, 150)]); end(); start(); end();
      }, [1]);
      test('second finger outside board', () => {
        start(); send('start', [a, b], [b], document.body);
        send('end', [a], [b], document.body); end(); start(); end();
      }, [1]);
      test('blur interrupts and next gesture recovers', () => {
        start(); window.dispatchEvent(new Event('blur')); end(); start(); end();
      }, [1]);
      test('threshold, four directions and diagonal tie', () => {
        start(); end(110); start(); end(90); start(); end(100, 110);
        start(); end(100, 90); start(); end(111); start(); end(89);
        start(); end(100, 111); start(); end(100, 89); start(); end(111, 111);
      }, [1, 3, 2, 0, 2]);
      test('wrong contact cannot complete gesture', () => {
        start(); send('end', [], [contact(2, 150)]); end(); start(); end();
      }, [1]);
      if (!pointer) {
        test('multi-touch observed during movement', () => {
          start(); send('move', [a, b], [a, b]); send('end', [a], [b]); end(); start(); end();
        }, [1]);
        test('simultaneous multi-touch start and end', () => {
          send('start', [a, b], [a, b]); send('end', [], [contact(1, 150), contact(2, 150)]);
          start(); end();
        }, [1]);
      }
      test('keyboard directions and modifier guard', () => {
        [38, 39, 40, 37, 75, 76, 74, 72, 87, 68, 83, 65].forEach(which => {
          document.dispatchEvent(new KeyboardEvent('keydown', { keyCode: which, bubbles: true }));
        });
        document.dispatchEvent(new KeyboardEvent('keydown', { keyCode: 38, shiftKey: true }));
      }, [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3]);
      return cases;
    }, pointer);
    for (const result of results) assert.deepEqual(result.actual, result.expected, `${pointer ? 'MSPointer' : 'Touch'}: ${result.name}`);
    if (!pointer) {
      await game.page.evaluate(() => {
        window.nativeMoves = [];
        KeyboardInputManager.prototype.emit = function (name, value) {
          if (name === 'move') window.nativeMoves.push(value);
        };
      });
      const box = await game.page.locator('.game-container').boundingBox();
      const first = { x: box.x + 60, y: box.y + 60, id: 1 };
      const moved = { ...first, x: first.x + 60 };
      const second = { x: first.x + 100, y: first.y, id: 2 };
      const session = await game.context.newCDPSession(game.page);
      const touch = (type, touchPoints) => session.send('Input.dispatchTouchEvent', { type, touchPoints });
      const swipe = async () => {
        await touch('touchStart', [first]);
        await touch('touchMove', [moved]);
        await touch('touchEnd', []);
      };
      await swipe();
      await touch('touchStart', [first]);
      await touch('touchMove', [moved]);
      await touch('touchCancel', []);
      await swipe();
      await touch('touchStart', [first]);
      await touch('touchStart', [first, second]);
      await touch('touchMove', [moved, second]);
      await touch('touchEnd', []);
      await swipe();
      assert.deepEqual(await game.page.evaluate(() => window.nativeMoves), [1, 1, 1],
        'Chromium touch input: clean swipes, cancellation, multi-touch and recovery');
      await session.detach();
      console.log('Chromium-generated touch sequence passed');
    }
    assert.deepEqual(errors, [], 'No browser errors');
    console.log(`${pointer ? 'MSPointer' : 'Touch'}: ${results.length} checks passed`);
  } finally {
    await game.close();
  }
}
(async () => { await check(false); await check(true); })().catch(error => {
  console.error(error); process.exitCode = 1;
});
