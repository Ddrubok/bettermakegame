const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  // Stop automatic frames so count-up and lifecycle checks are deterministic.
  const game = await openGame(__dirname, () => { window.requestAnimationFrame = () => 0; });
  try {
    const results = await game.page.evaluate(() => {
      const snapshot = () => ({ score, vscore, text: get('score').textContent });
      const initial = snapshot();
      const boundaries = [0, 1, 42, 9999, 10000, 99999, 100000, 100001, 999999, 1000000, 123456789, Number.MAX_SAFE_INTEGER].map(value => {
        setScore(value);
        drawScore();
        return snapshot();
      });
      play();
      setScore(99998);
      addScore(4);
      drawScore();
      const beforeAnimation = snapshot();
      const animation = [];
      for (let frame = 0; frame < 5; frame++) {
        update(0);
        drawScore();
        animation.push(snapshot());
      }
      addScore(123);
      lose();
      drawScore();
      const lost = { ...snapshot(), playing, startVisible: get('start').style.visibility !== 'hidden' };
      update(0);
      drawScore();
      const afterLoss = snapshot();
      play();
      drawScore();
      const restarted = { ...snapshot(), playing, rows };
      return { initial, boundaries, beforeAnimation, animation, lost, afterLoss, restarted };
    });
    assert.deepEqual(results.initial, { score: 0, vscore: 0, text: '00000' });
    for (const entry of results.boundaries) {
      assert.equal(entry.vscore, entry.score);
      assert.equal(entry.text, String(entry.score).padStart(5, '0'));
    }
    assert.deepEqual(results.beforeAnimation, { score: 100002, vscore: 99998, text: '99998' });
    assert.deepEqual(results.animation.map(s => s.vscore), [99999, 100000, 100001, 100002, 100002]);
    assert.deepEqual(results.animation.map(s => s.text), ['99999', '100000', '100001', '100002', '100002']);
    assert.ok(results.animation.every(s => s.score === 100002));
    assert.deepEqual(results.lost, { score: 100125, vscore: 100125, text: '100125', playing: false, startVisible: true });
    assert.deepEqual(results.afterLoss, { score: 100125, vscore: 100125, text: '100125' });
    assert.deepEqual(results.restarted, { score: 0, vscore: 0, text: '00000', playing: true, rows: 0 });

    for (const viewport of [{ width: 320, height: 480 }, { width: 1000, height: 900 }]) {
      await game.page.setViewportSize(viewport);
      const visible = await game.page.evaluate(() => {
        setScore(1234567);
        drawScore();
        const scoreRect = get('score').getBoundingClientRect();
        const menuRect = get('menu').getBoundingClientRect();
        return get('score').textContent === '1234567' && scoreRect.width > 0 &&
          scoreRect.left >= menuRect.left && scoreRect.right <= menuRect.right;
      });
      assert.ok(visible, `Seven-digit score fits menu at ${viewport.width}px`);
    }
    console.log('PASS: 12 score boundaries, count-up and authoritative score, loss, restart, and seven-digit visibility at two viewport sizes.');
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
