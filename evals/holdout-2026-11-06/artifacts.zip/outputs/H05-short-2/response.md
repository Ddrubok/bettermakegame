Fixed `index.html` so scores retain all digits while smaller scores keep five-digit zero padding. Scoring, count-up animation, and layout are unchanged.

Passed:
- `node score-check.cjs`: 12 boundary values, count-up across 100000, authoritative score, game over, restart, and seven-digit visibility at two viewport sizes.
- `node smoke.cjs`: browser smoke check; saved `smoke.png`.

Added `score-check.cjs`. Supplied task, guidance, and helpers remain unchanged. Verification used Chromium only.