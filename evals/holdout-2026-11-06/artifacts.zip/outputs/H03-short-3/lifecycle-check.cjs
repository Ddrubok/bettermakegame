const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    const results = await game.page.evaluate(async () => {
      // Let startup rendering finish before taking control of frame delivery.
      await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
      const nativeRAF = window.requestAnimationFrame;
      let frames = [];
      window.requestAnimationFrame = callback => frames.push(callback);
      const checks = [];
      function check(condition, name) {
        if (!condition) throw new Error(name);
        checks.push(name);
      }
      function flush() {
        const batch = frames;
        frames = [];
        batch.forEach(callback => callback());
      }
      function shown(actuator) {
        return actuator.messageContainer.classList.contains('game-won') ||
          actuator.messageContainer.classList.contains('game-over');
      }
      function grid(value = 2048) {
        const board = new Grid(4);
        board.insertTile(new Tile({ x: 0, y: 0 }, value));
        return board;
      }
      function metadata(won, score = 2048) {
        return { won, over: !won, terminated: true, score, bestScore: 4096 };
      }
      try {
        for (const won of [true, false]) {
          const actuator = new HTMLActuator();
          actuator.clearMessage();
          actuator.actuate(grid(), metadata(won));
          actuator.continueGame();
          flush();
          check(!shown(actuator), `queued ${won ? 'win' : 'loss'} stays cleared`);
          check(actuator.tileContainer.querySelector('.tile-2048'), 'pending board still renders');
          check(actuator.score === 2048 && actuator.bestContainer.textContent === '4096',
            'pending score and best score still render');
          check(actuator.scoreContainer.querySelector('.score-addition').textContent === '+2048',
            'score feedback survives continuation');
          actuator.actuate(grid(), metadata(won));
          flush();
          check(actuator.messageContainer.classList.contains(won ? 'game-won' : 'game-over'),
            'later terminal message appears');
          check(actuator.messageContainer.querySelector('p').textContent ===
            (won ? 'You win!' : 'Game over!'), 'terminal message text is correct');
          actuator.continueGame();
          check(!shown(actuator), 'already visible message clears immediately');
        }

        const actuator = new HTMLActuator();
        actuator.actuate(grid(), metadata(true));
        actuator.clearMessage();
        actuator.actuate(grid(), metadata(false, 4096));
        flush();
        check(!actuator.messageContainer.classList.contains('game-won') &&
          actuator.messageContainer.classList.contains('game-over'),
          'old win cannot contaminate a later loss in the same frame');
        actuator.continueGame();
        actuator.actuate(grid(), metadata(false));
        actuator.continueGame();
        actuator.actuate(grid(), metadata(true));
        actuator.continueGame();
        flush();
        check(!shown(actuator), 'multiple pending generations remain cleared');

        const board = grid(4);
        const merged = board.cellContent({ x: 0, y: 0 });
        const moving = new Tile({ x: 0, y: 0 }, 2);
        moving.previousPosition = { x: 1, y: 0 };
        merged.mergedFrom = [moving, new Tile({ x: 0, y: 0 }, 2)];
        board.insertTile(new Tile({ x: 3, y: 3 }, 2));
        actuator.actuate(board, { score: 4100, bestScore: 4100, terminated: false });
        flush();
        check(actuator.tileContainer.querySelector('.tile-merged.tile-4') &&
          actuator.tileContainer.querySelector('.tile-new.tile-position-4-4'),
          'merge and new-tile feedback remain');
        const moved = actuator.tileContainer.querySelector('.tile-position-2-1');
        check(moved, 'moving tile starts at its previous position');
        flush();
        check(moved.classList.contains('tile-position-1-1'), 'moving tile reaches its current position');
        check(!shown(actuator), 'nonterminal render has no message');

        // Exercise the unchanged manager's real restart and keep-playing paths.
        function Input() {}
        Input.prototype.on = function () {};
        function Storage() { this.best = 8192; }
        Storage.prototype.getGameState = function () { return null; };
        Storage.prototype.setGameState = Storage.prototype.clearGameState = function () {};
        Storage.prototype.getBestScore = function () { return this.best; };
        Storage.prototype.setBestScore = function (score) { this.best = score; };
        const manager = new GameManager(4, Input, HTMLActuator, Storage);
        flush();
        manager.grid = grid();
        manager.score = 2048;
        manager.won = true;
        manager.actuate();
        GameManager.prototype.keepPlaying.call(manager);
        flush();
        check(!shown(manager.actuator) && manager.actuator.score === 2048 &&
          manager.actuator.tileContainer.querySelector('.tile-2048'),
          'manager keep-playing preserves the pending winning board and score');
        for (const won of [true, false]) {
          manager.won = won;
          manager.over = !won;
          manager.keepPlaying = false;
          manager.actuate();
          manager.restart();
          flush();
          check(!shown(manager.actuator) && manager.actuator.score === 0 &&
            manager.actuator.tileContainer.children.length === 2 &&
            manager.actuator.bestContainer.textContent === '8192',
            `manager restart before ${won ? 'win' : 'loss'} frame renders a fresh board`);
          check(!manager.actuator.scoreContainer.querySelector('.score-addition'),
            'restart does not show a positive score addition');
        }
        manager.over = true;
        manager.actuate();
        flush();
        check(manager.actuator.messageContainer.classList.contains('game-over'),
          'new loss after restart still appears');
        return checks;
      } finally {
        window.requestAnimationFrame = nativeRAF;
      }
    });
    assert(results.length > 0);
    console.log(`PASS: ${results.length} browser lifecycle and feedback checks`);
    results.forEach(result => console.log(`  ${result}`));
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
