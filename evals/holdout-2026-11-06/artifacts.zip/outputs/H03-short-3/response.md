Fixed `js/html_actuator.js` so clearing a message invalidates queued terminal messages while preserving board, score, best-score and animation updates. Later terminal messages still display. GameManager and supplied files remain unchanged.

Checks run:

- Reproduced the failure before the fix.
- Passed 26 browser lifecycle and feedback checks in added `lifecycle-check.cjs`.
- Passed `node smoke.cjs` and JavaScript syntax validation.

Limit: browser verification used headless Chromium only.