const assert = require('node:assert/strict');
const { openGame } = require('./browser.cjs');

(async () => {
  const game = await openGame();
  try {
    await game.page.waitForSelector('.tile');
    const results = await game.page.evaluate(() => {
      const originalRAF = window.requestAnimationFrame;
      let frames = [];
      window.requestAnimationFrame = callback => frames.push(callback);
      const results = [];
      function check(condition, label) {
        if (!condition) throw new Error(label);
      }
      function flush() {
        const pending = frames;
        frames = [];
        pending.forEach(callback => callback());
      }
      function hidden(actuator) {
        return !actuator.messageContainer.classList.contains('game-won') &&
          !actuator.messageContainer.classList.contains('game-over');
      }
      function metadata(won, score = 16) {
        return { terminated: true, won, over: !won, score, bestScore: 100 };
      }
      function board(value = 4) {
        const grid = new Grid(4);
        grid.insertTile(new Tile({ x: 0, y: 0 }, value));
        return grid;
      }
      function fresh() {
        frames = [];
        const actuator = new HTMLActuator();
        actuator.continueGame();
        return actuator;
      }
      try {
        for (const won of [true, false]) {
          const actuator = fresh();
          actuator.actuate(board(), metadata(won));
          actuator.continueGame();
          flush();
          check(hidden(actuator), `obsolete ${won ? 'win' : 'loss'} stayed hidden`);
          check(actuator.tileContainer.querySelector('.tile-4'), 'pending board rendered');
          check(actuator.score === 16, 'pending score rendered');
          check(actuator.bestContainer.textContent === '100', 'best score rendered');
          check(actuator.scoreContainer.querySelector('.score-addition').textContent === '+16',
            'pending score feedback preserved');
          results.push(`cancel pending ${won ? 'win' : 'loss'}, preserve board and scores`);
        }

        for (const won of [true, false]) {
          const actuator = fresh();
          actuator.actuate(board(), metadata(!won));
          actuator.continueGame();
          actuator.continueGame();
          actuator.actuate(board(8), metadata(won, 32));
          flush();
          const expected = won ? 'game-won' : 'game-over';
          const opposite = won ? 'game-over' : 'game-won';
          check(actuator.messageContainer.classList.contains(expected), 'later terminal displayed');
          check(!actuator.messageContainer.classList.contains(opposite), 'old terminal suppressed');
          check(actuator.messageContainer.querySelector('p').textContent ===
            (won ? 'You win!' : 'Game over!'), 'terminal copy preserved');
          check(actuator.score === 32 && actuator.tileContainer.querySelector('.tile-8'),
            'latest board and score rendered');
          actuator.continueGame();
          check(hidden(actuator), 'visible terminal clears immediately');
          results.push(`later ${won ? 'win' : 'loss'} survives repeated continuation`);
        }

        // Exercise the unchanged manager's real restart and keep-playing paths.
        function Input() { this.on = function () {}; }
        function Storage() {
          this.getGameState = () => null;
          this.setGameState = this.clearGameState = () => {};
          this.getBestScore = () => 100;
          this.setBestScore = () => {};
        }
        for (const action of ['restart', 'keepPlaying']) {
          fresh();
          const manager = new GameManager(4, Input, HTMLActuator, Storage);
          flush();
          manager.grid = board(2048);
          manager.score = 2048;
          manager.won = true;
          manager.actuate();
          GameManager.prototype[action].call(manager);
          flush();
          check(hidden(manager.actuator), `${action} suppresses queued win`);
          check(manager.actuator.score === (action === 'restart' ? 0 : 2048),
            `${action} renders correct score`);
          check(manager.actuator.tileContainer.querySelectorAll('.tile').length ===
            (action === 'restart' ? 2 : 1), `${action} renders correct board`);
          manager.over = true;
          manager.actuate();
          flush();
          check(manager.actuator.messageContainer.classList.contains('game-over'),
            `${action} allows a later loss`);
          results.push(`GameManager ${action} and subsequent loss`);
        }

        const actuator = fresh();
        const grid = board(2);
        const moving = new Tile({ x: 1, y: 1 }, 8);
        moving.previousPosition = { x: 0, y: 1 };
        grid.insertTile(moving);
        const merged = new Tile({ x: 2, y: 2 }, 16);
        merged.mergedFrom = [new Tile({ x: 2, y: 2 }, 8), new Tile({ x: 3, y: 2 }, 8)];
        grid.insertTile(merged);
        actuator.actuate(grid, metadata(true));
        actuator.continueGame();
        flush();
        check(actuator.tileContainer.querySelector('.tile-2.tile-new'), 'spawn feedback');
        check(actuator.tileContainer.querySelector('.tile-16.tile-merged'), 'merge feedback');
        const wrapper = actuator.tileContainer.querySelector('.tile-8.tile-position-1-2');
        check(wrapper, 'movement starts at previous position');
        flush();
        check(wrapper.classList.contains('tile-position-2-2'), 'movement reaches current position');
        check(hidden(actuator), 'nested animation cannot restore terminal');
        results.push('spawn, merge, movement and score feedback preserved');
        return results;
      } finally {
        window.requestAnimationFrame = originalRAF;
      }
    });
    assert.equal(results.length, 7);
    results.forEach(result => console.log(`PASS ${result}`));
  } finally {
    await game.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
