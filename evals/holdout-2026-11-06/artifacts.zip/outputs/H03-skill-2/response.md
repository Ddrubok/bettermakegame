Updated `js/html_actuator.js` to invalidate queued terminal messages when cleared, while preserving board, score, and tile feedback. GameManager and supplied files remain unchanged.

Added `lifecycle-check.cjs`; it reproduced the original bug, then passed seven browser scenarios after the fix. Also passed `node smoke.cjs` and JavaScript syntax validation.

Remaining limit: checks used headless Chromium with controlled animation frames; visual animation smoothness was not assessed.