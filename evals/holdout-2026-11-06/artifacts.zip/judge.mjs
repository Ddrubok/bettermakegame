import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { resolve, join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
const { openGame } = createRequire(import.meta.url)('./browser.cjs');

export async function grade(id, folder) {
  const game = await openGame(folder, () => { window.requestAnimationFrame = () => 1; });
  const page = game.page;
  const checks = [];
  const add = (name, run) => checks.push({ name, run });
  const keyboard = async () => {
    await page.goto(game.url + '/fixture-host.html');
    await page.setContent('<div class="game-container"></div><button class="retry-button"></button><button class="restart-button"></button><button class="keep-playing-button"></button><input id="nick"><textarea id="notes"></textarea><div contenteditable="true" id="editor"><span id="nested">hello</span></div>');
    await page.addScriptTag({ url: game.url + '/js/keyboard_input_manager.js' });
    await page.evaluate(() => {
      window.input = new KeyboardInputManager(); window.moves=[]; window.restarts=0;
      input.on('move', v => moves.push(v)); input.on('restart', () => restarts++);
      window.key = (selector, code, modifiers={}) => {
        const target = document.querySelector(selector); target.focus();
        const ev = new KeyboardEvent('keydown',{bubbles:true,cancelable:true,keyCode:code,which:code,...modifiers});
        target.dispatchEvent(ev); return ev.defaultPrevented;
      };
      window.touch = (type, points, changed=points) => {
        const target=document.querySelector('.game-container');
        const convert=items=>items.map(([identifier,clientX,clientY])=>({identifier,clientX,clientY,target}));
        const ev=new Event(type,{bubbles:true,cancelable:true});
        Object.defineProperties(ev,{touches:{value:convert(points)},targetTouches:{value:convert(points)},changedTouches:{value:convert(changed)}});
        target.dispatchEvent(ev);
      };
    });
  };
  const actuator = async () => {
    await page.goto(game.url + '/fixture-host.html');
    await page.setContent('<div class="tile-container"></div><div class="score-container"></div><div class="best-container"></div><div class="game-message"><p></p></div>');
    await page.evaluate(() => {
      window.frames=[]; window.requestAnimationFrame=fn=>(frames.push(fn),frames.length);
      window.cancelAnimationFrame=id=>{frames[id-1]=null;};
      window.flush=()=>{let limit=30; while(frames.length && limit--){const batch=frames.splice(0);for(const fn of batch)fn?.();}};
    });
    await page.addScriptTag({url:game.url+'/js/html_actuator.js'});
    await page.evaluate(() => {
      window.a=new HTMLActuator();
      window.grid=value=>({cells:[[{x:0,y:0,value}]]});
      window.meta=(score,over=false,won=false)=>({score,bestScore:300,over,won,terminated:over||won});
      window.view=()=>({message:document.querySelector('.game-message').className,
        tiles:document.querySelector('.tile-container').textContent,
        score:a.score,best:document.querySelector('.best-container').textContent});
    });
  };
  const tetris = () => page.goto(game.url);

  if (id === 'H01') {
    for (const selector of ['#nick','#notes','#nested']) add(`editor ${selector} owns keys`, async()=>{
      await keyboard(); const result=await page.evaluate(selector=>({cancelled:[key(selector,65),key(selector,82),key(selector,37)],moves,restarts}),selector);
      assert.deepEqual(result,{cancelled:[false,false,false],moves:[],restarts:0});
    });
    add('game shortcuts and restart survive',async()=>{
      await keyboard(); assert.deepEqual(await page.evaluate(()=>{
        const cancelled=[38,39,40,37,75,76,74,72,87,68,83,65,82].map(code=>key('body',code));
        return{cancelled,moves,restarts};
      }),{cancelled:Array(13).fill(true),moves:[0,1,2,3,0,1,2,3,0,1,2,3],restarts:1});
    });
    add('modifier shortcuts remain untouched',async()=>{
      await keyboard(); assert.deepEqual(await page.evaluate(()=>{
        const cancelled=['ctrlKey','metaKey','altKey','shiftKey'].flatMap(k=>[key('body',65,{[k]:true}),key('body',82,{[k]:true})]);
        return{cancelled,moves,restarts};
      }),{cancelled:Array(8).fill(false),moves:[],restarts:0});
    });
  } else if(id==='H02') {
    add('clean directions and strict threshold',async()=>{
      await keyboard(); assert.deepEqual(await page.evaluate(()=>{
        for(const [x,y] of [[100,10],[-80,10],[10,100],[10,-80],[20,10]]){
          touch('touchstart',[[1,10,10]]);touch('touchend',[],[[1,x,y]]);
        } return moves;
      }),[1,3,2,0]);
    });
    add('cancelled gesture cannot complete',async()=>{
      await keyboard(); assert.deepEqual(await page.evaluate(()=>{
        touch('touchstart',[[1,10,10]]);touch('touchcancel',[],[[1,10,10]]);touch('touchend',[],[[1,100,10]]);return moves;
      }),[]);
    });
    add('multi-touch cannot reuse a prior start',async()=>{
      await keyboard(); assert.deepEqual(await page.evaluate(()=>{
        touch('touchstart',[[1,10,10]]);touch('touchend',[],[[1,100,10]]);moves.length=0;
        touch('touchstart',[[2,200,10],[3,220,10]]);touch('touchend',[],[[2,300,10],[3,320,10]]);return moves;
      }),[]);
    });
    add('adding a finger invalidates partial and final ends',async()=>{
      await keyboard(); assert.deepEqual(await page.evaluate(()=>{
        touch('touchstart',[[1,10,10]]);touch('touchstart',[[1,10,10],[2,20,10]],[[2,20,10]]);
        touch('touchend',[[2,100,10]],[[1,100,10]]);touch('touchend',[],[[2,120,10]]);return moves;
      }),[]);
    });
    add('fresh gesture works after cancellation; duplicate end ignored',async()=>{
      await keyboard(); assert.deepEqual(await page.evaluate(()=>{
        touch('touchstart',[[1,10,10]]);touch('touchcancel',[],[[1,10,10]]);
        touch('touchstart',[[2,10,10]]);touch('touchend',[],[[2,100,10]]);touch('touchend',[],[[2,100,10]]);return moves;
      }),[1]);
    });
  } else if(id==='H03') {
    add('old loss cannot cover a restarted board',async()=>{
      await actuator();const r=await page.evaluate(()=>{a.actuate(grid(2),meta(100,true));a.continueGame();a.actuate(grid(4),meta(0));flush();return view();});
      assert.equal(r.message,'game-message'); assert.equal(r.tiles,'4'); assert.equal(r.score,0);assert.equal(r.best,'300');
    });
    add('continue invalidates a queued win even before next render',async()=>{
      await actuator();assert.equal(await page.evaluate(()=>{a.actuate(grid(2048),meta(100,false,true));a.continueGame();flush();return view().message;}),'game-message');
    });
    add('latest board and score survive rapid updates',async()=>{
      await actuator(); const r=await page.evaluate(()=>{a.actuate(grid(2),meta(4));a.actuate(grid(8),meta(16));flush();return view();});
      assert.equal(r.tiles,'8');assert.equal(r.score,16);assert.equal(r.best,'300');
    });
    add('legitimate terminal results still display',async()=>{
      await actuator(); assert.equal(await page.evaluate(()=>{a.continueGame();a.actuate(grid(2048),meta(100,false,true));flush();return document.querySelector('.game-message').classList.contains('game-won');}),true);
    });
    add('score increment feedback and tile style survive',async()=>{
      await actuator();assert.deepEqual(await page.evaluate(()=>{a.actuate(grid(4),meta(4));flush();a.actuate(grid(8),meta(8));flush();return{
        addition:document.querySelector('.score-addition')?.textContent,
        tile:document.querySelector('.tile').classList.contains('tile-8')};}),{addition:'+4',tile:true});
    });
  } else if(id==='H04') {
    for(const hz of [30,60,120]) add(`count-up at ${hz} Hz`,async()=>{
      await tetris(); const r=await page.evaluate(hz=>{play();step=1e6;addScore(120);for(let n=0;n<hz;n++)update(1/hz);drawScore();return{vscore,score,text:get('score').textContent};},hz);
      assert.ok(Math.abs(r.vscore-60)<1e-6);assert.equal(r.score,120);assert.equal(r.text,'00060');
    });
    add('zero elapsed and fractional intervals do not invent or lose progress',async()=>{
      await tetris(); const r=await page.evaluate(()=>{play();step=1e6;addScore(10);update(0);const zero=vscore;for(let i=0;i<100;i++)update(0.001);drawScore();return{zero,vscore,text:get('score').textContent};});
      assert.equal(r.zero,0);assert.ok(Math.abs(r.vscore-6)<1e-6);assert.match(r.text,/^0000[56]$/);
    });
    add('no overshoot, final snap, restart and drop score preserved',async()=>{
      await tetris(); const r=await page.evaluate(()=>{play();step=1e6;addScore(5);update(1);const capped=vscore;addScore(100);lose();const final=vscore;play();const resetScore=vscore;
        current={type:o,dir:DIR.UP,x:4,y:18};drop();return{capped,final,resetScore,score,rows};});
      assert.deepEqual(r,{capped:5,final:105,resetScore:0,score:10,rows:0});
    });
  } else if(id==='H05') {
    for(const value of [0,9,12345,99999,100000,1234567]) add(`display score ${value}`,async()=>{
      await tetris(); const r=await page.evaluate(value=>{setScore(value);drawScore();return{score,text:get('score').textContent};},value);
      assert.deepEqual(r,{score:value,text:String(value).padStart(5,'0')});
    });
    add('count-up and end-game snap stay intact',async()=>{
      await tetris(); assert.deepEqual(await page.evaluate(()=>{play();step=1e6;addScore(100000);update(1/60);drawScore();const before=get('score').textContent;lose();drawScore();return{before,after:get('score').textContent,score};}),{before:'00001',after:'100000',score:100000});
    });
  } else if(id==='H06') {
    add('game source is unchanged for review-only task',async()=>{
      const source=new URL('./inputs/H06/index.html',import.meta.url);
      assert.equal(await readFile(join(folder,'index.html'),'utf8'),await readFile(source,'utf8'));
    });
    add('each refill contains four of every type and permits repeats',async()=>{
      await tetris(); const r=await page.evaluate(()=>{pieces=[];const saved=Math.random;Math.random=()=>0;const bags=[];
        for(let b=0;b<3;b++){const counts={};const order=[];for(let k=0;k<28;k++){const c=randomPiece().type.color;counts[c]=(counts[c]||0)+1;order.push(c);}bags.push({counts,repeat:order[0]===order[1]});}Math.random=saved;return bags;});
      for(const b of r){assert.equal(Object.keys(b.counts).length,7);assert.ok(Object.values(b.counts).every(v=>v===4));assert.equal(b.repeat,true);}
    });
    add('line-clear awards match stated intent',async()=>{
      await tetris(); assert.deepEqual(await page.evaluate(()=>{const awards=[];for(let n=1;n<=4;n++){reset();for(let y=20-n;y<20;y++)for(let x=0;x<10;x++)setBlock(x,y,o);removeLines();awards.push({score,rows});}return awards;}),[1,2,3,4].map((rows,i)=>({rows,score:100*2**i})));
    });
  } else throw new Error('Unknown case');
  const results=[];
  try {
    for(const check of checks){try{await check.run();results.push({name:check.name,status:'PASS'});}catch(error){results.push({name:check.name,status:'FAIL',error:error.message});}}
  } finally { await game.close(); }
  assert.ok(checks.length);
  return {id,status:results.length===checks.length && results.every(r=>r.status==='PASS')?'PASS':'FAIL',expected:checks.map(c=>c.name),checks:results};
}

if(process.argv[1] && import.meta.url===pathToFileURL(resolve(process.argv[1])).href){
  const [id,folder,out]=process.argv.slice(2);
  const result=await grade(id,resolve(folder));
  if(out)await writeFile(out,JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result,null,2));process.exitCode=result.status==='PASS'?0:1;
}
