const { chromium } = require('C:/Users/DooBokWie/orca/projects/Default/screen-fidelity-lab/node_modules/playwright');
const http = require('node:http');
const fs = require('node:fs/promises');
const path = require('node:path');

exports.openGame = async function(root = __dirname, initScript) {
  const base = path.resolve(root);
  const types = { '.html':'text/html', '.js':'text/javascript', '.css':'text/css', '.jpg':'image/jpeg',
    '.png':'image/png', '.ico':'image/x-icon', '.woff':'font/woff', '.ttf':'font/ttf', '.svg':'image/svg+xml' };
  const server = http.createServer(async (req, res) => {
    try {
      const name = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
      const file = path.resolve(base, '.' + (name === '/' ? '/index.html' : name));
      if (!file.startsWith(base + path.sep) || !types[path.extname(file)]) throw new Error('Not served');
      res.setHeader('Content-Type', types[path.extname(file)]);
      res.end(await fs.readFile(file));
    } catch { res.statusCode = 404; res.end('Not found'); }
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const url = `http://127.0.0.1:${server.address().port}`;
  let browser;
  try {
    browser = await chromium.launch({ headless:true, chromiumSandbox:true });
    const context = await browser.newContext({ viewport:{width:1000,height:900} });
    await context.route('**/*', route => route.request().url().startsWith(url + '/') ? route.continue() : route.abort());
    if (initScript) await context.addInitScript(initScript);
    const page = await context.newPage();
    page.setDefaultTimeout(5000);
    await page.goto(url);
    return { browser, context, page, url, close: async () => {
      await browser.close(); await new Promise(r => server.close(r));
    }};
  } catch (error) {
    await browser?.close(); await new Promise(r => server.close(r)); throw error;
  }
};
