import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { run, root, args } from './launch.mjs';
const manifest=JSON.parse(await readFile(join(root,'manifest.json'),'utf8'));
const selfcheck=JSON.parse(await readFile(join(root,'self-check.json'),'utf8'));
if(selfcheck.length!==12 || selfcheck.filter(x=>x.kind==='control').some(x=>x.status!=='PASS'))throw new Error('Self-check incomplete');
const sha=async name=>createHash('sha256').update(await readFile(join(root,name))).digest('hex');
const frozen={date:new Date().toISOString(),model:'gpt-6-astra',reasoning:'high',concurrency:3,
  timeout_ms:360000,arguments:args,sha256:Object.fromEntries(await Promise.all(['manifest.json','judge.mjs','browser.cjs','self-check.json','launch.mjs'].map(async n=>[n,await sha(n)]))),
  instruction:'Read TASK.md and GUIDANCE.md and carry out the requested work within this folder. Do not read parent/sibling folders, global instructions or installed skills; do not use web search, other agents or prior solutions. The provided browser helper and its installed dependency are allowed. Leave the supplied task/guidance/helper/skill files unchanged. Add focused checks if useful. Give a concise final report of changes, actual checks and remaining limits. You have up to six minutes for this task.'};
await writeFile(join(root,'frozen-protocol.json'),JSON.stringify(frozen,null,2)+'\n');
let cursor=0;
let infrastructureStop=false;
const results=[];
async function worker(){
  for(;;){
    if(infrastructureStop)return;
    const index=cursor++;if(index>=manifest.sessions.length)return;
    const session=manifest.sessions[index];console.log('START '+session.name);
    try{
      const result=await run(session.name,session.folder,frozen.instruction,frozen.timeout_ms);
      if(result.commands===0 || result.exit_code!==0 || result.errors.length) infrastructureStop=true;
      results.push(result);await writeFile(join(root,'progress.json'),JSON.stringify(results,null,2)+'\n');
      console.log('DONE '+session.name+' '+JSON.stringify({elapsed_ms:result.elapsed_ms,usage:result.usage,timeout:result.timeout,errors:result.errors.length,exit:result.exit_code}));
    }catch(error){results.push({name:session.name,infrastructure_error:String(error)});console.log('ERROR '+session.name+' '+String(error));}
  }
}
await Promise.all([worker(),worker(),worker()]);
await writeFile(join(root,'session-results.json'),JSON.stringify(results,null,2)+'\n');
console.log('FINISHED '+results.length);
