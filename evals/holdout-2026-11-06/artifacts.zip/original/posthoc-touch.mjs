// Exploratory test written after masked source review, before opening the arm map.
// This does not modify the preregistered judge or its primary score.
import { createRequire } from 'node:module';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { root } from './launch.mjs';
const {openGame}=createRequire(import.meta.url)('./browser.cjs');
const map=JSON.parse(await readFile(join(root,'blind-map.json'),'utf8'));
const results=[];
for(const [alias,name] of [['baseline','baseline'],...Object.entries(map).filter(([,name])=>name.startsWith('H02-'))]){
  const folder=join(root,name==='baseline'?'inputs/H02':'sessions/'+name);
  const g=await openGame(folder,()=>{window.requestAnimationFrame=()=>1;});
  try{
    await g.page.goto(g.url+'/fixture-host.html');
    await g.page.setContent('<div class="game-container"></div><input id="outside"><button class="retry-button"></button><button class="restart-button"></button><button class="keep-playing-button"></button>');
    await g.page.addScriptTag({url:g.url+'/js/keyboard_input_manager.js'});
    const observed=await g.page.evaluate(()=>{
      const game=document.querySelector('.game-container'),outside=document.querySelector('#outside');
      const input=new KeyboardInputManager(),moves=[];input.on('move',x=>moves.push(x));
      function send(target,type,contacts,changed){
        const point=([id,x])=>({identifier:id,clientX:x,clientY:10,target:id===2?outside:game});
        const touches=contacts.map(point),event=new Event(type,{bubbles:true,cancelable:true});
        Object.defineProperties(event,{touches:{value:touches},targetTouches:{value:touches.filter(t=>t.target===target)},changedTouches:{value:changed.map(point)}});
        target.dispatchEvent(event);
      }
      send(game,'touchstart',[[1,10]],[[1,10]]);
      send(outside,'touchstart',[[1,10],[2,200]],[[2,200]]);
      send(outside,'touchend',[[1,10]],[[2,200]]);
      send(game,'touchend',[],[[1,100]]);
      const interrupted=[...moves];moves.length=0;
      send(game,'touchstart',[[3,10]],[[3,10]]);send(game,'touchend',[],[[3,100]]);
      return{interrupted,cleanNext:moves};
    });
    results.push({alias,name,status:observed.interrupted.length===0&&JSON.stringify(observed.cleanNext)==='[1]'?'PASS':'FAIL',observed});
  }finally{await g.close();}
}
await writeFile(join(root,'posthoc-touch.json'),JSON.stringify({kind:'EXPLORATORY; not part of the frozen primary judge',hypothesis:'A second touch that starts and ends outside the board must invalidate the in-progress board gesture',results},null,2)+'\n');
// Keep condition labels masked for the initial review.
console.log(JSON.stringify(results.map(({alias,status,observed})=>({alias,status,observed})),null,2));
