import { spawn } from 'node:child_process';
import { mkdirSync, readdirSync, readFileSync, writeFileSync, createWriteStream } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

export const root = dirname(fileURLToPath(import.meta.url));
const cli = 'C:/Users/DooBokWie/AppData/Roaming/npm/node_modules/@openai/codex/bin/codex.js';
const names = new Set();
for (const name of ['pages:maintain-space', 'pages:manage-schedules', 'pages:organize-space', 'pages:write-page',
  'plugin-management:plugin-management', 'sites:sites', 'sites:sites-remix',
  'work-pets:create-pet', 'work-pets:pets', 'work-pets:update-pet', 'documents:documents',
  'pdf:pdf', 'presentations:Presentations', 'spreadsheets:Spreadsheets', 'spreadsheets:excel-live-control',
  'template-creator:template-creator']) {
  names.add(name); names.add(name.split(':').at(-1));
}
for (const base of ['C:/Users/DooBokWie/.codex/skills', 'C:/Users/DooBokWie/.agents/skills', 'C:/Users/DooBokWie/.codex/skills/.system']) {
  for (const entry of readdirSync(base, { withFileTypes: true })) {
    try {
      const text = readFileSync(join(base, entry.name, 'SKILL.md'), 'utf8');
      const name = text.match(/^name:\s*["']?([^\r\n"']+)/m)?.[1];
      if (name) names.add(name);
    } catch {}
  }
}
export const args = ['exec', '--ignore-user-config', '--skip-git-repo-check', '--ephemeral', '--json',
  '--model', 'gpt-6-astra', '--dangerously-bypass-approvals-and-sandbox',
  '-c', 'approval_policy="never"', '-c', 'model_reasoning_effort="high"', '-c', 'project_doc_max_bytes=0',
  '-c', 'suppress_unstable_features_warning=true', '-c', 'web_search="disabled"',
  '-c', `skills.config=[${[...names].map(name => `{name=${JSON.stringify(name)},enabled=false}`).join(',')}]`,
  '--enable', 'skip_host_skill_discovery', '--disable', 'hooks', '--disable', 'apps',
  '--disable', 'remote_plugin', '--disable', 'multi_agent', '--disable', 'skill_search'];

export async function run(name, cwd, prompt, timeoutMs = 360000) {
  const logs = join(root, 'logs', name);
  mkdirSync(logs, { recursive: true });
  const output = createWriteStream(join(logs, 'events.jsonl'));
  const errors = createWriteStream(join(logs, 'stderr.txt'));
  const started = new Date();
  let killed = false;
  const command = [cli, ...args, '--cd', cwd, '-o', join(logs, 'response.md'), '-'];
  writeFileSync(join(logs, 'request.json'), JSON.stringify({ command, cwd, prompt, timeoutMs }, null, 2));
  const child = spawn(process.execPath, command, { cwd, windowsHide: true,
    env: { ...process.env, ORCA_WORKER: 'bmg-astra-evaluation' }, stdio: ['pipe', 'pipe', 'pipe'] });
  child.stdout.pipe(output); child.stderr.pipe(errors);
  child.stdin.end(prompt);
  const timer = setTimeout(() => {
    killed = true;
    spawn('taskkill.exe', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
  }, timeoutMs);
  const code = await new Promise((resolve, reject) => { child.once('error', reject); child.once('close', resolve); });
  clearTimeout(timer);
  await Promise.all([new Promise(r => output.end(r)), new Promise(r => errors.end(r))]);
  const events = readFileSync(join(logs, 'events.jsonl'), 'utf8').split('\n').flatMap(line => {
    try { return [JSON.parse(line)]; } catch { return []; }
  });
  const usage = events.findLast(e => e.type === 'turn.completed')?.usage ?? null;
  const record = { name, started_at: started.toISOString(), ended_at: new Date().toISOString(),
    elapsed_ms: Date.now() - started.getTime(), timeout: killed, exit_code: code,
    session_id: events.find(e => e.type === 'thread.started')?.thread_id ?? null,
    usage, errors: events.filter(e => e.type === 'error' || e.type === 'turn.failed' || e.item?.type === 'error'),
    commands: events.filter(e => e.item?.type === 'command_execution' && e.type === 'item.completed').length };
  writeFileSync(join(logs, 'metrics.json'), JSON.stringify(record, null, 2));
  return record;
}

if (process.argv[2] === 'audit') {
  const record = await run('catalog-audit-final', root,
    'Harness diagnostic only. Do not call tools or inspect files. List the names of any installed skills actually advertised in your initial system/developer context. If none, reply NO_SKILL_CATALOG. Do not guess names.');
  console.log(JSON.stringify(record));
  console.log(readFileSync(join(root, 'logs/catalog-audit-final/response.md'), 'utf8'));
}
if (process.argv[2] === 'smoke') {
  const cwd=join(root,'environment-smoke');mkdirSync(cwd,{recursive:true});
  writeFileSync(join(cwd,'note.txt'),'BMG_ENVIRONMENT_PROBE\n');
  writeFileSync(join(cwd,'browser.cjs'),readFileSync(join(root,'browser.cjs')));
  writeFileSync(join(cwd,'index.html'),'<title>Environment probe</title><p>Local browser probe</p>');
  writeFileSync(join(cwd,'smoke.cjs'),`const {openGame}=require('./browser.cjs'); (async()=>{const g=await openGame();try{await g.page.screenshot({path:'probe.png'});console.log(await g.page.title());}finally{await g.close();}})().catch(e=>{console.error(e);process.exitCode=1;});`);
  console.log(JSON.stringify(await run('environment-smoke',cwd,
    'Environment diagnostic. Use tools to read note.txt, create probe.txt containing the same text, and run node smoke.cjs. Work only in this folder. Do not use any skills or agents. Report SMOKE_OK only if all three operations succeeded.',120000)));
  console.log(readFileSync(join(root,'logs/environment-smoke/response.md'),'utf8'));
}
