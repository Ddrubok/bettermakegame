// Coordinator-owned confirmation of review findings; excluded from primary score.
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const { openGame } = createRequire(import.meta.url)('./browser.cjs');
const g = await openGame(fileURLToPath(new URL('./inputs/H06/', import.meta.url)), () => { window.requestAnimationFrame = () => 1; });
try {
  const observed = await g.page.evaluate(() => {
    const saved = Math.random;
    const lastColors = [];
    for (const fraction of [0, 0.1, 0.5, 0.9, 0.999999]) {
      pieces = []; Math.random = () => fraction;
      let last;
      for (let n = 0; n < 28; n++) last = randomPiece().type.color;
      lastColors.push(last);
    }
    Math.random = saved;
    reset(); for (let x = 0; x < 10; x++) setBlock(x, 0, o);
    removeLines();
    return { lastColors, zColor: z.color, topRow: { score, rows, occupied: Array.from({length:10}, (_,x) => !!getBlock(x,0)) } };
  });
  assert.ok(observed.lastColors.every(color => color === observed.zColor));
  assert.equal(observed.topRow.rows, 0); assert.equal(observed.topRow.score, 0);
  assert.ok(observed.topRow.occupied.every(Boolean));
  const result = { kind:'POSTHOC confirmation of review observations, not primary accuracy scoring', status:'CONFIRMED', observed,
    limits:'Controlled browser states; does not establish natural-play reachability or player-perceived frequency.' };
  await writeFile(new URL('./posthoc-review.json', import.meta.url), JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify(result));
} finally { await g.close(); }
